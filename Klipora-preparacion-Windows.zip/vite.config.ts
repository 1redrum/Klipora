import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { localProcessing } from "./local/server.ts";
import netlify from "@netlify/vite-plugin-tanstack-start";

const config = defineConfig(({ command }) => ({
  resolve: { tsconfigPaths: true },
  server: { host: "127.0.0.1", strictPort: true },
  plugins: [
    localProcessing(),
    tailwindcss(),
    ...(command === "build" ? [netlify()] : []),
    tanstackStart(),
    viteReact(),
  ],
}));

export default config;
