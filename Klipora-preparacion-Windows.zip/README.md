# Klipora en local

El flujo de importación y exportación se ejecuta desde el equipo con `pnpm dev`. Consulta la [guía de instalación y recuperación](docs/local-processing.md) y la [guía de detección de momentos con IA](docs/semantic-analysis.md). Consulta también el [seguimiento y análisis visual](docs/visual-analysis.md). Para ajustar los resultados, consulta la [guía del editor](docs/clip-editor.md). Las pruebas de recuperación y la lista para Windows están en [estabilidad](docs/stability.md). Consulta el [informe de Windows y GPU](docs/windows-validation.md) para la validación de la fase 6.

# Klipora

Klipora is an AI clip generator: upload a video or paste a YouTube, Twitch or Kick link and get short vertical clips of the best
moments, each with an estimated interest score (1–100), suggested title, description and hashtags, burned-in synced captions and
smart framing, exported in H.264/AAC up to 1080p.

The product surface is live: landing page, projects history, new-project import, processing status, results dashboard and clip
editor. URL detection and upload file checks run for real in the browser; projects and clips currently come from sample data
until the processing backend is connected (see [PLAN.md](PLAN.md)).

## Stack

- TanStack Start (React 19, TypeScript), Tailwind CSS 4, shadcn/ui components
- Deployed on Netlify
- Planned: Netlify Identity, Netlify Database (Postgres + Drizzle), S3-compatible storage, Python worker (FastAPI, Celery/RQ,
  Redis, FFmpeg, faster-whisper), Netlify AI Gateway

## Run locally

```bash
pnpm install
netlify dev   # or: pnpm dev
```

## Roadmap

Accounts and data model → chunked uploads → processing worker with FFmpeg → URL import → transcription → moment detection and
scoring → rendering and framing → burned-in captions → editor-to-render sync → downloads/ZIP → operations. Details in
[PLAN.md](PLAN.md).
