# Análisis visual y reencuadre local

La detección con IA conserva las transcripciones y los originales de las fases anteriores. Actualiza las dependencias de Python antes de iniciar el servidor:

```powershell
.venv\Scripts\python.exe -m pip install -r local/requirements.txt
pnpm dev
```

En Linux o macOS, usa `.venv/bin/python` en el primer comando. Los modos por pausas y manuales con un encuadre fijo siguen disponibles. La preparación de llama.cpp, faster-whisper y Tesseract está en la [guía de detección semántica](semantic-analysis.md).

## Qué se analiza

- OpenCV YuNet detecta rostros y puntos faciales. Cuando hay marcas de habla, el movimiento de boca ayuda a elegir el rostro. La cercanía a la posición anterior y el suavizado reducen saltos. Un cambio de plano permite comenzar el seguimiento desde el nuevo sujeto.
- El seguimiento de sujeto usa el rostro o la zona con actividad visual. El modo de gameplay usa cambios de fotogramas en la zona del juego. Las evidencias de visión incluyen cambios de plano, actividad del juego y cambios faciales localizados.
- La detección gaming cruza el HUD, el movimiento, los picos de RMS y, si existe, la transcripción. Los perfiles de Fortnite, Minecraft, GTA V, Valorant, CS2 y Call of Duty agregan vocabulario específico. Las reglas genéricas siguen disponibles para otros juegos.
- Un texto como «Mission Completed» se interpreta como objetivo. Un rótulo de evento OCR necesita una señal de movimiento o audio próxima para producir una propuesta por reglas. Los picos RMS por sí solos se conservan como evidencia auxiliar. Los recortes de estas propuestas usan una rúbrica explícita a partir de las señales medidas.
- La selección del modelo conserva una línea central y comprueba que las citas y señales estén contenidas en el corte final. En frases, reacciones y opiniones extensas, busca comienzos y finales de oración más cercanos a la duración solicitada. Los relatos conservan su arco. Las propuestas demasiado amplias pierden puntuación de contexto y gancho de forma gradual. Los solapamientos y las repeticiones se descartan.
- La ficha usa como motivo una cita o una observación registrada. Las interpretaciones sin verificar del modelo se conservan únicamente en el archivo intermedio de evaluación. La puntuación orienta la revisión editorial. La calibración contra métricas de audiencia queda pendiente.

## Encuadres

| Opción                           | Comportamiento                                                                                                                                            |
| -------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Seguir rostro                    | Desplaza el recorte suavemente durante el plano. Con detecciones intermitentes conserva el último objetivo por un breve intervalo.                        |
| Seguir sujeto                    | Alterna entre rostro y actividad localizada.                                                                                                              |
| Recorte inteligente del gameplay | Muestra la acción seguida arriba y el original completo abajo para conservar la interfaz del juego.                                                       |
| Cámara arriba / juego abajo      | Prioriza una cara persistente en una esquina. Si detecta una persona integrada en la escena, usa ese recorte arriba y conserva la imagen completa abajo.  |
| Completo + desenfoque            | Conserva la imagen completa y rellena el espacio con un fondo difuminado. También sirve de respaldo si falta una cara para un encuadre facial o dividido. |
| Recorte manual                   | Los controles de posición horizontal y vertical fijan el centro del recorte.                                                                              |

Los formatos de exportación y las resoluciones de 720p y 1080p siguen disponibles. El encuadre se elige al crear el proyecto y se conserva al volver a exportar.

## Caché y aceleración

Las detecciones faciales, los rasgos de movimiento y los cambios de plano se guardan en ventanas de 30 s compartidas entre análisis y render. Las observaciones de OCR y audio usan su propia caché. Se conserva el flujo de codificación acelerada y el respaldo en CPU. YuNet funciona en CPU por defecto. `KLIPORA_VISION_DEVICE=opencl` intenta OpenCL si la compilación y el equipo lo soportan. El modelo YuNet se incluye con su licencia MIT. [OpenCV Zoo](https://github.com/opencv/opencv_zoo/tree/main/models/face_detection_yunet)

## Investigación de las muestras anteriores

En America’s Army, la fase 2 leyó «Mission Completed», pero el modelo sugirió una eliminación al interpretar un pico de audio. La propuesta carecía de confirmación visual de una eliminación y se descartó. En esta fase, el objetivo observado puede sembrar una propuesta competitiva sustentada en el HUD y un cambio medido de fotogramas. En Fantastic Contraption, los picos de audio y la cámara de realidad mixta requieren interpretar el contexto. La presencia de una cara o un aumento de volumen no certifica un fail.

El sistema identifica texto literal, actividad y proximidad temporal. Queda pendiente validar iconos de kill feed, semántica de acciones sin texto, reconocimiento acústico específico de gritos y diarización. Los perfiles son extensibles y todavía necesitan un corpus anotado por juego. Para las muestras y fuentes abiertas, consulta la [validación de la fase 2](semantic-analysis.md#material-de-prueba).

## Validación de la fase 3

Se reutilizaron los originales y los extractos documentados en la fase 2. La primera pasada procesó los cinco videos con YuNet, faster-whisper y Qwen2.5 1.5B en CPU. La segunda reprodujo las decisiones editoriales con las observaciones y los juicios reales guardados. La reexportación funcionó con llama-server detenido y sin Python en el ejecutor de recuperación.

| Muestra                       | Resultado observado                                                                                                                                                                                                                                                                                   |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Inside the FBI Podcast        | El clip pasó de 79,76 s a 23,84 s para una preferencia de 28 s. El nuevo corte va de 5,33 a 29,17 s, omite el fragmento de frase inicial y conserva el planteamiento y la explicación.                                                                                                                |
| Entrevista a George Monbiot   | El clip pasó de 63,56 s a 17,82 s. Va de 72,34 a 90,16 s y conserva la distinción entre objetividad e imparcialidad. Se corrigió una etiqueta original de humor sin respaldo.                                                                                                                         |
| Conversación de Pariamarca    | Se descartó una propuesta con puntuación editorial baja. El material y la transcripción permanecen disponibles para corte manual.                                                                                                                                                                     |
| Fantastic Contraption, Twitch | La propuesta de fail quedó por debajo del umbral. Se exportó además un corte de prueba con el encuadre dividido y se revisó el rostro de la persona arriba y la escena completa abajo.                                                                                                                |
| America’s Army                | Se evaluaron dos lecturas de «Mission Completed» y se exportó un corte competitivo de 10,38 s. El HUD permanece visible en la vista completa inferior del MP4 vertical. La lectura afirma que el texto aparece en pantalla. El instante exacto en que terminó el objetivo requiere anotación externa. |

Se cotejaron los fotogramas del MP4 con los de la fuente para medir el encuadre en dos extractos horizontales de la entrevista a Monbiot. La cara íntegra se mantuvo en 48 de 54 fotogramas comparables con seguimiento de rostro y en 41 de 48 con seguimiento de sujeto. El recorte centrado conservó íntegra la misma cara en 0 de 54 y 0 de 48, respectivamente. La posición del recorte se movió típicamente un 0,26 % del ancho por paso de muestreo, excluyendo los cambios de plano detectados. Son mediciones locales sobre dos extractos con el sujeto desplazado, con cajas delimitadas por YuNet.

En la pequeña muestra de gaming se revisó un clip competitivo exportado y se conservaron cero etiquetas de eliminaciones, victorias o fails. El conjunto sirve para verificar que un objetivo y un pico de audio se tratan como evidencias distintas. La precisión y la cobertura por videojuego requieren más eventos con verdad de referencia. Las pruebas se realizaron en Linux por CPU. La comprobación en Windows y GPU queda pendiente.
