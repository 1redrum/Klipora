# Editor local de clips

Abre un proyecto local y pulsa **Editar clip** en el resultado. El editor lee los tiempos y las palabras que se guardaron al generar el clip. Con un clip manual o uno anterior sin datos de palabras, puedes añadirlas en **Subtítulos**. Los tiempos del editor se expresan en segundos del video original.

## Edición y muestra

- La línea de tiempo muestra el recorte dentro del original. Ajusta inicio, fin y duración por separado o usa la posición del cursor. El cursor puede apuntar fuera del MP4 previo. En ese caso, **Previsualizar cambios** lee el tramo correspondiente desde el archivo original.
- **Video** ofrece volumen de 0 a 100 %, silencio y los encuadres locales, incluida la posición manual en ambos ejes.
- **Subtítulos** incluye Hormozi, MrBeast, Gaming, Karaoke y Minimalista. Puedes elegir fuente, tamaño, colores, énfasis, contorno, sombra, fondo, posición, animación y palabras por línea. Cada palabra se puede corregir, añadir, quitar, resaltar y retimar. Al ampliar el recorte, puedes añadir las palabras del tramo nuevo.
- **Textos** admite varias capas con tiempos, posición, tamaño y color propios. **Salida** guarda 720p o 1080p y 9:16, 16:9, 1:1 o 4:5.
- **Previsualizar cambios** genera hasta cuatro segundos a una resolución menor, con el mismo encuadre, pista de audio y motor ASS de la exportación. Una edición posterior marca la muestra como desactualizada. El editor conserva una sola muestra por clip y sustituye la anterior.

FFmpeg usa las fuentes incluidas con licencia SIL OFL. Las llaves y barras invertidas introducidas como texto se muestran con caracteres de ancho completo para evitar que se interpreten como instrucciones ASS. Para instalar en Windows, sigue la [guía local](local-processing.md) y usa un FFmpeg con `libass`, AAC y H.264.

## Guardado y exportación

El autoguardado escribe un JSON en el directorio privado del proyecto. La escritura se descarga al disco antes de reemplazar atómicamente el borrador. El navegador guarda una copia temporal de los cambios pendientes y permite recuperarlos después de cerrar la página. Si otra sesión editó el mismo borrador, la versión desactualizada se rechaza y el usuario puede recuperar sus cambios de manera explícita al volver a abrir el editor.

La exportación fija una instantánea del borrador y la añade a la cola local. Puedes cerrar la pestaña mientras se procesa y encontrar el resultado en el proyecto. El motor corta desde el original, incrusta los subtítulos y textos y aplica audio y encuadre. Repetir la exportación del mismo borrador reutiliza el MP4. Los clips históricos y las modificaciones del borrador siguen siendo accesibles por separado.

## Validación

Las pruebas se ejecutaron en Linux con CPU, Chromium, FFmpeg, libass, faster-whisper y llama.cpp local. Se reutilizaron los [videos reales de la fase 2](semantic-analysis.md#material-de-prueba).

| Prueba                             | Resultado                                                                                                                                                                                                                                                             |
| ---------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Edición y persistencia en Chromium | Se abrió un clip del podcast generado en la fase 3. Se cambiaron recorte, volumen, encuadre, texto, estilo, palabra, tiempo y resaltado. Se recuperaron tras recargar y se descargó el MP4 editado.                                                                   |
| Recuperación en disco              | Tras reiniciar el servidor con llama-server detenido, se leyó el mismo borrador y se volvió a generar la muestra. Se comprobó el rechazo de escrituras concurrentes desactualizadas y la reutilización de una exportación idéntica.                                   |
| Estilos y formatos                 | Se inspeccionaron fotogramas de los cinco estilos sobre la entrevista. Las muestras cubrieron 9:16, 16:9, 1:1 y 4:5. Se verificaron el clip final cuadrado de 720p y el de 1080p en 16:9 silenciado.                                                                  |
| Audio y tiempos                    | En un recorte real de 6,52 s, la señal de audio exportada se alineó con la original a 16 kHz. El volumen al 43 % redujo el RMS en 7,33 dB. El resaltado karaoke cambió alrededor de la marca de la palabra «by», a 1,12 s de la muestra.                              |
| Regresión de las fases anteriores  | Una nueva entrevista recorrió la importación, Whisper y la exportación por pausas. La detección con llama.cpp exportó un momento de otro proyecto de entrevista. El flujo de gaming exportó un objetivo de America’s Army. También se comprobó un corte manual nuevo. |

Windows y la aceleración GPU quedan pendientes de una prueba en ese equipo.
