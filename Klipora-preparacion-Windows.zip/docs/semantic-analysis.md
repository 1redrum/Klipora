# Detección de momentos en local

La [fase 3](visual-analysis.md) documenta el análisis de video y las mejoras editoriales. Los resultados de prueba de esta página corresponden a la fase 2.

Klipora ofrece tres flujos al crear un proyecto. **Detectar momentos con IA** usa un modelo de lenguaje en el equipo. **Fragmentos hablados** conserva el flujo de transcripción y segmentación por pausas. **Cortes manuales** funciona con FFmpeg. Los proyectos anteriores mantienen su comportamiento y sus archivos.

## Preparación en Windows

Sigue la [instalación local](local-processing.md) para Node, FFmpeg y faster-whisper. Para la detección semántica, arranca además un servidor de inferencia local y mantenlo abierto mientras se procesan los proyectos. La descarga inicial del modelo necesita conexión. La inferencia posterior funciona en el equipo sin cuenta ni clave API.

### llama.cpp

Descarga la distribución de llama.cpp para Windows compatible con tu equipo y un modelo GGUF instruct multilingüe. Qwen2.5 1.5B Instruct funciona como punto de partida en CPU. Un modelo mayor, como Qwen2.5 7B Instruct cuantizado, requiere más RAM o VRAM y es una opción para evaluar precisión. [Binarios de llama.cpp](https://github.com/ggml-org/llama.cpp/releases) · [Qwen2.5 1.5B GGUF](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF)

En PowerShell, desde la carpeta del ejecutable:

```powershell
.\llama-server.exe -m "C:\Modelos\qwen2.5-1.5b-instruct-q4_k_m.gguf" --alias klipora --host 127.0.0.1 --port 8080 -c 8192 -ngl 0
```

Con un binario y controladores de GPU compatibles, aumenta `-ngl` según la VRAM disponible. `-ngl 0` ejecuta el modelo en CPU. Inicia `pnpm dev` desde el proyecto en otra terminal. La dirección predeterminada es `http://127.0.0.1:8080` y el alias predeterminado es `klipora`.

### Ollama

Si ya usas Ollama, puedes utilizar su servidor local compatible con Chat Completions y salida estructurada en JSON. Configura el nombre del modelo instalado. Si tu modelo tiene un contexto pequeño y la tarea se queda sin espacio, aumenta su contexto a 8192 en Ollama o elige otro modelo. La integración de referencia se verificó con llama.cpp. [Compatibilidad de Ollama](https://docs.ollama.com/api/openai-compatibility)

```powershell
ollama pull qwen2.5:1.5b
$env:KLIPORA_LLM_URL = "http://127.0.0.1:11434"
$env:KLIPORA_LLM_MODEL = "qwen2.5:1.5b"
pnpm dev
```

### OCR para gaming

Instala Tesseract 5 con los datos de inglés (`eng`) y agrégalo a PATH, o configura la ruta al ejecutable. Para juegos con HUD en español instala también `spa`. [Instalación de Tesseract](https://tesseract-ocr.github.io/tessdoc/Installation.html)

```powershell
$env:KLIPORA_TESSERACT = "C:\Program Files\Tesseract-OCR\tesseract.exe"
$env:KLIPORA_OCR_LANG = "eng+spa"
```

## Cómo selecciona

- **Automático** clasifica el proyecto a partir del título, la plataforma y muestras de la transcripción. **Contenido general** y **Gaming y streaming** permiten elegir el motor. Forzar gaming es útil para grabaciones sin habla o con poco vocabulario de juego.
- faster-whisper almacena palabras con tiempos absolutos en ventanas. El modelo analiza intervalos de 90 segundos con hasta 25 segundos de contexto por lado y propone una categoría, seis puntuaciones y referencias con las que se obtienen los tiempos reales, la evidencia y los límites del clip. El valor de duración en la interfaz orienta al modelo. Una exportación manual puede abarcar cualquier intervalo admitido por el archivo.
- En gaming, FFmpeg extrae un fotograma cada tres segundos para OCR y mide picos RMS relativos al nivel habitual de la ventana. El modelo recibe estos datos junto a la transcripción. Las eliminaciones, victorias y derrotas requieren texto visual compatible. Un pico de volumen por sí solo no genera clips.
- El ejecutor valida las citas y sus tiempos, ajusta al habla cuando corresponde, ordena por puntuación y quita solapamientos o repeticiones léxicas. La ficha muestra las seis dimensiones, la razón del modelo y la evidencia observada. El 1–100 combina los juicios del modelo con el respaldo de las señales y estima potencial editorial. No se ha calibrado contra reproducciones reales.
- Se guardan por separado transcripción, clasificación, señales y resultados de cada ventana. Los trabajos retoman estos puntos al reiniciar o reintentar. Para comparar otro modelo en un trabajo nuevo, usa un alias distinto. Los clips mantienen los subtítulos sincronizados y las exportaciones 720p/1080p.

## Alcance de la validación

La evaluación manual revisa si la cita o el HUD respaldan el evento y si el recorte tiene sentido por sí solo. Se usan extractos reales y se informa cuando una muestra no produce resultados. Las pruebas de referencia se ejecutan en Linux con inferencia en CPU, por lo que aún queda comprobar Windows y el rendimiento con GPU.

El OCR muestrea fotogramas y depende de la legibilidad del texto. Queda pendiente evaluar kill feeds que solo muestran iconos, detección de gestos en cámara y eventos acústicos como risas o gritos sin texto. El reconocimiento general de movimientos y situaciones visuales, la calibración de puntuaciones y la evaluación amplia por juego también siguen pendientes.

## Material de prueba

Se importaron archivos de Commons incluidos extractos procedentes de YouTube y Twitch. Los tiempos de la tabla se refieren a los archivos originales, antes de crear el proyecto. El archivo de gameplay se procesó completo.

| Material                    | Extracto                  | Modo                                                                                                                                          |
| --------------------------- | ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| Entrevista a George Monbiot | 00:27–02:12               | Automático. [Fuente](https://commons.wikimedia.org/wiki/File:George_Monbiot_interview_with_The_Green_Interview.webm)                          |
| Inside the FBI Podcast      | 01:40–03:00               | General. [Fuente](https://commons.wikimedia.org/wiki/File:Inside_the_FBI_Podcast_%E2%80%93_Top_Ten_Fugitive_Yulan_Adonay_Archaga_Carias.webm) |
| Entrevista Pariamarca       | 00:06–00:58               | Automático, español. [Fuente](https://commons.wikimedia.org/wiki/File:Entrevista_Pariamarca.webm)                                             |
| Backstage with Basia        | 00:57–01:52               | General, copia de YouTube. [Fuente](<https://commons.wikimedia.org/wiki/File:Backstage_with_Basia_-_YouTube_(360p).webm>)                     |
| Fantastic Contraption       | 00:39–01:29               | Gaming, grabación de Twitch. [Fuente](https://commons.wikimedia.org/wiki/File:Fantastic_Contraption_-_Lindsay%27s_wall_hugger.webm)           |
| America's Army              | 01:08, grabación completa | Gaming. [Fuente](https://commons.wikimedia.org/wiki/File:AA33_Pipeline_AssaultDefend_Failed_20130123_720p.ogv)                                |

La prueba de referencia se ejecutó con llama.cpp b12483, Qwen2.5 1.5B Instruct Q4_K_M y faster-whisper `tiny`, por CPU. Los seis trabajos terminaron. La tabla cuenta momentos distintos, de modo que la versión en otra resolución no suma un momento.

| Muestra                | Candidatos | Momentos exportados | Observación                                                                                                                                                        |
| ---------------------- | ---------: | ------------------: | ------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| George Monbiot         |          2 |                   1 | El modelo seleccionó una intervención de la entrevista.                                                                                                            |
| Inside the FBI Podcast |          1 |                   1 | El origen de la pandilla está en el audio. La selección abarcó casi todo el extracto de 80 s aunque se eligieron 28 s como orientación.                            |
| Pariamarca             |          1 |                   1 | Seleccionó una intervención de la conversación. La etiqueta de humor requiere revisión humana.                                                                     |
| Backstage with Basia   |          1 |                   1 | El recorte incluye el título del álbum y el recuerdo de Chicago. El modelo vinculó ambos incorrectamente en su interpretación. Se verificó el MP4 en 720p y 1080p. |
| Fantastic Contraption  |          0 |                   0 | Se registraron picos de audio. El modelo se abstuvo de seleccionar un clip.                                                                                        |
| America's Army         |          1 |                   0 | El OCR leyó «Mission Completed». La selección rechazó la propuesta de eliminación porque ese texto acredita un objetivo.                                           |

Los casos muestran que el respaldo literal de una cita y su tiempo se pueden verificar, mientras que la etiqueta, la interpretación y la puntuación requieren una revisión editorial. La validación de selecciones positivas de eliminaciones, victorias y fails en distintos juegos queda pendiente.

Se verificó la recuperación con una copia de la entrevista de Monbiot interrumpida antes de exportar. El servidor reexportó el mismo clip desde dos ventanas persistidas, con llama-server detenido y sin un intérprete de Whisper disponible. Chromium verificó el selector de motor, el detalle de puntuación y evidencia y la descarga de un clip real.
