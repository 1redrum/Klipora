# Fase 6 · validación de Windows y GPU

## Estado

**Windows 10, Windows 11 y el uso de una GPU física quedan pendientes de ejecución.** El entorno asignado es Linux x86-64 y carece de un host Windows y de dispositivos de GPU expuestos. El procedimiento de este documento está preparado para recoger evidencia en Windows. Los resultados que se obtuvieron en Linux se identifican por separado.

## Instalar desde cero en Windows

1. Instala Node.js 22.13+ en la rama 22 o Node.js 24, pnpm 10.26 o posterior de la rama 10 y Python 3.12 x64 con el lanzador `py`. Extrae el ZIP a una ruta de tu usuario. Abre PowerShell en esa carpeta. [Node.js](https://nodejs.org/en/download) · [pnpm](https://pnpm.io/installation) · [Python](https://www.python.org/downloads/windows/)
2. Instala FFmpeg y añade al PATH la carpeta que contiene `ffmpeg.exe` y `ffprobe.exe`. Inicia otra consola para leer el PATH actualizado. Usa una compilación con libx264, AAC y el filtro `subtitles` con libass. En un equipo NVIDIA, comprueba también `h264_nvenc`. [FFmpeg para Windows](https://ffmpeg.org/download.html#build-windows)
3. Para Gaming, instala Tesseract con los datos de inglés y, si corresponde, español. Pon el ejecutable en PATH o especifica su ruta mediante `KLIPORA_TESSERACT`. Para la detección semántica, prepara llama.cpp u Ollama según la [guía de análisis](semantic-analysis.md). [Tesseract](https://tesseract-ocr.github.io/tessdoc/Installation.html)
4. Si una biblioteca nativa falla con un mensaje de carga de DLL, verifica que Python y la biblioteca sean x64 e instala el redistribuible Visual C++ v14 x64 si falta. Usa los instaladores oficiales para las DLL del sistema. [Microsoft Visual C++ Redistributable](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist)
5. Para probar CUDA en Whisper, instala las bibliotecas NVIDIA compatibles con la versión de CTranslate2 que instales y añádelas al PATH. El controlador puede detectar la tarjeta incluso cuando las DLL necesarias para ejecutar el modelo falten. [Dependencias GPU de faster-whisper](https://github.com/SYSTRAN/faster-whisper#gpu)

```powershell
node --version
pnpm.cmd --version
py -3.12 --version
ffmpeg -version
ffprobe -version
ffmpeg -hide_banner -filters | Select-String '\bsubtitles\b'
ffmpeg -hide_banner -encoders | Select-String '\b(libx264|h264_nvenc)\b'

pnpm.cmd install --frozen-lockfile
py -3.12 -m venv .venv
$env:KLIPORA_PYTHON = (Resolve-Path ".venv\Scripts\python.exe").Path
& $env:KLIPORA_PYTHON -m pip install -r local/requirements.txt

$env:KLIPORA_STORAGE = Join-Path $env:LOCALAPPDATA "Klipora datos"
New-Item -ItemType Directory -Path $env:KLIPORA_STORAGE -Force | Out-Null
$env:KLIPORA_MODEL = "small"
pnpm.cmd dev
```

Abre http://127.0.0.1:3000. Para volver a iniciar, abre PowerShell **en la raíz del proyecto** y configura el entorno. El servidor y el diagnóstico buscan `local/child-guard.mjs` y los recursos locales desde esa carpeta. Las rutas absolutas se pueden escribir entre comillas. No hace falta activar el entorno virtual ni cambiar la política de ejecución para usar `pnpm.cmd`.

```powershell
$env:KLIPORA_PYTHON = (Resolve-Path ".venv\Scripts\python.exe").Path
$env:KLIPORA_STORAGE = Join-Path $env:LOCALAPPDATA "Klipora datos"
pnpm.cmd dev
```

Usa el mismo directorio de datos para recuperar los trabajos. Comprueba que puedes escribir en el directorio del proyecto, en el almacenamiento y en `$env:TEMP`. El servidor escucha en `127.0.0.1` y el comando `dev` utiliza el puerto 3000 en modo estricto. Si aparece `Address already in use`, identifica el proceso con `Get-NetTCPConnection -LocalPort 3000 -State Listen`. Cierra Klipora con Ctrl+C en la consola donde lo iniciaste y espera a que vuelva el prompt. Cerrar la pestaña deja el servidor activo. llama-server u Ollama se detienen desde su propia consola.

El archivo `local/requirements.txt` instala faster-whisper 1.2.1, PyAV, OpenCV sin interfaz gráfica y yt-dlp. CTranslate2 se instala como dependencia de faster-whisper. YuNet y las fuentes del editor se incluyen en el proyecto. Whisper descarga el modelo en el primer uso si aún falta. Para trabajar sin conexión después de preparar el modelo, apunta `KLIPORA_MODEL` a una carpeta local de CTranslate2 para Whisper. El modelo GGUF del servidor semántico se descarga por separado.

`pnpm-workspace.yaml` autoriza la compilación de `esbuild` fijado en `pnpm-lock.yaml`. Si la instalación anuncia otro script bloqueado, guarda el mensaje y revisa el paquete antes de autorizarlo.

## Prueba reproducible del dispositivo

Selecciona un archivo propio que tenga voz clara en sus primeros 15 segundos. Ejecuta desde la carpeta del proyecto, con el mismo intérprete y modelo del servidor:

```powershell
node --experimental-strip-types local/verify-device.ts "C:\Videos\Grabación de prueba.mp4" |
  Set-Content -Encoding utf8 "$env:TEMP\klipora-diagnóstico.json"
```

La prueba usa el ejecutor de Klipora. Copia el archivo a un directorio temporal con un nombre acentuado, transcribe un extracto y exporta MP4 en 720p y 1080p. El informe JSON queda en la ruta indicada en el comando. Comprueba `$LASTEXITCODE` en la consola y revisa el estado de cada prueba del JSON. Se necesitan palabras transcritas para dar por válida la prueba de Whisper.

| Evidencia                       | Significado                                                                                                                                                                    |
| ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Adaptadores de Windows          | Inventario y versión del controlador que informa Windows.                                                                                                                      |
| Contador CUDA                   | Número de dispositivos que ve CTranslate2.                                                                                                                                     |
| NVENC en la compilación         | El binario incluye el codificador. Un valor verdadero por sí solo no certifica el controlador ni el uso de la GPU.                                                             |
| Dispositivo de la transcripción | `CUDA · float16` solo se informa después de transcribir. Si se utilizó CPU, aparece el motivo del respaldo cuando se intentó CUDA.                                             |
| Dispositivo de cada exportación | El controlador se prueba con un fotograma y el informe registra el codificador que terminó el MP4. `CPU · libx264` incluye el motivo registrado si se descartó la aceleración. |

Para comparar los tres modos con el mismo archivo, ejecuta este bloque en una consola de diagnóstico separada. Define allí `KLIPORA_PYTHON` como en el arranque y ajusta la ruta de `$video`. Los cambios de entorno de esa consola no modifican el servidor que ya está abierto.

```powershell
$video = "C:\Videos\Grabación de prueba.mp4"
$logs = Join-Path $env:LOCALAPPDATA ("Klipora registros " + (Get-Date -Format yyyyMMdd-HHmmss))
New-Item -ItemType Directory -Path $logs -Force | Out-Null

function Guardar-Diagnostico([string]$modo) {
  & node --experimental-strip-types local/verify-device.ts $video 2> (Join-Path $logs "$modo.stderr.log") |
    Set-Content -Encoding utf8 (Join-Path $logs "$modo.json")
  $codigo = $LASTEXITCODE
  "Código de salida: $codigo" | Set-Content -Encoding utf8 (Join-Path $logs "$modo.exit.txt")
}

Remove-Item Env:KLIPORA_DEVICE, Env:KLIPORA_ENCODER, Env:KLIPORA_VISION_DEVICE -ErrorAction SilentlyContinue
Guardar-Diagnostico "automatico"

$env:KLIPORA_DEVICE = "cpu"
$env:KLIPORA_ENCODER = "cpu"
Guardar-Diagnostico "cpu"

$env:KLIPORA_DEVICE = "cuda"
$env:KLIPORA_ENCODER = "h264_nvenc"
Guardar-Diagnostico "nvidia"
```

El diagnóstico usa un extracto de hasta 15 segundos y revisa el retorno del ejecutor. `status: ok` en un inventario indica que la consulta se ejecutó. Revisa el valor del contador CUDA y, por separado, el campo `device` de Whisper y de cada exportación. Una exportación que termina en `CPU · libx264` aprueba el respaldo en CPU. La prueba de NVENC queda pendiente o fallida según el motivo registrado.

## Recopilar errores y registros

En la consola donde arrancas Klipora, crea un directorio de registros y captura la salida antes de reproducir el fallo:

```powershell
$logs = Join-Path $env:LOCALAPPDATA ("Klipora servidor " + (Get-Date -Format yyyyMMdd-HHmmss))
New-Item -ItemType Directory -Path $logs -Force | Out-Null
& {
  Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber
  Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion
  node --version
  pnpm.cmd --version
  ffmpeg -version
  ffprobe -version
  & $env:KLIPORA_PYTHON -m pip freeze
  Get-Command node,pnpm.cmd,ffmpeg,ffprobe -ErrorAction Continue | Select-Object Name,Source
} 2>&1 | Out-File -Encoding utf8 (Join-Path $logs "entorno.log")
pnpm.cmd dev 2>&1 | Tee-Object -FilePath (Join-Path $logs "servidor.log")
```

- Si falla una tarea, anota qué estabas haciendo, la hora, el mensaje de la ficha y el identificador del proyecto que aparece en la URL. El manifiesto está en `$env:KLIPORA_STORAGE\<id>\project.json`. Guarda ese JSON si existe, y los registros del diagnóstico si interviene GPU. Si falla el análisis semántico, guarda por separado la salida de llama-server u Ollama.
- Si falla una instalación, conserva el comando y el error de `pnpm.cmd install --frozen-lockfile` o de `python.exe -m pip install -r local/requirements.txt`. `pip freeze` ayuda a identificar versiones transitivas como CTranslate2. Si falta un ejecutable, registra la ruta que muestra `Get-Command` o el mensaje de que el comando no existe.
- Si falla un guardado o un renombrado, registra la ruta de almacenamiento y el espacio libre. Usa una carpeta local escribible por tu usuario y verifica si otro proceso la está bloqueando. Evita abrir dos servidores con el mismo almacenamiento.
- Si el navegador muestra un error que no aparece en la consola, conserva el texto de la consola del navegador y el código HTTP de la petición fallida en **Red**. Revisa rutas, nombres, URLs y datos personales antes de compartir registros. Los videos, los modelos y los temporales pueden quedarse en tu equipo.

## Fallos probables antes de la primera prueba

| Mensaje o síntoma                                                      | Qué revisar                                                                                                                                                                             |
| ---------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `py -3.12` no encuentra Python                                         | Instala Python 3.12 x64 con el lanzador `py`. Si eliges configurar el intérprete por ruta, usa el ejecutable del entorno virtual y guarda su ruta absoluta en `KLIPORA_PYTHON`.         |
| `DLL load failed`, código 126 o error importando `cv2` o `ctranslate2` | Comprueba arquitectura x64, el redistribuible Visual C++ y el intérprete que muestra `KLIPORA_PYTHON`. Repite la importación desde ese mismo ejecutable.                                |
| NVENC figura en FFmpeg pero el render usa CPU                          | Consulta el motivo en el JSON. Verifica que el modelo de tarjeta admita codificación H.264 con NVENC y que el controlador sea compatible con la compilación instalada.                  |
| CUDA detecta una GPU pero Whisper informa CPU                          | Revisa el motivo de respaldo y las bibliotecas CUDA/cuDNN que exige la versión de CTranslate2 registrada en `pip freeze`.                                                               |
| `No such filter: subtitles` o falta `libx264`                          | Cambia a una compilación de FFmpeg que incluya libass y libx264. Comprueba `Get-Command ffmpeg` por si hay otra versión antes en PATH.                                                  |
| `EPERM`, `EACCES` o `WinError 206`                                     | Comprueba escritura en proyecto, almacenamiento y TEMP. Si la ruta es muy larga, prueba una carpeta local más corta bajo tu usuario. Registra el archivo y la ruta que causan el error. |

## Recorrido funcional pendiente en Windows

| Prueba                        | Evidencia a recoger                                                                                                                                                  |
| ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Arranque y archivo            | Edición y compilación de Windows, versiones de dependencias, puerto local y carga de un archivo con nombre acentuado.                                                |
| Transcripción y generación    | Texto y un clip producido desde voz clara. Anota el dispositivo informado por el trabajo.                                                                            |
| Semántica general y gaming    | Una entrevista o podcast con habla, y una grabación de juego con un objetivo identificable. Registra justificación y tiempos o la decisión de descartar el momento.  |
| Seguimiento visual            | Revisa un clip vertical con una persona que se desplaza y comprueba el encuadre antes y después de un cambio de plano.                                               |
| Editor, subtítulos y formatos | Cambia una palabra y un texto, revisa los cinco estilos y las cuatro relaciones, cierra y abre la página y exporta en 720p y 1080p.                                  |
| Recuperación                  | Cierra el servidor durante transcripción o render, vuelve a iniciarlo con el mismo almacenamiento y verifica estado, reutilización de caché y cantidad final de MP4. |
| Video largo                   | Usa un video con audio que cruce los cinco minutos. Revisa más de una ventana de Whisper y el resultado después de reiniciar.                                        |

Repite el recorrido por separado en Windows 10 y Windows 11. Registra cada caso como ejecutado con éxito, fallido o pendiente. Para un fallo, conserva el mensaje exacto, el paso y las versiones. Los resultados de Linux de la fase anterior están en [estabilidad](stability.md).

## Evidencia de esta fase en Linux

- Entorno Linux 6.18.57 x86-64, Node 24.22.1, Python 3.12.14, FFmpeg 7.1.5, CTranslate2 4.9.0, faster-whisper 1.2.1 y OpenCV 4.14.0. El inventario y los resultados del diagnóstico están en [phase6-linux-results.json](phase6-linux-results.json).
- Con CUDA y NVENC solicitados, CTranslate2 vio cero dispositivos. Whisper produjo 29 palabras de un extracto real de entrevista de 14,01 s con CPU INT8. La compilación incluía NVENC y su prueba falló al cargar `libcuda.so.1`. Ambos MP4 conservaron audio y se exportaron con `libx264` en CPU.
- El servidor local arrancó con un directorio de datos acentuado, importó el archivo, generó un corte 4:5 y devolvió el motivo del respaldo en los datos del clip. El cierre por SIGINT terminó con código 130.
- La corrección registra la causa del respaldo de FFmpeg y evita atribuir a una GPU un codificador personalizado cuyo dispositivo no se puede confirmar. Pasaron la comprobación de tipos, la compilación y las 42 pruebas automatizadas.

Las pruebas de esta sección se limitan a Linux. Las celdas del recorrido funcional de Windows quedan pendientes.

## Revisión previa a la primera ejecución

La configuración de pnpm aún tenía el texto provisional `set this to true or false` para esbuild. Se sustituyó por una autorización explícita para ese paquete y se conservó el lockfile. Se ejercitó una instalación limpia con pnpm 10.34.9, el arranque de la API y el cierre por SIGINT en Linux.

Se repitió el diagnóstico con CPU forzada, con CUDA y NVENC solicitados y con un archivo inexistente. Los dos primeros recorridos registraron transcripción y MP4 de 720 × 1280 y 1080 × 1920. En la prueba NVIDIA, ambos volvían a CPU. El archivo inexistente produjo un JSON de error y código de salida 1. Estos pasos comprueban la reproducibilidad del procedimiento en Linux. El uso de PowerShell, las DLL de Windows y la aceleración física quedan pendientes.
