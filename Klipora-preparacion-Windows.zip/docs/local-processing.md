# Procesamiento local

Klipora guarda originales, proyectos, transcripciones y clips en el disco del equipo. El servidor escucha en `127.0.0.1`. No requiere cuenta, claves API ni almacenamiento externo.

## Iniciar

Requisitos del equipo: Node.js 22.13 o superior en la rama 22, Node.js 24 o superior según `package.json`, pnpm 10.26 o posterior de la rama 10, Python 3.10 o superior para transcripción e importación por enlace, y FFmpeg con `ffprobe`, `libx264`, AAC y el filtro `subtitles` (libass) disponibles en PATH.

Desde la raíz del proyecto, instala las dependencias de la interfaz.

```sh
pnpm install --frozen-lockfile
```

Para transcribir o importar por enlace, instala las dependencias de Python en un entorno virtual. En macOS o Linux:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r local/requirements.txt
pnpm dev
```

En PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\python.exe -m pip install -r local/requirements.txt
$env:KLIPORA_PYTHON = (Resolve-Path .venv\Scripts\python.exe).Path
pnpm dev
```

Abre http://127.0.0.1:3000/app/new. Los cortes manuales desde un archivo funcionan con FFmpeg sin instalar Python. El modo de fragmentos hablados descarga el modelo Whisper la primera vez. Con el modelo en caché o en una carpeta local, la inferencia puede hacerse sin conexión. Las plataformas pueden bloquear descargas por enlace o cambiar sus formatos. En ese caso, importa el archivo original.

## Trabajos y archivos

- El archivo se transfiere por flujo directo a disco. Mantén la página abierta hasta que aparezca el proyecto. Si interrumpes esa transferencia, vuelve a seleccionar el archivo y a enviarlo.
- Una vez guardado, puedes cerrar o recargar el navegador. Deja `pnpm dev` ejecutándose para que el equipo siga trabajando. Al reiniciar el servidor con el mismo directorio de datos, los trabajos interrumpidos se encolan de nuevo y reutilizan ventanas ya transcritas y clips guardados.
- Los fallos se muestran en el proyecto. Tras resolver la causa, usa **Reintentar**. El trabajo no se borra al fallar. Para liberar almacenamiento, elimina un proyecto explícitamente desde su página o cambia el directorio de datos.
- Los fragmentos hablados se separan por pausas y cierres de frase. Cada clip transcrito lleva subtítulos incrustados. También puedes indicar inicio y fin manualmente. La página permite reproducir, descargar y volver a exportar clips en 720p o 1080p.
- El original y los resultados se mantienen hasta que elimines el proyecto. Para hacer una copia de seguridad, detén el servidor y copia el directorio de datos.

## Configuración opcional

| Variable          | Comportamiento                                                                                                                                                                                     |
| ----------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `KLIPORA_STORAGE` | Directorio de datos. Por defecto, `.klipora`. Usa una sola instancia del servidor por directorio.                                                                                                  |
| `KLIPORA_WORKERS` | Trabajos simultáneos. Por defecto, uno para conservar RAM y VRAM. Otros proyectos quedan en cola sin caducidad.                                                                                    |
| `KLIPORA_PYTHON`  | Ruta al intérprete con las dependencias instaladas.                                                                                                                                                |
| `KLIPORA_MODEL`   | Modelo de faster-whisper o ruta local. El predeterminado es `small`. Fija el modelo antes de importar y mantenlo durante la recuperación.                                                          |
| `KLIPORA_DEVICE`  | `cpu` fuerza INT8 por CPU. La configuración automática intenta CUDA y recurre a CPU cuando falla.                                                                                                  |
| `KLIPORA_ENCODER` | Codificador H.264 de FFmpeg. Se intenta VideoToolbox en macOS, NVENC/QSV si se detecta el dispositivo en Linux, y NVENC/QSV/AMF en Windows. El render usa `libx264` si el intento acelerado falla. |

La [guía de detección semántica](semantic-analysis.md) describe la integración local con modelos de lenguaje y OCR para gaming. Para evaluar su calidad, el repositorio conserva los contratos de clasificación y selección y sus pruebas. YuNet en OpenCV es una opción local para detectar rostros antes de añadir seguimiento y reencuadre. El flujo de fragmentos hablados segmenta por pausas y frases. Ambos flujos ofrecen recorte centrado y fondo desenfocado.
