# Fase 5 · estabilidad y verificación local

## Correcciones

- Los procesos multimedia ejecutados por Klipora quedan vinculados al servidor. El cierre ordenado cancela operaciones activas y espera a que finalicen. Si desaparece el servidor durante un render, el supervisor del proceso detecta la desconexión y detiene el codificador. Los trabajos pendientes permanecen en disco.
- Los renders y el audio intermedio se aíslan en directorios de trabajo propios. Los archivos finales se publican por reemplazo y los manifiestos se sincronizan antes del reemplazo. En Windows, un bloqueo transitorio durante un renombrado recibe varios reintentos antes de mostrar el error.
- Un render interrumpido se limpia automáticamente cuando su supervisor registró que el codificador ya cerró. Los temporales sin esa confirmación se conservan. Esta distinción también aplica si se corta la energía y desaparecen tanto el servidor como el supervisor.
- Repetir un corte manual idéntico o una variante idéntica reutiliza su identificador y su MP4. Se conservan los checkpoints compatibles de Whisper, visión y análisis. Los checkpoints antiguos pueden aparecer como caché con dispositivo sin registro.
- FFmpeg prueba un fotograma con cada codificador acelerado disponible antes de elegirlo. Una prueba o un render fallido hace que Klipora pruebe otra opción y finalmente use `libx264` en CPU. Whisper consulta CUDA y recurre a CPU INT8 si la GPU falta o falla. YuNet comprueba un dispositivo OpenCL y conserva CPU como respaldo. La ficha del proyecto muestra los dispositivos registrados. La API del modelo local no proporciona una confirmación portátil de GPU y la ficha identifica el servidor de inferencia como responsable de ese dispositivo.
- Se evita pasar los comandos multimedia por un shell. Python usa UTF-8 para los argumentos y los datos que recibe por tubería. Los temporales de FFmpeg usan nombres relativos al directorio privado del proyecto.

## Pruebas realizadas en Linux

| Prueba                        | Resultado                                                                                                                                                                                                                                                                                                               |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Vídeo de 10 min 15 s          | Material real repetido y audio real en dos bloques separados por silencio para cruzar el límite de ventana. Whisper escribió las ventanas de 0, 300 y 600 s. Se detuvo el servidor durante el trabajo, se volvió a iniciar y se conservaron la marca de modificación de la primera ventana y los dos clips resultantes. |
| Entrada de tres horas         | Se importó un contenedor sintético de 10 800 s y se exportaron sus últimos seis segundos en 720 × 900. Se verificó la búsqueda cerca del EOF y el corte, sin ejecutar una transcripción completa de tres horas.                                                                                                         |
| Cierre abrupto durante FFmpeg | Tras `SIGKILL`, el supervisor y el codificador dejaron de ejecutarse. El reinicio recuperó el identificador pendiente y produjo un solo MP4 de 75 s en 1080 × 1080. Se limpió el temporal confirmado y se conservó un directorio de prueba sin confirmación.                                                            |
| Cierre ordenado               | `SIGTERM` durante la transcripción detuvo cuatro descendientes observados. `SIGINT` cerró el servidor con código 130.                                                                                                                                                                                                   |
| GPU solicitada sin hardware   | NVENC estaba compilado en FFmpeg. El fotograma de prueba falló por ausencia de CUDA. Con NVENC y CUDA solicitados, el proyecto real siguió con `CPU · libx264` y `CPU · int8`. También se ejecutó un recorrido con CPU forzada.                                                                                         |
| Memoria                       | Pico agregado observado del servidor y sus descendientes durante el ensayo de recuperación: aproximadamente 909 MiB de RSS. Se excluyó llama-server, ejecutado como servicio local aparte. Las muestras de RSS son un ensayo acotado, con memoria compartida potencialmente contabilizada más de una vez.               |
| Directorios de datos          | Se probó el servidor, Python y FFmpeg con espacios y caracteres acentuados. El recorrido de regresión también usó apóstrofos en la ruta.                                                                                                                                                                                |

Los recortes, originales y archivos de prueba permanecieron en el disco del entorno de prueba. La prueba de cierre abrupto se ejecutó sobre un servidor aislado.

## Regresiones funcionales

En Linux se ejecutaron Node 24.22.1, FFmpeg 7.1.5, Python 3.12.14, CTranslate2 4.9.0 y OpenCV 4.14.0. Los detectores devolvieron cero dispositivos CUDA y OpenCL no disponible.

- **Whisper y análisis.** Una entrevista nueva produjo un clip con el flujo por pausas y otro con el flujo semántico de llama.cpp. Una nueva importación de America’s Army produjo el clip de objetivo, registró OCR y visión, y exportó la variante vertical de 1080 × 1920. Las tres ventanas de visión conservaron sus marcas de modificación. Repetir la misma variante reutilizó el MP4.
- **Edición.** Chromium abrió un clip histórico, ajustó recorte, audio y encuadre, editó palabras y textos, recuperó el borrador tras recargar y descargó el MP4. Se volvieron a generar e inspeccionar fotogramas de los cinco estilos en las cuatro relaciones de aspecto. Se confirmó la exportación silenciosa de 1080p y la exportación cuadrada de 720p.
- **Trabajos consecutivos.** Se completaron seis cortes manuales seguidos y se verificó que repetir cada petición no añadía otro MP4. Tras cada corte se registraron cero descendientes activos y el RSS en reposo del servidor pasó de 537 636 a 537 952 KiB. Esto cubre una serie corta de resistencia. Queda pendiente una prueba de varios días.
- **Caché recuperable.** Se restauró la selección semántica desde una copia de un trabajo real, con llama-server detenido y sin intérprete Python disponible para dicho servidor. Se reconstruyó el MP4 con el mismo identificador, se mantuvieron intactos cinco archivos de caché y el editor leyó un borrador histórico de disco.
- **Automatización.** Pasaron la compilación, la comprobación de tipos y las 42 pruebas. El lint de los módulos modificados pasa. El lint global reporta tres errores previos y el formato global reporta 52 archivos previos.

## Windows 10 y Windows 11

Esta fase se ejecutó en Linux, en un entorno sin una máquina Windows ni una GPU accesible. Las rutas, la gestión de procesos y el código de respaldo de Windows se revisaron. Queda pendiente ejecutar en ambos sistemas y medir rendimiento sobre hardware real.

Desde PowerShell, en la raíz del proyecto:

```powershell
node --version
pnpm --version
ffmpeg -version
ffprobe -version
ffmpeg -hide_banner -filters | Select-String subtitles
py -m venv .venv
$env:KLIPORA_PYTHON = (Resolve-Path ".venv\Scripts\python.exe").Path
& $env:KLIPORA_PYTHON -m pip install -r local/requirements.txt
& $env:KLIPORA_PYTHON -c "import cv2, ctranslate2, faster_whisper; print('CUDA:', ctranslate2.get_cuda_device_count()); print('OpenCL:', cv2.ocl.haveOpenCL())"
$env:KLIPORA_STORAGE = Join-Path $env:LOCALAPPDATA "Klipora datos"
pnpm install --frozen-lockfile
pnpm dev
```

Para la comprobación física, repite los recorridos de [procesamiento](local-processing.md), [análisis](semantic-analysis.md) y [edición](clip-editor.md) con la ruta anterior y un video con nombre acentuado. Repite un trabajo con la detección automática, revisa la ficha y verifica el cierre durante un render con Ctrl+C. Para una comparación por CPU, configura `KLIPORA_DEVICE=cpu`, `KLIPORA_VISION_DEVICE=cpu` y `KLIPORA_ENCODER=cpu`; configura el modelo local en CPU por separado. El servicio llama-server u Ollama tiene su propio ciclo de vida.

En Windows, la disponibilidad de NVENC, QSV y AMF depende del binario de FFmpeg y de los controladores. Whisper CUDA depende de CTranslate2 y de las DLL compatibles con la versión instalada. La primera descarga de un modelo sigue necesitando conectividad o un modelo ya guardado en el equipo.
