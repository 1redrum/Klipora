export type CaptionAnimation = 'none' | 'pop' | 'slide' | 'fade'

export interface CaptionStyle {
  preset: CaptionPresetKey
  font: string
  size: number
  color: string
  highlight: string
  outline: number
  outlineColor: string
  shadow: number
  /** 0 = top, 100 = bottom (percentage of frame height). */
  position: number
  wordsPerLine: number
  animation: CaptionAnimation
  uppercase: boolean
  /** Karaoke: fill words progressively as they are spoken. */
  karaoke: boolean
  /** Highlight only emphasised words instead of the active one. */
  emphasisOnly: boolean
  background: boolean
}

export type CaptionPresetKey = 'hormozi' | 'mrbeast' | 'minimal' | 'gaming' | 'karaoke'

export const CAPTION_FONTS = [
  { value: "'Anton', sans-serif", label: 'Anton' },
  { value: "'Bricolage Grotesque', sans-serif", label: 'Bricolage' },
  { value: "'Inter', sans-serif", label: 'Inter' },
  { value: "'JetBrains Mono', monospace", label: 'Mono' },
]

export const CAPTION_PRESETS: Record<CaptionPresetKey, { label: string; description: string; style: CaptionStyle }> = {
  hormozi: {
    label: 'Hormozi',
    description: 'Palabras grandes y blancas, resalta las clave',
    style: {
      preset: 'hormozi',
      font: "'Anton', sans-serif",
      size: 44,
      color: '#ffffff',
      highlight: '#facc15',
      outline: 4,
      outlineColor: '#000000',
      shadow: 0,
      position: 68,
      wordsPerLine: 3,
      animation: 'pop',
      uppercase: true,
      karaoke: false,
      emphasisOnly: true,
      background: false,
    },
  },
  mrbeast: {
    label: 'MrBeast',
    description: 'Enormes, llamativos y con rebote',
    style: {
      preset: 'mrbeast',
      font: "'Anton', sans-serif",
      size: 56,
      color: '#ffffff',
      highlight: '#22d3ee',
      outline: 6,
      outlineColor: '#111111',
      shadow: 6,
      position: 55,
      wordsPerLine: 2,
      animation: 'pop',
      uppercase: true,
      karaoke: false,
      emphasisOnly: false,
      background: false,
    },
  },
  minimal: {
    label: 'Minimalista',
    description: 'Texto blanco con sombra suave',
    style: {
      preset: 'minimal',
      font: "'Inter', sans-serif",
      size: 26,
      color: '#ffffff',
      highlight: '#ffffff',
      outline: 0,
      outlineColor: '#000000',
      shadow: 10,
      position: 80,
      wordsPerLine: 6,
      animation: 'fade',
      uppercase: false,
      karaoke: false,
      emphasisOnly: true,
      background: false,
    },
  },
  gaming: {
    label: 'Gaming',
    description: 'Colores vivos y énfasis fuerte',
    style: {
      preset: 'gaming',
      font: "'Bricolage Grotesque', sans-serif",
      size: 42,
      color: '#a3e635',
      highlight: '#f472b6',
      outline: 5,
      outlineColor: '#1e1b4b',
      shadow: 4,
      position: 62,
      wordsPerLine: 3,
      animation: 'slide',
      uppercase: true,
      karaoke: false,
      emphasisOnly: false,
      background: false,
    },
  },
  karaoke: {
    label: 'Karaoke',
    description: 'Cada palabra se ilumina al pronunciarse',
    style: {
      preset: 'karaoke',
      font: "'Bricolage Grotesque', sans-serif",
      size: 34,
      color: '#ffffffaa',
      highlight: '#a3e635',
      outline: 0,
      outlineColor: '#000000',
      shadow: 2,
      position: 74,
      wordsPerLine: 5,
      animation: 'none',
      uppercase: false,
      karaoke: true,
      emphasisOnly: false,
      background: true,
    },
  },
}
