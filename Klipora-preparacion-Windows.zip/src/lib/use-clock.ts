import { useEffect, useState } from 'react'

/** Looping playback clock (seconds) for previews without a real video. */
export function useClock(duration: number, playing = true, startAt = 0) {
  const [t, setT] = useState(startAt)
  useEffect(() => {
    if (!playing) return
    let raf = 0
    let last = performance.now()
    const tick = (now: number) => {
      const dt = (now - last) / 1000
      last = now
      setT((prev) => (prev + dt >= duration ? 0 : prev + dt))
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [duration, playing])
  return t
}
