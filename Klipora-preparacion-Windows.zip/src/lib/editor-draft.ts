import { z } from "zod";
import { CAPTION_PRESETS, type CaptionStyle } from "./caption-styles.ts";

export const editorAspect = z.enum(["9:16", "16:9", "1:1", "4:5"]);
export const editorResolution = z.enum(["720p", "1080p"]);
export const editorFraming = z.enum([
  "face-track",
  "subject-track",
  "gameplay-track",
  "blur-fill",
  "streamer-split",
  "manual",
]);
const color = z.string().regex(/^#[a-f0-9]{6}([a-f0-9]{2})?$/i);
const percent = z.number().min(0).max(100);
const positiveTime = z.number().nonnegative();
const font = z.enum([
  "Anton",
  "Inter",
  "Bricolage Grotesque",
  "JetBrains Mono",
]);
export const editorFonts = font.options;
const timed = z.object({
  start: positiveTime,
  end: positiveTime,
  text: z.string(),
});
const styleSchema = z.object({
  preset: z.enum(["hormozi", "mrbeast", "gaming", "karaoke", "minimal"]),
  font,
  size: z.number().min(8).max(160),
  color,
  highlight: color,
  outline: z.number().min(0).max(24),
  outlineColor: color,
  shadow: z.number().min(0).max(30),
  position: percent,
  wordsPerLine: z.number().int().min(1).max(24),
  animation: z.enum(["none", "pop", "slide", "fade"]),
  uppercase: z.boolean(),
  karaoke: z.boolean(),
  emphasisOnly: z.boolean(),
  background: z.boolean(),
});
export const draftSchema = z.object({
  start: positiveTime,
  end: positiveTime,
  volume: percent,
  muted: z.boolean(),
  aspect: editorAspect,
  resolution: editorResolution,
  framing: editorFraming,
  x: percent,
  y: percent,
  captions: z.boolean(),
  style: styleSchema,
  words: z.array(timed.extend({ emphasis: z.boolean() })),
  overlays: z.array(
    timed.extend({
      x: percent,
      y: percent,
      size: z.number().min(8).max(160),
      color,
    }),
  ),
});
export type ClipDraft = z.infer<typeof draftSchema>;
export type EditorResponse = {
  draft: ClipDraft;
  revision: string;
  duration: number;
  mediaStart: number;
  mediaEnd: number;
  title: string;
};

export function presetStyle(
  preset: CaptionStyle["preset"],
): ClipDraft["style"] {
  const style = CAPTION_PRESETS[preset].style;
  return { ...style, font: font.parse(style.font.split("'")[1]) };
}

export function draftProblem(
  draft: ClipDraft,
  duration: number,
): string | undefined {
  if (draft.start >= draft.end || draft.end > duration)
    return "El recorte debe empezar antes de terminar y quedar dentro del original.";
  if (draft.words.some((word) => word.start >= word.end || word.end > duration))
    return "Revisa el inicio y el final de las palabras. Los tiempos se refieren al original.";
  if (
    draft.overlays.some(
      (entry) => entry.start >= entry.end || entry.end > duration,
    )
  )
    return "Revisa los tiempos de los textos personalizados.";
}
