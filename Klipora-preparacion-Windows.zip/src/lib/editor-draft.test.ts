import { describe, expect, it } from "vitest";
import { makeAss } from "../../local/ass";
import { draftProblem, presetStyle, type ClipDraft } from "./editor-draft";

function example(): ClipDraft {
  return {
    start: 10,
    end: 15,
    volume: 100,
    muted: false,
    aspect: "9:16",
    resolution: "720p",
    framing: "manual",
    x: 50,
    y: 50,
    captions: true,
    style: presetStyle("karaoke"),
    words: [
      { start: 10.1, end: 10.6, text: "Hola", emphasis: false },
      { start: 10.7, end: 11.3, text: "mundo", emphasis: false },
    ],
    overlays: [
      {
        start: 10.3,
        end: 12,
        text: "{texto}\\N",
        x: 50,
        y: 14,
        color: "#ffffff",
        size: 36,
      },
    ],
  };
}

describe("editor local", () => {
  it("rechaza rangos invertidos sin limitar los minutos del proyecto", () => {
    const draft = example();
    expect(draftProblem({ ...draft, end: 7200 }, 9200)).toBeUndefined();
    expect(draftProblem({ ...draft, end: 9 }, 9200)).toContain("recorte");
    expect(
      draftProblem(
        {
          ...draft,
          words: [{ start: 11, end: 10, text: "Hola", emphasis: false }],
        },
        30,
      ),
    ).toContain("palabras");
  });

  it("mantiene los grupos y reconstruye el estado karaoke al comenzar una muestra dentro de una frase", () => {
    const draft = example();
    const full = makeAss(draft, 10, 15, 720, 1280)!;
    const preview = makeAss(draft, 10.5, 11.5, 360, 640)!;
    expect(full).toContain("0:00:00.10,0:00:01.42,Caption");
    expect(preview).toContain("0:00:00.00,0:00:00.92,Caption");
    expect(preview).toContain("{\\1c&H35e6a3&\\1a&H00&}Hola");
    expect(preview).toContain("\\t(200,210,\\1c&H35e6a3&");
    expect(preview).toContain("｛texto｝＼N");
  });

  it("exporta textos aunque se desactiven los subtítulos", () => {
    const draft = { ...example(), captions: false };
    const ass = makeAss(draft, 10, 15, 720, 1280)!;
    expect(ass).toContain("Dialogue: 2,0:00:00.30,0:00:02.00,Text");
    expect(ass).not.toContain("Dialogue: 1");
  });
});
