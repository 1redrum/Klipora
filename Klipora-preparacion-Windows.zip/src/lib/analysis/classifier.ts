import type { SourcePlatform } from '../types'
import {
  CATEGORY_LABEL,
  type ContentCategory,
  type ContentMode,
  type EngineKey,
  type GameKey,
  type GeneralCategory,
} from './content'

/**
 * Evidence gathered before moment detection. Every field is optional except
 * the platform: on import we only know the link or file name; the worker adds
 * platform metadata, a transcript sample and sampled-frame statistics.
 */
export interface ClassificationEvidence {
  platform: SourcePlatform
  title?: string
  description?: string
  tags?: string[]
  /** Category reported by the platform (Twitch/Kick category, YouTube category name). */
  platformCategory?: string
  /** A few minutes of transcript sampled across the video. */
  transcriptSample?: string
  visual?: {
    /** Share of sampled frames with a game HUD (minimap, kill feed, health bar…). */
    hudRatio: number
    /** Share of frames with a small facecam overlaid on another image. */
    facecamOverlayRatio: number
    /** Share of frames where a real face fills a large part of the image. */
    fullFrameFaceRatio: number
    /** Per-game confidence from the HUD/vision detector, 0–1. */
    gameDetections?: Partial<Record<GameKey, number>>
  }
  audio?: {
    /** Share of the timeline with speech. */
    speechRatio: number
    speakerCount: number
    /** Share of the timeline with game sounds (gunfire, UI, music cues). */
    gameAudioRatio?: number
  }
}

export interface ContentClassification {
  mode: ContentMode
  engine: EngineKey
  category: ContentCategory
  /** 0–1. With user-chosen modes this is the confidence of the category only. */
  confidence: number
  decidedBy: 'user' | 'auto'
  /** Human-readable reasons, strongest first. */
  evidence: string[]
}

/* ------------------------------------------------------------------ */

const GAME_ALIASES: Record<Exclude<GameKey, 'otro-juego'>, RegExp> = {
  fortnite: /\bfortnite\b|\bbattle ?pass\b.*\bfort|\bvictory royale\b/i,
  minecraft: /\bminecraft\b|\bmc\b.*\b(survival|hardcore)\b|\bcreeper\b|\bthe nether\b/i,
  'gta-v': /\bgta\s?(v|5|rp|online)\b|\bgrand theft auto\b/i,
  valorant: /\bvalorant\b|\bvalo\b/i,
  cs2: /\bcs2\b|\bcounter[- ]?strike\b|\bcs:?go\b/i,
  cod: /\bcall of duty\b|\bwarzone\b|\bcod\b|\bblack ops\b|\bmodern warfare\b/i,
  lol: /\bleague of legends\b|\blol\b.*\b(ranked|rank|soloq|elo)\b|\bsoloq\b|\bsummoner'?s rift\b/i,
}

const GENERIC_GAMING = /\b(gameplay|gaming|gamer|ranked|clutch|speedrun|let'?s play|partida|partidas|torneo|scrims?|kills?|headshots?|elo|soloq|clasificatoria|1v\d|ace)\b/i

/** In-game vocabulary heard in a transcript sample. */
const GAMING_SPEECH =
  /\b(kill|kills|baja|bajas|rush|rushea|flanco|flanqu\w*|headshot|ronda|spike|plant\w*|defus\w*|respawn|loot|lootear|build|edit|tormenta|zona|dragón|barón|torre|nexo|farm\w*|creeper|aldeano|policía|misión|recarga|cura|revive|revivir|sniper|op|awp|vandal)\b/gi

const NON_GAMING_PLATFORM_CATEGORY = /just chatting|charlando|podcasts?|talk shows?|irl|educa|science|ciencia|people & blogs|music|música|asmr|cooking|cocina|sports?/i

const GENERAL_HINTS: [GeneralCategory, RegExp][] = [
  ['podcast', /\bpodcast\b|\bep(isodio)?\.?\s?\d+\b|\bpod\b/i],
  ['entrevista', /\bentrevista\b|\binterview\b|\bcon (el|la) invitad[oa]\b/i],
  ['debate', /\bdebate\b|\bdebatimos\b|\bversus\b|\bvs\.?\b/i],
  ['reaccion', /\breacci(ó|o)n(ando)?\b|\breacciono\b|\breact(ing|s)?\b/i],
  ['historia', /\bstorytime\b|\bmi historia\b|\bos cuento\b|\bte cuento\b|\banécdota\b/i],
  ['humor', /\bhumor\b|\bcomedia\b|\bstand ?up\b|\bbromas?\b|\bsketch\b/i],
  ['educacion', /\btutorial\b|\bclase\b|\bcurso\b|\bc(ó|o)mo\s\w+|\bexplica(do|ción)\b|\baprende\b|\bguía\b/i],
  ['opinion', /\bopini(ó|o)n\b|\bmi opinión\b|\blo que pienso\b|\bhot take\b/i],
  ['conversacion', /\bcharla\b|\bconversaci(ó|o)n\b|\bhablamos\b|\bjust chatting\b|\birl\b/i],
]

const GAME_LABEL_FOR_EVIDENCE = (g: GameKey) => CATEGORY_LABEL[g]

function textOf(e: ClassificationEvidence) {
  return [e.title, e.description, ...(e.tags ?? [])].filter(Boolean).join(' · ')
}

/**
 * Decides which engine analyses the video. In manual modes the user's choice
 * wins and only the category inside that engine is inferred.
 */
export function classifyContent(e: ClassificationEvidence, mode: ContentMode = 'auto'): ContentClassification {
  let gaming = 0
  let general = 0
  const reasons: { w: number; text: string; side: EngineKey }[] = []
  const gameVotes = new Map<GameKey, number>()
  const generalVotes = new Map<GeneralCategory, number>()
  const add = (side: EngineKey, w: number, text: string) => {
    if (side === 'gaming') gaming += w
    else general += w
    reasons.push({ w, text, side })
  }
  const voteGame = (g: GameKey, w: number) => gameVotes.set(g, (gameVotes.get(g) ?? 0) + w)
  const voteGeneral = (c: GeneralCategory, w: number) => generalVotes.set(c, (generalVotes.get(c) ?? 0) + w)

  // 1. Platform category — the strongest metadata signal.
  if (e.platformCategory) {
    const game = matchGame(e.platformCategory)
    if (game) {
      add('gaming', 3, `Categoría en la plataforma: ${e.platformCategory}`)
      voteGame(game, 3)
    } else if (NON_GAMING_PLATFORM_CATEGORY.test(e.platformCategory)) {
      add('general', 3, `Categoría en la plataforma: ${e.platformCategory}`)
      const hinted = GENERAL_HINTS.find(([, re]) => re.test(e.platformCategory!))
      voteGeneral(hinted?.[0] ?? 'conversacion', 1.5)
    } else {
      // Unknown category name on a streaming platform is usually a game.
      add('gaming', e.platform === 'youtube' ? 0.5 : 1.5, `Categoría en la plataforma: ${e.platformCategory}`)
      voteGame('otro-juego', 1)
    }
  }

  // 2. Title, description, tags.
  const text = textOf(e)
  if (text) {
    const game = matchGame(text)
    if (game) {
      add('gaming', 2, `El título o las etiquetas mencionan ${GAME_LABEL_FOR_EVIDENCE(game)}`)
      voteGame(game, 2)
    } else if (GENERIC_GAMING.test(text)) {
      add('gaming', 1, 'El título usa vocabulario de partidas')
    }
    for (const [cat, re] of GENERAL_HINTS) {
      if (re.test(text)) {
        add('general', 1.5, `El título o las etiquetas indican ${CATEGORY_LABEL[cat].toLowerCase()}`)
        voteGeneral(cat, 2)
      }
    }
  }

  // 3. Transcript sample — in-game vocabulary density.
  if (e.transcriptSample) {
    const words = e.transcriptSample.split(/\s+/).filter(Boolean).length
    const hits = e.transcriptSample.match(GAMING_SPEECH)?.length ?? 0
    const density = words ? hits / words : 0
    if (density > 0.02) add('gaming', Math.min(2, density * 60), `Vocabulario de juego en la transcripción (${hits} términos)`)
    else if (words > 150) add('general', 1, 'La transcripción no contiene vocabulario de juego')
    const game = matchGame(e.transcriptSample)
    if (game) voteGame(game, 1)
    for (const [cat, re] of GENERAL_HINTS) if (re.test(e.transcriptSample)) voteGeneral(cat, 0.5)
  }

  // 4. Sampled frames.
  if (e.visual) {
    const v = e.visual
    if (v.hudRatio >= 0.4) add('gaming', 1 + 2.5 * v.hudRatio, `HUD de videojuego en el ${pct(v.hudRatio)} de los fotogramas`)
    else if (v.hudRatio < 0.1) add('general', 1, 'No aparece interfaz de videojuego en los fotogramas')
    if (v.facecamOverlayRatio >= 0.3 && v.hudRatio >= 0.2) add('gaming', 1, 'Cámara del streamer superpuesta al juego')
    if (v.fullFrameFaceRatio >= 0.5 && v.hudRatio < 0.15) add('general', 2, `Personas a cámara en el ${pct(v.fullFrameFaceRatio)} del video`)
    for (const [g, c] of Object.entries(v.gameDetections ?? {}) as [GameKey, number][]) {
      if (c >= 0.5) {
        voteGame(g, 3 * c)
        if (c >= 0.7) add('gaming', 1, `Interfaz reconocida: ${GAME_LABEL_FOR_EVIDENCE(g)}`)
      }
    }
  }

  // 5. Audio.
  if (e.audio) {
    const a = e.audio
    if (a.speakerCount >= 2 && a.speechRatio >= 0.7) {
      add('general', 1.5, `${a.speakerCount} voces y habla continua (${pct(a.speechRatio)})`)
      voteGeneral(a.speakerCount >= 3 ? 'debate' : 'conversacion', 0.6)
    }
    if ((a.gameAudioRatio ?? 0) >= 0.35) add('gaming', 1, `Sonido de juego en el ${pct(a.gameAudioRatio!)} del audio`)
  }

  // 6. Weak prior from the source platform.
  if (e.platform === 'twitch' || e.platform === 'kick') add('gaming', 0.5, 'Origen en una plataforma de streaming')

  const auto: EngineKey = gaming > general ? 'gaming' : 'general'
  const engine: EngineKey = mode === 'auto' ? auto : mode
  const total = gaming + general
  // Margin-based confidence that also grows with the amount of evidence.
  const margin = total ? Math.abs(gaming - general) / total : 0
  const autoConfidence = round2(Math.min(0.99, margin * Math.min(1, total / 6)))

  const category = engine === 'gaming' ? pickTop(gameVotes, 'otro-juego') : pickGeneral(generalVotes, e)
  const evidence = reasons
    .filter((r) => r.side === engine)
    .sort((a, b) => b.w - a.w)
    .map((r) => r.text)

  if (mode !== 'auto') {
    evidence.unshift(`Motor elegido manualmente: ${engine === 'gaming' ? 'Gaming y streaming' : 'Contenido general'}`)
    if (auto !== mode && total > 0) evidence.push('Las señales del video apuntaban al otro motor; se respeta tu elección')
  }

  const votes = engine === 'gaming' ? gameVotes : generalVotes
  const catTotal = [...votes.values()].reduce((a, b) => a + b, 0)
  const catConfidence = catTotal ? round2(((votes as Map<string, number>).get(category) ?? 0) / catTotal) : 0.3

  return {
    mode,
    engine,
    category,
    confidence: mode === 'auto' ? autoConfidence : catConfidence,
    decidedBy: mode === 'auto' ? 'auto' : 'user',
    evidence,
  }
}

/** Below this the UI suggests picking the engine manually. */
export const LOW_CONFIDENCE = 0.35

function matchGame(text: string): Exclude<GameKey, 'otro-juego'> | null {
  for (const [g, re] of Object.entries(GAME_ALIASES) as [Exclude<GameKey, 'otro-juego'>, RegExp][]) if (re.test(text)) return g
  return null
}

function pickTop<K>(votes: Map<K, number>, fallback: K): K {
  let best = fallback
  let bestW = 0
  for (const [k, w] of votes) if (w > bestW) [best, bestW] = [k, w]
  return best
}

function pickGeneral(votes: Map<GeneralCategory, number>, e: ClassificationEvidence): GeneralCategory {
  if (votes.size) return pickTop(votes, 'conversacion')
  if ((e.audio?.speakerCount ?? 0) >= 2) return 'conversacion'
  return e.platform === 'youtube' ? 'youtube' : 'conversacion'
}

const pct = (r: number) => `${Math.round(r * 100)}%`
const round2 = (n: number) => Math.round(n * 100) / 100
