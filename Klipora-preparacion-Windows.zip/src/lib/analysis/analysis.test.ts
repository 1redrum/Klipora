import { describe, expect, it } from "vitest";
import type { Word } from "../types";
import { classifyContent } from "./classifier";
import { MOMENT_RESPONSE_SCHEMA, buildMomentPrompt } from "./prompts";
import {
  selectMoments,
  snapToSentences,
  type MomentCandidate,
} from "./selection";

const breakdown = (n: number, context = n) => ({
  interest: n,
  emotion: n,
  entertainment: n,
  context,
  impact: n,
  hook: n,
});

/** Builds a transcript of sentences, one word per second, each ending in a period. */
function transcript(sentences: string[], from = 0): Word[] {
  const out: Word[] = [];
  let t = from;
  for (const s of sentences) {
    const parts = s.split(" ");
    parts.forEach((p, i) => {
      out.push({
        text: i === parts.length - 1 ? `${p}.` : p,
        start: t,
        end: t + 0.8,
      });
      t += 1;
    });
  }
  return out;
}

describe("classifyContent", () => {
  it("picks the gaming engine for a Valorant Twitch VOD", () => {
    const c = classifyContent({
      platform: "twitch",
      title: "Clutch 1v4 en ranked de Valorant",
      platformCategory: "VALORANT",
      visual: {
        hudRatio: 0.9,
        facecamOverlayRatio: 0.8,
        fullFrameFaceRatio: 0.05,
      },
    });
    expect(c.engine).toBe("gaming");
    expect(c.category).toBe("valorant");
    expect(c.decidedBy).toBe("auto");
    expect(c.confidence).toBeGreaterThan(0.5);
    expect(c.evidence.length).toBeGreaterThan(0);
  });

  it("picks the general engine for a two-person podcast", () => {
    const c = classifyContent({
      platform: "youtube",
      title: "Podcast episodio 42: entrevista con una economista",
      visual: { hudRatio: 0, facecamOverlayRatio: 0, fullFrameFaceRatio: 0.8 },
      audio: { speechRatio: 0.92, speakerCount: 2 },
    });
    expect(c.engine).toBe("general");
    expect(["podcast", "entrevista"]).toContain(c.category);
  });

  it("treats Just Chatting on Kick as general content despite the streaming platform", () => {
    const c = classifyContent({
      platform: "kick",
      platformCategory: "Just Chatting",
    });
    expect(c.engine).toBe("general");
  });

  it("respects a manual choice even when the signals disagree", () => {
    const c = classifyContent(
      { platform: "twitch", platformCategory: "Fortnite", title: "Fortnite" },
      "general",
    );
    expect(c.engine).toBe("general");
    expect(c.decidedBy).toBe("user");
    expect(c.evidence.join(" ")).toMatch(/se respeta tu elección/);
  });

  it("reports low confidence when there is no evidence", () => {
    expect(classifyContent({ platform: "upload" }).confidence).toBeLessThan(
      0.35,
    );
  });
});

describe("snapToSentences", () => {
  const words = transcript([
    "uno dos tres cuatro",
    "cinco seis siete ocho",
    "nueve diez once doce",
  ]);

  it("extends a window to complete sentences", () => {
    expect(snapToSentences(words, 5, 10, 8)).toEqual({ start: 4, end: 11.8 });
  });

  it("returns null when no full sentence fits the snap window", () => {
    expect(snapToSentences(words, 5, 6, 0.5)).toBeNull();
  });
});

describe("selectMoments", () => {
  const words = transcript(
    Array.from(
      { length: 40 },
      (_, i) =>
        `frase numero ${i} sobre tema${i} distinto${i} contenido${i} interesante${i}`,
    ),
  );
  const base = (over: Partial<MomentCandidate>): MomentCandidate => ({
    id: "c",
    start: 14,
    end: 28,
    kind: "frase",
    signals: [{ kind: "quotable", t: 20, strength: 0.9 }],
    reason: "Frase citable que se entiende sin contexto previo.",
    breakdown: breakdown(85),
    ...over,
  });
  const opts = { targetLengthSec: 15 };

  it("keeps a self-contained moment with a reason and evidence", () => {
    const r = selectMoments([base({ id: "ok" })], words, "general", opts);
    expect(r.selected).toHaveLength(1);
    expect(r.selected[0]!.reason).not.toBe("");
    expect(r.selected[0]!.evidence).toContain("Frase citable");
  });

  it("keeps more than 15 distinct moments of the same kind without a quota", () => {
    const candidates = Array.from({ length: 24 }, (_, i) =>
      base({
        id: `moment-${i}`,
        start: i * 200 + 10,
        end: i * 200 + 30,
      }),
    );
    const result = selectMoments(candidates, [], "general", {
      targetLengthSec: 30,
    });
    expect(result.selected).toHaveLength(24);
    expect(result.rejected).toEqual([]);
  });

  it("preserves complete moments longer than 180 seconds by default", () => {
    const result = selectMoments(
      [base({ start: 10, end: 400 })],
      [],
      "general",
      { targetLengthSec: 300 },
    );
    expect(result.selected).toHaveLength(1);
    expect(result.selected[0]!.end - result.selected[0]!.start).toBeGreaterThan(
      180,
    );
  });

  it("rejects moments backed only by loudness or motion", () => {
    const r = selectMoments(
      [
        base({
          id: "loud",
          signals: [
            { kind: "audio-peak", t: 20, strength: 1 },
            { kind: "motion", t: 21, strength: 1 },
          ],
        }),
      ],
      words,
      "general",
      opts,
    );
    expect(r.selected).toHaveLength(0);
    expect(r.rejected[0]!.reason).toBe("solo-intensidad");
  });

  it("rejects moments without a reason or that need prior context", () => {
    const r = selectMoments(
      [
        base({ id: "a", reason: "  " }),
        base({ id: "b", needsPriorContext: true }),
        base({ id: "c", breakdown: breakdown(85, 30) }),
      ],
      words,
      "general",
      opts,
    );
    expect(r.rejected.map((x) => x.reason)).toEqual([
      "sin-razon",
      "sin-contexto",
      "sin-contexto",
    ]);
  });

  it("drops overlapping and near-duplicate moments, keeping the best one", () => {
    const r = selectMoments(
      [
        base({ id: "best", breakdown: breakdown(90) }),
        base({ id: "dup", start: 15, end: 29, breakdown: breakdown(80) }),
      ],
      words,
      "general",
      opts,
    );
    expect(r.selected.map((s) => s.candidateId)).toEqual(["best"]);
    expect(r.rejected[0]).toEqual({ candidateId: "dup", reason: "solapado" });
  });

  it("rejects the same kind of moment close in time as too similar", () => {
    const r = selectMoments(
      [
        base({ id: "a", start: 14, end: 28 }),
        base({ id: "b", start: 70, end: 84, breakdown: breakdown(80) }),
      ],
      words,
      "general",
      opts,
    );
    expect(r.selected.map((s) => s.candidateId)).toEqual(["a"]);
    expect(r.rejected[0]!.reason).toBe("similar");
  });

  it("gaming engine accepts visual events with streamer reactions and keeps the build-up", () => {
    const r = selectMoments(
      [
        base({
          id: "kill",
          kind: "multikill",
          start: 120,
          end: 132,
          peak: 128,
          signals: [
            { kind: "multikill", t: 128, strength: 1 },
            { kind: "shout", t: 129, strength: 0.9 },
          ],
          breakdown: breakdown(80, 60),
        }),
      ],
      words,
      "gaming",
      opts,
    );
    expect(r.selected).toHaveLength(1);
    expect(r.selected[0]!.start).toBeLessThan(120);
  });
});

describe("prompts", () => {
  it("builds an engine-specific prompt that forbids intensity-only picks", () => {
    const classification = classifyContent({
      platform: "twitch",
      platformCategory: "Fortnite",
    });
    const { system } = buildMomentPrompt(classification, {
      start: 0,
      end: 60,
      transcript: "[00:00] hola",
      signals: [],
    });
    expect(system).toMatch(/Motor B/);
    expect(system).toMatch(/volumen alto o mucho movimiento/);
  });

  it("rejects LLM moments without a reason or with kinds from the other engine", () => {
    const m = {
      start: 1,
      end: 20,
      kind: "kill",
      evidenceIds: ["M0"],
      reason: "x",
      needsPriorContext: false,
      breakdown: breakdown(70),
    };
    expect(
      MOMENT_RESPONSE_SCHEMA.gaming.safeParse({ moments: [m] }).success,
    ).toBe(false);
    expect(
      MOMENT_RESPONSE_SCHEMA.general.safeParse({
        moments: [{ ...m, reason: "Una razón suficientemente larga" }],
      }).success,
    ).toBe(false);
    expect(
      MOMENT_RESPONSE_SCHEMA.gaming.safeParse({
        moments: [{ ...m, reason: "Una razón suficientemente larga" }],
      }).success,
    ).toBe(true);
  });
});
