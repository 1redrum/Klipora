import { describe, expect, it } from "vitest";
import {
  chooseBounds,
  trimLeadingFragment,
  trimTrailingFragment,
} from "../../../local/editorial";
import { observedGames } from "../../../local/game-candidates";
import { readHud, type Observation } from "../../../local/game-signals";
import type { Word } from "../types";

describe("editorial evidence", () => {
  it("removes a leading ASR fragment and chooses a complete span with the main line", () => {
    const words: Word[] = [
      { text: "in", start: 0, end: 0.4 },
      { text: "context.", start: 0.5, end: 1.1 },
      { text: "The setup.", start: 2, end: 4 },
      { text: "The key evidence.", start: 4.1, end: 6 },
      { text: "Another topic.", start: 15, end: 20 },
    ];
    expect(trimLeadingFragment(words, { start: 0, end: 20 })).toEqual({
      start: 2,
      end: 20,
    });
    expect(
      chooseBounds(words, { start: 2, end: 20 }, { start: 4.1, end: 6 }, 5),
    ).toEqual({ start: 2, end: 6 });
  });
  it("keeps the last complete sentence when a proposed clip ends mid-clause", () => {
    const words = [
      { text: "A result.", start: 0, end: 2 },
      { text: "Then,", start: 3, end: 4 },
    ];
    expect(trimTrailingFragment(words, { start: 0, end: 4 })).toEqual({
      start: 0,
      end: 2,
    });
    expect(trimTrailingFragment(words, { start: 3, end: 4 })).toBeNull();
  });
  it("requires independent evidence and keeps a completed objective distinct from a kill", () => {
    const hud = readHud("Mission Completed", 15);
    const motion: Observation = {
      kind: "motion",
      origin: "vision",
      t: 16,
      strength: 0.6,
      text: "Frame activity",
    };
    expect(observedGames([motion], 0, 30)).toEqual([]);
    expect(observedGames(hud, 0, 30)).toEqual([]);
    expect(observedGames([...hud, motion], 0, 30)).toMatchObject([
      { kind: "competitivo", start: 15 },
    ]);
  });
});
