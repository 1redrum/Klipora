/**
 * Content types and the two specialised analysis engines.
 *
 * Shared contract between the web app, the LLM moment analyzer and the media
 * worker (see PLAN.md, milestone 7). Never use a single detection algorithm
 * for every video: classification picks Engine A (general) or Engine B
 * (gaming) and each engine has its own signals, weights and boundary rules.
 */

/** What the user chose on import. */
export type ContentMode = 'auto' | 'general' | 'gaming'
export type EngineKey = 'general' | 'gaming'

export type GeneralCategory =
  | 'podcast'
  | 'entrevista'
  | 'conversacion'
  | 'youtube'
  | 'reaccion'
  | 'debate'
  | 'historia'
  | 'humor'
  | 'educacion'
  | 'opinion'

export type GameKey = 'fortnite' | 'minecraft' | 'gta-v' | 'valorant' | 'cs2' | 'cod' | 'lol' | 'otro-juego'
export type ContentCategory = GeneralCategory | GameKey

export const CONTENT_MODE_OPTIONS: { value: ContentMode; label: string; hint: string }[] = [
  { value: 'auto', label: 'Detección automática', hint: 'La IA identifica el tipo de video y elige el motor' },
  { value: 'general', label: 'Contenido general', hint: 'Podcasts, entrevistas, reacciones, humor, educación…' },
  { value: 'gaming', label: 'Gaming y streaming', hint: 'Fortnite, Valorant, CS2, LoL, Minecraft, GTA V…' },
]

export const CATEGORY_LABEL: Record<ContentCategory, string> = {
  podcast: 'Podcast',
  entrevista: 'Entrevista',
  conversacion: 'Conversación',
  youtube: 'Video de YouTube',
  reaccion: 'Reacción',
  debate: 'Debate',
  historia: 'Historia',
  humor: 'Humor',
  educacion: 'Educación',
  opinion: 'Opinión',
  fortnite: 'Fortnite',
  minecraft: 'Minecraft',
  'gta-v': 'GTA V',
  valorant: 'Valorant',
  cs2: 'Counter-Strike 2',
  cod: 'Call of Duty',
  lol: 'League of Legends',
  'otro-juego': 'Otro videojuego',
}

export const GENERAL_CATEGORIES: GeneralCategory[] = [
  'podcast',
  'entrevista',
  'conversacion',
  'youtube',
  'reaccion',
  'debate',
  'historia',
  'humor',
  'educacion',
  'opinion',
]
export const GAME_KEYS: GameKey[] = ['fortnite', 'minecraft', 'gta-v', 'valorant', 'cs2', 'cod', 'lol', 'otro-juego']

export function engineForCategory(c: ContentCategory): EngineKey {
  return (GAME_KEYS as string[]).includes(c) ? 'gaming' : 'general'
}

/* ------------------------------------------------------------------ */
/* Moments                                                             */
/* ------------------------------------------------------------------ */

export const GENERAL_MOMENT_KINDS = [
  'frase',
  'cambio-tema',
  'gracioso',
  'respuesta-inesperada',
  'reaccion',
  'debate',
  'historia',
  'ensenanza',
  'opinion',
] as const

export const GAMING_MOMENT_KINDS = [
  'kill',
  'multikill',
  'victoria',
  'derrota',
  'jugada',
  'competitivo',
  'reaccion-streamer',
  'celebracion',
  'fail',
  'inesperado',
  'gracioso',
  'giro-partida',
] as const

export type GeneralMomentKind = (typeof GENERAL_MOMENT_KINDS)[number]
export type GamingMomentKind = (typeof GAMING_MOMENT_KINDS)[number]
export type MomentKind = GeneralMomentKind | GamingMomentKind

export const MOMENT_KIND_LABEL: Record<MomentKind, string> = {
  frase: 'Frase destacada',
  'cambio-tema': 'Cambio de conversación',
  gracioso: 'Momento gracioso',
  'respuesta-inesperada': 'Respuesta inesperada',
  reaccion: 'Reacción',
  debate: 'Debate',
  historia: 'Historia',
  ensenanza: 'Enseñanza',
  opinion: 'Opinión',
  kill: 'Eliminación',
  multikill: 'Multikill',
  victoria: 'Victoria',
  derrota: 'Derrota',
  jugada: 'Jugada impresionante',
  competitivo: 'Momento competitivo',
  'reaccion-streamer': 'Reacción del streamer',
  celebracion: 'Grito / celebración',
  fail: 'Fail',
  inesperado: 'Situación inesperada',
  'giro-partida': 'Cambio en la partida',
}

/* ------------------------------------------------------------------ */
/* Signals                                                             */
/* ------------------------------------------------------------------ */

/** Evidence produced by the worker (audio/vision) or the LLM transcript pass. */
export type SignalKind =
  // Raw intensity — never enough on its own to justify a clip.
  | 'audio-peak'
  | 'motion'
  | 'scene-change'
  // Audio semantics.
  | 'laughter'
  | 'shout'
  | 'speaker-change'
  | 'overlap-speech'
  | 'silence-break'
  // Transcript / LLM.
  | 'quotable'
  | 'topic-shift'
  | 'punchline'
  | 'unexpected-answer'
  | 'story-arc'
  | 'disagreement'
  | 'explanation'
  | 'opinion'
  // Gameplay vision.
  | 'kill-feed'
  | 'multikill'
  | 'victory-screen'
  | 'defeat-screen'
  | 'death'
  | 'low-health'
  | 'round-change'
  | 'objective'
  // Streamer.
  | 'facecam-reaction'
  | 'chat-spike'

export const INTENSITY_SIGNALS: ReadonlySet<SignalKind> = new Set(['audio-peak', 'motion', 'scene-change'])

export const SIGNAL_LABEL: Record<SignalKind, string> = {
  'audio-peak': 'Pico de volumen',
  motion: 'Mucho movimiento',
  'scene-change': 'Cambio de escena',
  laughter: 'Risas',
  shout: 'Grito',
  'speaker-change': 'Cambio de turno de palabra',
  'overlap-speech': 'Voces superpuestas',
  'silence-break': 'Silencio seguido de reacción',
  quotable: 'Frase citable',
  'topic-shift': 'Cambio de tema',
  punchline: 'Remate',
  'unexpected-answer': 'Respuesta inesperada',
  'story-arc': 'Historia con inicio y desenlace',
  disagreement: 'Desacuerdo',
  explanation: 'Explicación completa',
  opinion: 'Opinión clara',
  'kill-feed': 'Eliminación en el kill feed',
  multikill: 'Varias eliminaciones seguidas',
  'victory-screen': 'Pantalla de victoria',
  'defeat-screen': 'Pantalla de derrota',
  death: 'Muerte del jugador',
  'low-health': 'Vida crítica',
  'round-change': 'Cambio de ronda',
  objective: 'Objetivo de la partida',
  'facecam-reaction': 'Reacción en la cámara',
  'chat-spike': 'Pico de actividad en el chat',
}

export interface MomentSignal {
  kind: SignalKind
  /** Seconds in the source video. */
  t: number
  /** 0–1 normalised strength reported by the detector. */
  strength: number
}

/* ------------------------------------------------------------------ */
/* Engines                                                             */
/* ------------------------------------------------------------------ */

export interface EngineDefinition {
  key: EngineKey
  label: string
  description: string
  momentKinds: readonly MomentKind[]
  /** How much each signal supports a moment in this engine (0 = ignored). */
  signalWeight: Partial<Record<SignalKind, number>>
  /** Weights of the six-factor breakdown in the final score (sum 1). */
  breakdownWeight: { interest: number; emotion: number; entertainment: number; context: number; impact: number; hook: number }
  /** Seconds of build-up kept before the key event. */
  preRollSec: number
  /** Seconds kept after the key event (reaction tail). */
  postRollSec: number
  /** How far boundaries may move to land on a complete sentence. */
  snapWindowSec: number
  minScore: number
  /** Minimum breakdown.context for a clip to stand on its own. */
  minContext: number
  /** Instructions for the LLM pass over transcript windows. */
  llmFocus: string[]
}

export const ENGINES: Record<EngineKey, EngineDefinition> = {
  general: {
    key: 'general',
    label: 'Motor A · Contenido general',
    description:
      'Prioriza el contexto y la calidad narrativa: frases interesantes, cambios de conversación, humor, respuestas inesperadas y reacciones que se entienden por sí solas.',
    momentKinds: GENERAL_MOMENT_KINDS,
    signalWeight: {
      quotable: 1,
      punchline: 1,
      'unexpected-answer': 1,
      'story-arc': 0.9,
      disagreement: 0.8,
      explanation: 0.8,
      opinion: 0.7,
      'topic-shift': 0.6,
      laughter: 0.7,
      'speaker-change': 0.3,
      'overlap-speech': 0.4,
      'silence-break': 0.4,
      shout: 0.3,
      'facecam-reaction': 0.5,
      'chat-spike': 0.3,
      'audio-peak': 0.15,
      motion: 0.05,
      'scene-change': 0.05,
    },
    breakdownWeight: { interest: 0.2, emotion: 0.1, entertainment: 0.15, context: 0.25, impact: 0.2, hook: 0.1 },
    preRollSec: 0,
    postRollSec: 0.6,
    snapWindowSec: 8,
    minScore: 60,
    minContext: 65,
    llmFocus: [
      'Busca frases interesantes o citables, cambios de conversación, momentos graciosos, respuestas inesperadas, reacciones y situaciones que capten la atención.',
      'Prioriza el contexto y la calidad narrativa: el clip debe tener planteamiento y cierre dentro del propio fragmento.',
      'Descarta fragmentos que dependan de algo dicho antes y no incluido, o que terminen a mitad de una idea.',
    ],
  },
  gaming: {
    key: 'gaming',
    label: 'Motor B · Gaming y streaming',
    description:
      'Combina el análisis visual del gameplay (kill feed, pantallas de victoria/derrota, vida, rondas) con el audio y las reacciones del streamer.',
    momentKinds: GAMING_MOMENT_KINDS,
    signalWeight: {
      multikill: 1,
      'victory-screen': 1,
      'kill-feed': 0.7,
      'defeat-screen': 0.8,
      'low-health': 0.6,
      'round-change': 0.5,
      objective: 0.6,
      death: 0.5,
      'facecam-reaction': 0.9,
      shout: 0.7,
      laughter: 0.7,
      'silence-break': 0.6,
      'chat-spike': 0.6,
      punchline: 0.6,
      'unexpected-answer': 0.5,
      quotable: 0.4,
      'audio-peak': 0.25,
      motion: 0.1,
      'scene-change': 0.1,
    },
    breakdownWeight: { interest: 0.15, emotion: 0.2, entertainment: 0.2, context: 0.15, impact: 0.15, hook: 0.15 },
    preRollSec: 6,
    postRollSec: 4,
    snapWindowSec: 4,
    minScore: 62,
    minContext: 55,
    llmFocus: [
      'Busca eliminaciones, victorias, derrotas, jugadas impresionantes, momentos competitivos, reacciones, gritos y celebraciones, fails, situaciones inesperadas, momentos graciosos y cambios importantes en la partida.',
      'Cruza los eventos visuales del gameplay con el audio y la reacción del streamer: un evento sin reacción o una reacción sin evento valen menos que ambos juntos.',
      'Incluye la preparación de la jugada y la reacción posterior; no cortes en mitad de una frase del streamer.',
    ],
  },
}
