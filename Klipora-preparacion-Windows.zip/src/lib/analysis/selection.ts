import type { ScoreBreakdown, Word } from "../types";
import {
  ENGINES,
  INTENSITY_SIGNALS,
  SIGNAL_LABEL,
  type EngineKey,
  type MomentKind,
  type MomentSignal,
} from "./content";

/**
 * Selection intelligence: turns raw candidate moments into clips that make
 * sense on their own. Loudness or motion alone never selects a clip; every
 * kept clip carries an identifiable reason and the evidence behind it.
 */

export interface MomentCandidate {
  id: string;
  /** Rough window from the detectors, in source seconds. */
  start: number;
  end: number;
  /** Seconds of the key event (kill, punchline…) inside the window. */
  peak?: number;
  kind: MomentKind;
  signals: MomentSignal[];
  /** From the LLM pass over the transcript window with surrounding context. */
  reason: string;
  breakdown: ScoreBreakdown;
  /** The LLM flagged references to something said/shown before the window. */
  needsPriorContext?: boolean;
}

export interface SelectOptions {
  targetLengthSec: number;
  /** Defaults: 40 % of the target minimum; no maximum unless requested. */
  minLengthSec?: number;
  maxLengthSec?: number;
  deduplicate?: boolean;
  roundTimes?: boolean;
}

export type RejectionReason =
  | "sin-razon"
  | "solo-intensidad"
  | "frase-incompleta"
  | "sin-contexto"
  | "poco-interes"
  | "solapado"
  | "repetido"
  | "similar";

export const REJECTION_LABEL: Record<RejectionReason, string> = {
  "sin-razon": "Sin una razón identificable",
  "solo-intensidad": "Solo volumen o movimiento, sin contenido",
  "frase-incompleta": "Frases incompletas en el inicio o el final",
  "sin-contexto": "No se entiende sin contexto previo",
  "poco-interes": "Interés por debajo del umbral",
  solapado: "Se solapa con un clip mejor",
  repetido: "Repite lo que dice otro clip",
  similar: "Demasiado parecido a otro clip",
};

export interface SelectedMoment {
  candidateId: string;
  start: number;
  end: number;
  score: number;
  kind: MomentKind;
  reason: string;
  /** Human-readable supporting evidence, strongest first. */
  evidence: string[];
  breakdown: ScoreBreakdown;
}

export interface SelectionResult {
  engine: EngineKey;
  selected: SelectedMoment[];
  rejected: { candidateId: string; reason: RejectionReason }[];
}

const SENTENCE_END = /[.?!…]["»”)]*$/;
const PAUSE_SEC = 0.7;

/** Indices of words that start/end a sentence (punctuation or a long pause). */
export function sentenceBoundaries(words: Word[]) {
  const starts = new Set<number>();
  const ends = new Set<number>();
  words.forEach((w, i) => {
    const next = words[i + 1];
    const isEnd =
      !next || SENTENCE_END.test(w.text) || next.start - w.end >= PAUSE_SEC;
    if (isEnd) ends.add(i);
    if (i === 0 || ends.has(i - 1)) starts.add(i);
  });
  return { starts, ends };
}

/**
 * Moves [start, end] so that it begins at a sentence start and ends at a
 * sentence end, within `window` seconds. Returns null if impossible.
 */
export function snapToSentences(
  words: Word[],
  start: number,
  end: number,
  window: number,
) {
  if (!words.length) return { start, end };
  const { starts, ends } = sentenceBoundaries(words);
  // Start: latest sentence start at or before `start`, else the nearest after it.
  let s: number | null = null;
  for (let i = 0; i < words.length; i++) {
    const w = words[i]!;
    if (!starts.has(i)) continue;
    if (w.start <= start + 0.05 && start - w.start <= window) s = i;
  }
  if (s === null) {
    for (let i = 0; i < words.length; i++) {
      const w = words[i]!;
      if (starts.has(i) && w.start >= start && w.start - start <= window / 2) {
        s = i;
        break;
      }
    }
  }
  // End: earliest sentence end at or after `end`, else the nearest before it.
  let e: number | null = null;
  for (let i = 0; i < words.length; i++) {
    const w = words[i]!;
    if (ends.has(i) && w.end >= end - 0.05 && w.end - end <= window) {
      e = i;
      break;
    }
  }
  if (e === null) {
    for (let i = words.length - 1; i >= 0; i--) {
      const w = words[i]!;
      if (ends.has(i) && w.end <= end && end - w.end <= window / 2) {
        e = i;
        break;
      }
    }
  }
  // No speech inside the window at all: keep the window (e.g. silent gameplay).
  const spoken = words.some((w) => w.end > start && w.start < end);
  if (!spoken) return { start, end };
  if (s === null || e === null || words[e]!.end <= words[s]!.start) return null;
  return { start: words[s]!.start, end: words[e]!.end };
}

export function scoreMoment(c: MomentCandidate, engine: EngineKey) {
  const def = ENGINES[engine];
  const w = def.breakdownWeight;
  const b = c.breakdown;
  const base =
    b.interest * w.interest +
    b.emotion * w.emotion +
    b.entertainment * w.entertainment +
    b.context * w.context +
    b.impact * w.impact +
    b.hook * w.hook;
  // Signal support: semantic signals the engine cares about raise the score a little,
  // capped so detectors can't outvote the narrative judgement.
  const support = c.signals.reduce(
    (acc, s) => acc + (def.signalWeight[s.kind] ?? 0) * s.strength,
    0,
  );
  // Gaming: a visual event AND a streamer reaction together is worth more than either.
  const combo =
    engine === "gaming" &&
    c.signals.some((s) =>
      [
        "kill-feed",
        "multikill",
        "victory-screen",
        "defeat-screen",
        "death",
        "objective",
      ].includes(s.kind),
    ) &&
    c.signals.some((s) =>
      ["facecam-reaction", "shout", "laughter"].includes(s.kind),
    )
      ? 4
      : 0;
  return clamp(Math.round(base + Math.min(8, support * 2.5) + combo), 1, 100);
}

export function describeEvidence(signals: MomentSignal[], engine: EngineKey) {
  const def = ENGINES[engine];
  const byKind = new Map<string, { n: number; weight: number }>();
  for (const s of signals) {
    const cur = byKind.get(s.kind) ?? { n: 0, weight: 0 };
    byKind.set(s.kind, {
      n: cur.n + 1,
      weight: cur.weight + (def.signalWeight[s.kind] ?? 0) * s.strength,
    });
  }
  return [...byKind.entries()]
    .sort((a, b) => b[1].weight - a[1].weight)
    .map(
      ([k, v]) =>
        `${SIGNAL_LABEL[k as MomentSignal["kind"]]}${v.n > 1 ? ` ×${v.n}` : ""}`,
    );
}

const STOPWORDS = new Set(
  "a al algo como con de del el ella en es esa ese eso esta este esto ha la las le lo los me mi muy no o para pero por que se si sin su te tu tú un una uno y ya yo the and to of is it you i that this".split(
    " ",
  ),
);

export function tokens(words: Word[], start: number, end: number) {
  return new Set(
    words
      .filter((w) => w.start >= start && w.end <= end)
      .map((w) => w.text.toLowerCase().replace(/[^\p{L}\p{N}]/gu, ""))
      .filter((t) => t.length > 2 && !STOPWORDS.has(t)),
  );
}

export function jaccard(a: Set<string>, b: Set<string>) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter++;
  return inter / (a.size + b.size - inter);
}

export function overlapRatio(
  a: { start: number; end: number },
  b: { start: number; end: number },
) {
  const inter = Math.max(
    0,
    Math.min(a.end, b.end) - Math.max(a.start, b.start),
  );
  return inter / Math.min(a.end - a.start, b.end - b.start);
}

export function selectMoments(
  candidates: MomentCandidate[],
  words: Word[],
  engine: EngineKey,
  opts: SelectOptions,
): SelectionResult {
  const def = ENGINES[engine];
  const minLen = opts.minLengthSec ?? opts.targetLengthSec * 0.4;
  const maxLen = opts.maxLengthSec ?? Infinity;
  const rejected: SelectionResult["rejected"] = [];
  const pool: (SelectedMoment & { tokens: Set<string>; peak: number })[] = [];

  for (const c of candidates) {
    const reject = (reason: RejectionReason) =>
      rejected.push({ candidateId: c.id, reason });

    if (!c.reason.trim()) {
      reject("sin-razon");
      continue;
    }
    const semantic = c.signals.filter(
      (s) =>
        !INTENSITY_SIGNALS.has(s.kind) && (def.signalWeight[s.kind] ?? 0) > 0,
    );
    if (!semantic.length) {
      reject("solo-intensidad");
      continue;
    }
    if (c.needsPriorContext || c.breakdown.context < def.minContext) {
      reject("sin-contexto");
      continue;
    }

    // Engine-specific framing: gaming keeps the build-up and the reaction tail.
    let start = Math.max(0, c.start - def.preRollSec);
    let end = c.end + def.postRollSec;
    // Too short: add context around the window (more before for gaming build-up).
    if (end - start < minLen) {
      const grow = minLen - (end - start);
      const before = grow * (engine === "gaming" ? 0.6 : 0.5);
      start = Math.max(0, start - before);
      end = Math.max(end + grow - before, start + minLen);
    }
    const snapped = snapToSentences(words, start, end, def.snapWindowSec);
    if (!snapped || snapped.end - snapped.start > maxLen) {
      reject("frase-incompleta");
      continue;
    }
    if (snapped.end - snapped.start < minLen * 0.75) {
      reject("frase-incompleta");
      continue;
    }

    const score = scoreMoment(c, engine);
    if (score < def.minScore) {
      reject("poco-interes");
      continue;
    }
    pool.push({
      candidateId: c.id,
      start: opts.roundTimes === false ? snapped.start : round1(snapped.start),
      end: opts.roundTimes === false ? snapped.end : round1(snapped.end),
      score,
      kind: c.kind,
      reason: c.reason.trim(),
      evidence: describeEvidence(c.signals, engine),
      breakdown: c.breakdown,
      tokens: tokens(words, snapped.start, snapped.end),
      peak: c.peak ?? (c.start + c.end) / 2,
    });
  }

  pool.sort((a, b) => b.score - a.score);
  const kept: typeof pool = [];
  for (const m of pool) {
    const reject = (reason: RejectionReason) =>
      rejected.push({ candidateId: m.candidateId, reason });
    if (
      opts.deduplicate !== false &&
      kept.some((k) => overlapRatio(k, m) > 0.35)
    ) {
      reject("solapado");
      continue;
    }
    if (
      opts.deduplicate !== false &&
      kept.some((k) => jaccard(k.tokens, m.tokens) > 0.55)
    ) {
      reject("repetido");
      continue;
    }
    // Same kind of moment a short while apart (e.g. two kills in the same round
    // that were not merged, or the same joke retold): keep only the best one.
    if (
      opts.deduplicate !== false &&
      kept.some((k) => k.kind === m.kind && Math.abs(k.peak - m.peak) < 90)
    ) {
      reject("similar");
      continue;
    }
    kept.push(m);
  }

  return {
    engine,
    selected: kept.map((m) => {
      const { tokens, peak, ...rest } = m;
      void tokens;
      void peak;
      return rest;
    }),
    rejected,
  };
}

export function summarizeRejections(rejected: SelectionResult["rejected"]) {
  const out: Partial<Record<RejectionReason, number>> = {};
  for (const r of rejected) out[r.reason] = (out[r.reason] ?? 0) + 1;
  return out;
}

const clamp = (n: number, lo: number, hi: number) =>
  Math.min(hi, Math.max(lo, n));
const round1 = (n: number) => Math.round(n * 10) / 10;
