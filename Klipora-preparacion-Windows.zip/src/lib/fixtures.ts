/**
 * STUB DATA — the only source of sample content in the app.
 *
 * Milestone 1 renders the product surface against these fixtures. In
 * milestone 2+ (see PLAN.md) every export here is replaced by calls to the
 * projects API; components only depend on the types in `./types`.
 */
import type { MomentKind } from "./analysis/content";
import type {
  CaptionSegment,
  Clip,
  MomentTag,
  Project,
  ScoreBreakdown,
  StageKey,
  StageState,
} from "./types";
import { PIPELINE_STAGES } from "./types";

/** Builds word-level timings for a line; `*word` marks emphasis. */
function line(
  id: string,
  start: number,
  end: number,
  text: string,
): CaptionSegment {
  const tokens = text.split(" ");
  const step = (end - start) / tokens.length;
  return {
    id,
    start,
    end,
    words: tokens.map((t, i) => ({
      text: t.replace(/^\*/, ""),
      emphasis: t.startsWith("*"),
      start: +(start + i * step).toFixed(2),
      end: +(start + (i + 1) * step - 0.04).toFixed(2),
    })),
  };
}

function stages(
  upTo: StageKey | "all",
  running?: { progress: number; detail?: string },
  failed?: string,
): StageState[] {
  const idx =
    upTo === "all"
      ? PIPELINE_STAGES.length
      : PIPELINE_STAGES.findIndex((s) => s.key === upTo);
  return PIPELINE_STAGES.map((s, i) => {
    if (i < idx) return { key: s.key, progress: 100, status: "done" };
    if (i === idx && failed)
      return {
        key: s.key,
        progress: running?.progress ?? 0,
        status: "error",
        detail: failed,
      };
    if (i === idx && running)
      return {
        key: s.key,
        progress: running.progress,
        status: "running",
        detail: running.detail,
      };
    return { key: s.key, progress: 0, status: "pending" };
  });
}

interface ClipSeed {
  kind: MomentKind;
  evidence: string[];
  start: number;
  len: number;
  score: number;
  breakdown: ScoreBreakdown;
  tags: MomentTag[];
  reason: string;
  title: string;
  description: string;
  hook: string;
  hashtags: string[];
  platform: Clip["platform"];
  postingTip: string;
  lines: string[];
  hue: number;
  favorite?: boolean;
}

function buildClips(
  projectId: string,
  seeds: ClipSeed[],
  defaults: Pick<Clip, "aspect" | "resolution">,
): Clip[] {
  return seeds
    .sort((a, b) => b.score - a.score)
    .map((s, i) => {
      const per = s.len / s.lines.length;
      return {
        id: `${projectId}-c${i + 1}`,
        projectId,
        rank: i + 1,
        start: s.start,
        end: s.start + s.len,
        score: s.score,
        breakdown: s.breakdown,
        tags: s.tags,
        kind: s.kind,
        reason: s.reason,
        evidence: s.evidence,
        title: s.title,
        description: s.description,
        hook: s.hook,
        hashtags: s.hashtags,
        platform: s.platform,
        postingTip: s.postingTip,
        favorite: s.favorite ?? false,
        captions: s.lines.map((l, j) =>
          line(
            `${projectId}-c${i + 1}-s${j}`,
            +(j * per).toFixed(2),
            +((j + 1) * per - 0.15).toFixed(2),
            l,
          ),
        ),
        hue: s.hue,
        ...defaults,
      };
    });
}

const p1 = "p_valorant_clutch";
const p2 = "p_podcast_emprender";

export const projects: Project[] = [
  {
    id: p1,
    title: "Ranked hasta Inmortal — 1v4 y rage final",
    source: "twitch",
    sourceUrl: "https://www.twitch.tv/videos/2290417733",
    channel: "nekko_plays",
    durationSec: 3 * 3600 + 12 * 60 + 41,
    language: "es",
    createdAt: "2026-11-17T13:05:00Z",
    status: "completed",
    stages: stages("all"),
    clipLengthTarget: 30,
    aspect: "9:16",
    resolution: "1080p",
    contentMode: "auto",
    classification: {
      mode: "auto",
      engine: "gaming",
      category: "valorant",
      confidence: 0.93,
      decidedBy: "auto",
      evidence: [
        "HUD de videojuego en el 94% de los fotogramas",
        "Categoría en la plataforma: VALORANT",
        "El título o las etiquetas mencionan Valorant",
        "Vocabulario de juego en la transcripción (212 términos)",
        "Cámara del streamer superpuesta al juego",
      ],
    },
    selection: {
      candidates: 31,
      rejected: {
        "solo-intensidad": 9,
        "sin-contexto": 4,
        "frase-incompleta": 3,
        similar: 6,
        "poco-interes": 4,
      },
    },
    hue: 145,
    clips: buildClips(
      p1,
      [
        {
          kind: "multikill",
          evidence: [
            "Varias eliminaciones seguidas ×4",
            "Vida crítica",
            "Grito",
            "Reacción en la cámara",
            "Pico de actividad en el chat",
          ],

          start: 6512,
          len: 34,
          score: 94,
          breakdown: {
            interest: 96,
            emotion: 98,
            entertainment: 92,
            context: 88,
            impact: 95,
            hook: 97,
          },
          tags: ["jugada", "grito", "victoria"],
          reason:
            "Cuatro eliminaciones con 3 de vida en la ronda decisiva, con grito y celebración del streamer al cerrar. El 1v4 se entiende sin contexto previo.",
          title: "1 contra 4 con 3 de vida… y lo gana",
          description:
            "Ronda decisiva en ranked: queda solo contra cuatro y lo remonta con el Sheriff. Mira la reacción al final.",
          hook: "¿Se puede ganar un 1v4 con 3 de vida?",
          hashtags: ["#valorant", "#clutch", "#gaming", "#twitchclips", "#1v4"],
          platform: "TikTok",
          postingTip:
            "Publica entre 19:00 y 22:00. Empieza en el último disparo como gancho y deja la ronda completa después.",
          lines: [
            "Vale vale *tres de vida",
            "quedan *cuatro tío",
            "uno… *DOS",
            "NO ME LO *CREO",
            "*TRES Y CUATRO",
            "CHAT LO HE *HECHO",
          ],
          hue: 145,
          favorite: true,
        },
        {
          kind: "derrota",
          evidence: [
            "Pantalla de derrota",
            "Reacción en la cámara",
            "Risas",
            "Cambio de turno de palabra",
          ],

          start: 11420,
          len: 29,
          score: 88,
          breakdown: {
            interest: 85,
            emotion: 97,
            entertainment: 93,
            context: 80,
            impact: 86,
            hook: 88,
          },
          tags: ["derrota", "reacción", "gracioso"],
          reason:
            "Cambio brusco de tono y risa del streamer tras la derrota. Alta densidad de palabras emocionales.",
          title: "Pierde el ascenso por 1 ronda y reacciona así",
          description:
            "A una ronda de Inmortal, el equipo se desconecta. La reacción vale más que la partida.",
          hook: "A UNA ronda de subir…",
          hashtags: ["#valorant", "#rage", "#streamer", "#ranked"],
          platform: "YouTube Shorts",
          postingTip:
            'Título con número concreto ("1 ronda") mejora la retención en Shorts.',
          lines: [
            "Una ronda *una",
            "y se *desconecta",
            "me estás *vacilando",
            "me voy a *dormir chat",
            "mañana *Inmortal",
          ],
          hue: 20,
        },
        {
          kind: "gracioso",
          evidence: ["Remate", "Risas ×2", "Voces superpuestas"],

          start: 2210,
          len: 31,
          score: 81,
          breakdown: {
            interest: 80,
            emotion: 74,
            entertainment: 86,
            context: 84,
            impact: 79,
            hook: 82,
          },
          tags: ["gracioso", "discusión"],
          reason:
            "Intercambio rápido con un compañero, risas en ambas voces y remate verbal claro.",
          title: "Su compañero le pide la Operator y pasa esto",
          description:
            "Negociación de economía que termina mal para todos. Momento de comunicación de equipo.",
          hook: '"Dame la Op y te la devuelvo"',
          hashtags: ["#valorant", "#humor", "#gamingclips"],
          platform: "Instagram Reels",
          postingTip:
            "Añade texto en pantalla con la frase del compañero para quien vea sin sonido.",
          lines: [
            "¿Me das la *Op?",
            "te la *devuelvo",
            "te lo *prometo",
            "y la tira al *suelo",
            "cómo que la *pierdes",
          ],
          hue: 280,
        },
        {
          kind: "competitivo",
          evidence: [
            "Objetivo de la partida",
            "Silencio seguido de reacción",
            "Vida crítica",
            "Grito",
          ],

          start: 8840,
          len: 45,
          score: 74,
          breakdown: {
            interest: 76,
            emotion: 70,
            entertainment: 72,
            context: 78,
            impact: 71,
            hook: 75,
          },
          tags: ["tensión", "jugada"],
          reason:
            "Defuse con la ronda en juego: el silencio del streamer mientras desactiva y el grito final dan inicio y cierre al momento.",
          title: "Defuse con 0.2 segundos de margen",
          description:
            "Desactiva la Spike en el último instante mientras le disparan desde dos ángulos.",
          hook: "Cuenta los segundos…",
          hashtags: ["#valorant", "#defuse", "#clutchmoments"],
          platform: "TikTok",
          postingTip: "Mantén el contador visible: es el gancho visual.",
          lines: [
            "Voy a *tapear",
            "no no no *no",
            "aguanta *aguanta",
            "*DEFUSE",
            "cero coma *dos",
          ],
          hue: 200,
        },
        {
          kind: "fail",
          evidence: ["Frase citable", "Muerte del jugador", "Risas"],

          start: 4105,
          len: 27,
          score: 66,
          breakdown: {
            interest: 64,
            emotion: 62,
            entertainment: 70,
            context: 66,
            impact: 63,
            hook: 69,
          },
          tags: ["frase", "reacción"],
          reason:
            "Da un consejo de aim con total seguridad y muere al instante: el contraste entre la frase y la jugada es el chiste.",
          title: '"El aim no se entrena, se siente"',
          description:
            "Consejo improvisado que acaba con la peor ronda de la partida.",
          hook: "Consejo de aim gratis",
          hashtags: ["#valorant", "#aim", "#tips"],
          platform: "YouTube Shorts",
          postingTip:
            "Funciona mejor como contenido irónico: menciona el resultado en la descripción.",
          lines: [
            "El aim no se *entrena",
            "se *siente",
            "mirad *esto",
            "vale *no",
          ],
          hue: 50,
        },
      ],
      { aspect: "9:16", resolution: "1080p" },
    ),
  },
  {
    id: p2,
    title: "De 0 a 1M: lo que nadie te cuenta de emprender",
    source: "youtube",
    sourceUrl: "https://www.youtube.com/watch?v=Xk3pL9mQ2rT",
    channel: "Charla Abierta Podcast",
    durationSec: 1 * 3600 + 47 * 60 + 9,
    language: "es",
    createdAt: "2026-11-16T09:40:00Z",
    status: "completed",
    stages: stages("all"),
    clipLengthTarget: 45,
    aspect: "9:16",
    resolution: "1080p",
    contentMode: "auto",
    classification: {
      mode: "auto",
      engine: "general",
      category: "podcast",
      confidence: 0.88,
      decidedBy: "auto",
      evidence: [
        "Personas a cámara en el 91% del video",
        "El título o las etiquetas indican podcast",
        "2 voces y habla continua (93%)",
        "No aparece interfaz de videojuego en los fotogramas",
      ],
    },
    selection: {
      candidates: 18,
      rejected: {
        "sin-contexto": 5,
        "frase-incompleta": 4,
        repetido: 3,
        "poco-interes": 3,
      },
    },
    hue: 260,
    clips: buildClips(
      p2,
      [
        {
          kind: "respuesta-inesperada",
          evidence: [
            "Respuesta inesperada",
            "Frase citable",
            "Explicación completa",
          ],

          start: 1312,
          len: 44,
          score: 86,
          breakdown: {
            interest: 90,
            emotion: 78,
            entertainment: 80,
            context: 92,
            impact: 93,
            hook: 88,
          },
          tags: ["frase", "sorpresa"],
          reason:
            "Afirmación contraintuitiva con cifra concreta; el invitado cierra la idea dentro del segmento.",
          title: "Por qué cerró su primera empresa con 40.000 € en ventas",
          description:
            "El invitado explica cómo las ventas escondían un problema de márgenes y qué haría distinto.",
          hook: "Vender mucho casi me arruina",
          hashtags: ["#emprendimiento", "#negocios", "#podcast", "#startups"],
          platform: "Instagram Reels",
          postingTip:
            "Usa la cifra en la portada. Mejor en Reels entre semana por la mañana.",
          lines: [
            "Vender mucho casi me *arruina",
            "facturábamos *cuarenta mil",
            "pero cada pedido *perdía dinero",
            "nadie mira los *márgenes",
            "hasta que es *tarde",
          ],
          hue: 260,
          favorite: true,
        },
        {
          kind: "debate",
          evidence: [
            "Desacuerdo",
            "Cambio de turno de palabra ×6",
            "Opinión clara",
          ],

          start: 3120,
          len: 38,
          score: 79,
          breakdown: {
            interest: 82,
            emotion: 85,
            entertainment: 70,
            context: 77,
            impact: 80,
            hook: 76,
          },
          tags: ["discusión", "tensión"],
          reason:
            "Desacuerdo entre presentador e invitado con turnos rápidos; ambas posturas quedan claras.",
          title: "¿Hay que dejar el trabajo para emprender?",
          description:
            "Presentador e invitado no se ponen de acuerdo sobre cuándo dar el salto.",
          hook: "No dejes tu trabajo. Todavía.",
          hashtags: ["#emprender", "#trabajo", "#debate"],
          platform: "TikTok",
          postingTip:
            "Invita a comentar con una pregunta en la descripción: el debate genera respuestas.",
          lines: [
            "No dejes tu *trabajo",
            "*todavía",
            "yo no estoy de *acuerdo",
            "sin riesgo no hay *nada",
            "el riesgo *calculado",
          ],
          hue: 330,
        },
        {
          kind: "historia",
          evidence: ["Historia con inicio y desenlace", "Remate", "Risas"],

          start: 5402,
          len: 30,
          score: 71,
          breakdown: {
            interest: 72,
            emotion: 60,
            entertainment: 74,
            context: 78,
            impact: 70,
            hook: 72,
          },
          tags: ["gracioso", "frase"],
          reason:
            "Anécdota con risa compartida y remate claro en los últimos 5 segundos.",
          title: "El primer cliente que pagó con… vales de comida",
          description:
            "Una anécdota de los inicios que ningún plan de negocio contempla.",
          hook: "Mi primer cliente me pagó así",
          hashtags: ["#emprendedores", "#historias", "#humor"],
          platform: "YouTube Shorts",
          postingTip: "Corta justo después de la risa para un final limpio.",
          lines: [
            "Mi primer *cliente",
            "me pagó con *vales",
            "de *comida",
            "y los *aceptamos",
          ],
          hue: 30,
        },
      ],
      { aspect: "9:16", resolution: "1080p" },
    ),
  },
  {
    id: "p_kick_irl",
    title: "IRL por Madrid — reto 24 h sin dinero",
    source: "kick",
    sourceUrl: "https://kick.com/elviajero/videos/9b1f2c3d",
    channel: "elviajero",
    durationSec: 5 * 3600 + 2 * 60,
    language: "es",
    createdAt: "2026-11-17T16:12:00Z",
    status: "processing",
    stages: stages("transcribing", {
      progress: 62,
      detail: "faster-whisper large-v3 · bloque 19 de 31",
    }),
    clipLengthTarget: 60,
    aspect: "9:16",
    resolution: "1080p",
    contentMode: "auto",
    classification: {
      mode: "auto",
      engine: "general",
      category: "conversacion",
      confidence: 0.71,
      decidedBy: "auto",
      evidence: [
        "Categoría en la plataforma: IRL",
        "No aparece interfaz de videojuego en los fotogramas",
        "El título o las etiquetas indican conversación",
      ],
    },
    hue: 310,
    clips: [],
  },
  {
    id: "p_upload_boda",
    title: "discurso_padrino_final.mkv",
    source: "upload",
    durationSec: 22 * 60 + 18,
    language: "es",
    createdAt: "2026-11-15T20:02:00Z",
    status: "failed",
    stages: stages(
      "preparing",
      { progress: 34 },
      "FFmpeg: pista de audio ilegible",
    ),
    error: {
      stage: "preparing",
      message: "No pudimos leer la pista de audio del archivo.",
      cause:
        "El archivo usa un códec de audio no compatible (pcm_s24be en MKV) o está incompleto. Vuelve a exportarlo como MP4 con audio AAC, o reintenta para forzar la conversión.",
    },
    clipLengthTarget: 30,
    aspect: "9:16",
    resolution: "720p",
    contentMode: "general",
    hue: 15,
    clips: [],
  },
];

export function getProject(id: string) {
  return projects.find((p) => p.id === id);
}

export function getClip(projectId: string, clipId: string) {
  return getProject(projectId)?.clips.find((c) => c.id === clipId);
}
