/**
 * Domain model for Klipora. These types are the contract between the UI and
 * the future processing backend (see PLAN.md). Keep them in sync with the
 * API schema when the backend lands.
 */

import type { ContentClassification } from "./analysis/classifier";
import type { ContentMode, MomentKind } from "./analysis/content";
import type { RejectionReason } from "./analysis/selection";

export type SourcePlatform = "youtube" | "twitch" | "kick" | "upload";

/** Ordered processing stages, matching the worker pipeline. */
export const PIPELINE_STAGES = [
  { key: "uploading", label: "Subiendo video" },
  { key: "preparing", label: "Preparando archivo" },
  { key: "analyzing", label: "Identificando tipo de contenido" },
  { key: "transcribing", label: "Transcribiendo audio" },
  { key: "detecting", label: "Detectando momentos destacados" },
  { key: "generating", label: "Generando clips" },
  { key: "captioning", label: "Aplicando subtítulos" },
  { key: "rendering", label: "Renderizando videos" },
  { key: "completed", label: "Completado" },
] as const;

export type StageKey = (typeof PIPELINE_STAGES)[number]["key"];

export type ProjectStatus = "processing" | "completed" | "failed";

export interface StageState {
  key: StageKey;
  /** 0–100 progress reported by the worker for this stage. */
  progress: number;
  status: "pending" | "running" | "done" | "error";
  detail?: string;
}

export interface Project {
  id: string;
  title: string;
  source: SourcePlatform;
  sourceUrl?: string;
  channel?: string;
  durationSec: number;
  language: "es" | "en";
  createdAt: string;
  status: ProjectStatus;
  stages: StageState[];
  error?: { stage: StageKey; message: string; cause: string };
  clipLengthTarget: number;
  aspect: AspectRatio;
  resolution: Resolution;
  /** Engine requested on import. */
  contentMode: ContentMode;
  /** Set once the "analyzing" stage has identified the content type. */
  classification?: ContentClassification;
  /** How many candidate moments were evaluated and why the rest were discarded. */
  selection?: {
    candidates: number;
    rejected: Partial<Record<RejectionReason, number>>;
  };
  clips: Clip[];
  /** Gradient used as a placeholder poster until real thumbnails exist. */
  hue: number;
}

export type AspectRatio = "9:16" | "16:9" | "1:1" | "4:5";
export type Resolution = "720p" | "1080p";
export type FramingMode =
  | "face-track"
  | "subject-track"
  | "gameplay-track"
  | "blur-fill"
  | "streamer-split"
  | "manual";

export type MomentTag =
  | "gracioso"
  | "reacción"
  | "grito"
  | "tensión"
  | "discusión"
  | "frase"
  | "sorpresa"
  | "jugada"
  | "victoria"
  | "derrota";

export interface Word {
  text: string;
  start: number;
  end: number;
  emphasis?: boolean;
}

export interface CaptionSegment {
  id: string;
  start: number;
  end: number;
  words: Word[];
}

export interface ScoreBreakdown {
  interest: number;
  emotion: number;
  entertainment: number;
  context: number;
  impact: number;
  hook: number;
}

export interface Clip {
  id: string;
  projectId: string;
  rank: number;
  /** Seconds in the source video. */
  start: number;
  end: number;
  score: number;
  breakdown: ScoreBreakdown;
  tags: MomentTag[];
  /** Moment type from the engine that selected the clip. */
  kind: MomentKind;
  /** Identifiable reason for the selection. Never empty. */
  reason: string;
  /** Signals that supported the selection, strongest first. */
  evidence: string[];
  title: string;
  description: string;
  hook: string;
  hashtags: string[];
  platform: "TikTok" | "YouTube Shorts" | "Instagram Reels";
  postingTip: string;
  resolution: Resolution;
  aspect: AspectRatio;
  favorite: boolean;
  captions: CaptionSegment[];
  hue: number;
}

export const ASPECT_OPTIONS: {
  value: AspectRatio;
  label: string;
  hint: string;
}[] = [
  { value: "9:16", label: "9:16", hint: "TikTok · Reels · Shorts" },
  { value: "16:9", label: "16:9", hint: "YouTube horizontal" },
  { value: "1:1", label: "1:1", hint: "Feed cuadrado" },
  { value: "4:5", label: "4:5", hint: "Instagram feed" },
];

export const FRAMING_OPTIONS: {
  value: FramingMode;
  label: string;
  hint: string;
}[] = [
  {
    value: "face-track",
    label: "Seguir rostro",
    hint: "Mantiene la cara centrada",
  },
  {
    value: "subject-track",
    label: "Seguir sujeto",
    hint: "Sigue al sujeto principal",
  },
  {
    value: "gameplay-track",
    label: "Recorte inteligente del gameplay",
    hint: "Acción ampliada y juego completo debajo",
  },
  {
    value: "blur-fill",
    label: "Completo + desenfoque",
    hint: "Sin recortes, fondo difuminado",
  },
  {
    value: "streamer-split",
    label: "Cámara arriba / juego abajo",
    hint: "Ideal para streams",
  },
  { value: "manual", label: "Recorte manual", hint: "Tú eliges la zona" },
];

export const CLIP_LENGTHS = [15, 30, 45, 60, 90] as const;
