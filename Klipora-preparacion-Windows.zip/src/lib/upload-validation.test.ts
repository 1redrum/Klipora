import { afterEach, describe, expect, it, vi } from "vitest";
import { checkVideoFile } from "./upload-validation";

function mockVideo(duration: number, fails = false) {
  const video = document.createElement("video");
  Object.defineProperties(video, {
    duration: { value: duration },
    videoWidth: { value: 1920 },
    videoHeight: { value: 1080 },
    src: {
      set: () =>
        queueMicrotask(() =>
          video.dispatchEvent(new Event(fails ? "error" : "loadedmetadata")),
        ),
    },
  });
  vi.spyOn(document, "createElement").mockReturnValue(video);
  vi.stubGlobal("URL", {
    createObjectURL: vi.fn(() => "blob:video"),
    revokeObjectURL: vi.fn(),
  });
}

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("personal-use video validation", () => {
  it("accepts a 12-hour source larger than 10 GB without reading it into memory", async () => {
    mockVideo(12 * 3600);
    const file = new File(["video"], "stream.mp4");
    Object.defineProperty(file, "size", { value: 50 * 1024 ** 3 });
    expect(await checkVideoFile(file)).toMatchObject({
      ok: true,
      durationSec: 12 * 3600,
    });
  });

  it("accepts short videos without a minimum content quota", async () => {
    mockVideo(3);
    expect(
      await checkVideoFile(new File(["video"], "short.mp4")),
    ).toMatchObject({ ok: true, durationSec: 3 });
  });

  it("defers unsupported browser codecs to the media executor", async () => {
    mockVideo(0, true);
    expect(
      await checkVideoFile(new File(["video"], "codec.mp4")),
    ).toMatchObject({ ok: true, needsServerProbe: true });
  });

  it("still rejects empty files and unsupported formats", async () => {
    expect((await checkVideoFile(new File([], "empty.mp4"))).ok).toBe(false);
    expect((await checkVideoFile(new File(["text"], "notes.txt"))).ok).toBe(
      false,
    );
  });

  it("rejects a source with no playable duration", async () => {
    mockVideo(0);
    expect((await checkVideoFile(new File(["video"], "invalid.mp4"))).ok).toBe(
      false,
    );
  });
});
