export function formatDuration(totalSec: number) {
  const s = Math.max(0, Math.round(totalSec))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  const mm = h ? String(m).padStart(2, '0') : String(m)
  return `${h ? `${h}:` : ''}${mm}:${String(sec).padStart(2, '0')}`
}

/** Timestamp with tenths, used in the editor. */
export function formatTimecode(sec: number) {
  const s = Math.max(0, sec)
  const m = Math.floor(s / 60)
  const rest = s - m * 60
  return `${m}:${rest.toFixed(1).padStart(4, '0')}`
}

export function formatRelative(iso: string, now = new Date('2026-11-17T16:30:00Z')) {
  const diff = (now.getTime() - new Date(iso).getTime()) / 1000
  if (diff < 3600) return `hace ${Math.max(1, Math.round(diff / 60))} min`
  if (diff < 86400) return `hace ${Math.round(diff / 3600)} h`
  return `hace ${Math.round(diff / 86400)} d`
}

export function scoreTone(score: number) {
  if (score >= 85) return 'hot'
  if (score >= 70) return 'warm'
  return 'cool'
}
