/** Client-side checks run before a file is streamed to the local server. */

export const ACCEPTED_EXTENSIONS = [
  "mp4",
  "mov",
  "mkv",
  "avi",
  "webm",
  "m4v",
  "flv",
] as const;
export const ACCEPT_ATTR =
  ACCEPTED_EXTENSIONS.map((e) => `.${e}`).join(",") + ",video/*";

export interface FileCheck {
  ok: boolean;
  error?: string;
  extension: string;
  /** Duration read from the container, when the browser can decode it. */
  durationSec?: number;
  width?: number;
  height?: number;
  /** Browser can't decode (e.g. MKV/AVI/FLV): the server's FFmpeg will. */
  needsServerProbe?: boolean;
}

export function extensionOf(name: string) {
  return name.split(".").pop()?.toLowerCase() ?? "";
}

/** Reads metadata through a detached <video> element; never loads the whole file. */
function probeInBrowser(
  file: File,
): Promise<{ duration: number; width: number; height: number } | null> {
  return new Promise((resolve) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    const url = URL.createObjectURL(file);
    const done = (
      v: { duration: number; width: number; height: number } | null,
    ) => {
      URL.revokeObjectURL(url);
      video.removeAttribute("src");
      resolve(v);
    };
    const timer = window.setTimeout(() => done(null), 8000);
    video.onloadedmetadata = () => {
      window.clearTimeout(timer);
      done({
        duration: video.duration,
        width: video.videoWidth,
        height: video.videoHeight,
      });
    };
    video.onerror = () => {
      window.clearTimeout(timer);
      done(null);
    };
    video.src = url;
  });
}

export async function checkVideoFile(file: File): Promise<FileCheck> {
  const extension = extensionOf(file.name);
  if (!(ACCEPTED_EXTENSIONS as readonly string[]).includes(extension)) {
    return {
      ok: false,
      extension,
      error: `Formato .${extension || "?"} no compatible. Usa MP4, MOV, MKV, AVI, WEBM, M4V o FLV.`,
    };
  }
  if (file.size === 0)
    return { ok: false, extension, error: "El archivo está vacío." };

  const meta = await probeInBrowser(file);
  if (!meta || !Number.isFinite(meta.duration)) {
    return { ok: true, extension, needsServerProbe: true };
  }
  if (meta.duration <= 0) {
    return {
      ok: false,
      extension,
      error: "El video no tiene una duración válida.",
    };
  }
  if (meta.width === 0 && meta.height === 0) {
    return {
      ok: false,
      extension,
      error: "El archivo no contiene una pista de video legible.",
    };
  }
  return {
    ok: true,
    extension,
    durationSec: meta.duration,
    width: meta.width,
    height: meta.height,
  };
}

export function formatBytes(bytes: number) {
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = bytes;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}
