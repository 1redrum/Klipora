// @vitest-environment node
import { describe, expect, it } from "vitest";
import { execLocal, runLocal } from "../../local/processes";

describe("procesos locales", () => {
  it("conserva argumentos y salida UTF-8 sin pasar por un shell", async () => {
    const text = "grabación ñ 'sesión'";
    const { stdout } = await execLocal(process.execPath, [
      "-e",
      "process.stdout.write(process.argv[1])",
      text,
    ]);
    expect(stdout).toBe(text);
    await expect(
      execLocal("klipora-comando-inexistente", []),
    ).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("cancela una ejecución y devuelve el motivo de cierre", async () => {
    const controller = new AbortController();
    const reason = new Error("Cierre de prueba");
    const result = runLocal({ signal: controller.signal }, () =>
      execLocal(process.execPath, ["-e", "setInterval(()=>{},1000)"]),
    );
    const timer = setTimeout(() => controller.abort(reason), 120);
    try {
      await expect(result).rejects.toBe(reason);
    } finally {
      clearTimeout(timer);
    }
  });
});
