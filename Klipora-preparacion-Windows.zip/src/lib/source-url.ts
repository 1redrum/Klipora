import type { SourcePlatform } from "./types.ts";

export type ParsedSource =
  | {
      ok: true;
      platform: Exclude<SourcePlatform, "upload">;
      kind: "video" | "short" | "live" | "vod" | "clip";
      id: string;
      canonicalUrl: string;
      /** Thumbnail we can show before the backend fetches metadata. */
      thumbnailUrl?: string;
    }
  | { ok: false; error: string };

const YT_ID = /^[A-Za-z0-9_-]{11}$/;

/**
 * Detects the platform and content id of a pasted link. Runs fully on the
 * client for instant feedback; the backend re-validates and fetches metadata.
 */
export function parseSourceUrl(raw: string): ParsedSource {
  const input = raw.trim();
  if (!input) return { ok: false, error: "Pega un enlace para continuar." };

  let url: URL;
  try {
    url = new URL(/^https?:\/\//i.test(input) ? input : `https://${input}`);
  } catch {
    return { ok: false, error: "El enlace no tiene un formato válido." };
  }

  const host = url.hostname.replace(/^(www\.|m\.)/, "").toLowerCase();
  const parts = url.pathname.split("/").filter(Boolean);

  // YouTube
  if (
    host === "youtu.be" ||
    host === "youtube.com" ||
    host === "music.youtube.com"
  ) {
    let id: string | null = null;
    let kind: "video" | "short" | "live" = "video";
    if (host === "youtu.be") id = parts[0] ?? null;
    else if (parts[0] === "watch") id = url.searchParams.get("v");
    else if (parts[0] === "shorts") {
      id = parts[1] ?? null;
      kind = "short";
    } else if (parts[0] === "live") {
      id = parts[1] ?? null;
      kind = "live";
    } else if (parts[0] === "embed") id = parts[1] ?? null;
    if (!id || !YT_ID.test(id)) {
      return {
        ok: false,
        error: "Es un enlace de YouTube, pero no apunta a un video concreto.",
      };
    }
    return {
      ok: true,
      platform: "youtube",
      kind,
      id,
      canonicalUrl: `https://www.youtube.com/watch?v=${id}`,
      thumbnailUrl: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    };
  }

  // Twitch
  if (host === "twitch.tv" || host === "clips.twitch.tv") {
    if (host === "clips.twitch.tv" && parts[0]) {
      return {
        ok: true,
        platform: "twitch",
        kind: "clip",
        id: parts[0],
        canonicalUrl: `https://clips.twitch.tv/${parts[0]}`,
      };
    }
    if (parts[0] === "videos" && /^\d+$/.test(parts[1] ?? "")) {
      return {
        ok: true,
        platform: "twitch",
        kind: "vod",
        id: parts[1]!,
        canonicalUrl: `https://www.twitch.tv/videos/${parts[1]}`,
      };
    }
    if (parts[1] === "clip" && parts[2]) {
      return {
        ok: true,
        platform: "twitch",
        kind: "clip",
        id: parts[2],
        canonicalUrl: `https://clips.twitch.tv/${parts[2]}`,
      };
    }
    if (parts.length === 1) {
      return {
        ok: false,
        error:
          "Es un canal de Twitch. Pega el enlace de un VOD (twitch.tv/videos/…) o de un clip; las emisiones en directo no se pueden procesar.",
      };
    }
    return { ok: false, error: "No reconocemos este enlace de Twitch." };
  }

  // Kick
  if (host === "kick.com") {
    if (parts[1] === "videos" && parts[2]) {
      return {
        ok: true,
        platform: "kick",
        kind: "vod",
        id: parts[2],
        canonicalUrl: `https://kick.com/${parts[0]}/videos/${parts[2]}`,
      };
    }
    if (parts[0] === "video" && parts[1]) {
      return {
        ok: true,
        platform: "kick",
        kind: "vod",
        id: parts[1],
        canonicalUrl: `https://kick.com/video/${parts[1]}`,
      };
    }
    if ((parts[1] === "clips" || parts[1] === "clip") && parts[2]) {
      return {
        ok: true,
        platform: "kick",
        kind: "clip",
        id: parts[2],
        canonicalUrl: `https://kick.com/${parts[0]}/clips/${parts[2]}`,
      };
    }
    if (parts.length === 1) {
      return {
        ok: false,
        error:
          "Es un canal de Kick. Pega el enlace de un VOD o de un clip concreto.",
      };
    }
    return { ok: false, error: "No reconocemos este enlace de Kick." };
  }

  return {
    ok: false,
    error:
      "Solo admitimos enlaces de YouTube, Twitch y Kick. Para otras fuentes, sube el archivo.",
  };
}

export const PLATFORM_LABEL: Record<SourcePlatform, string> = {
  youtube: "YouTube",
  twitch: "Twitch",
  kick: "Kick",
  upload: "Archivo subido",
};
