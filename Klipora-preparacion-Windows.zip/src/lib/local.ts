import type { AspectRatio, Resolution } from "./types.ts";

import type { ContentClassification } from "./analysis/classifier.ts";
import type { SelectedMoment } from "./analysis/selection.ts";

export type LocalMoment = Pick<
  SelectedMoment,
  "score" | "kind" | "reason" | "evidence" | "breakdown"
>;

export interface LocalProject {
  id: string;
  title: string;
  createdAt: string;
  status: "queued" | "processing" | "completed" | "failed";
  phase: string;
  devices?: Partial<
    Record<"whisper" | "vision" | "llm" | "encoder" | "ocr" | "audio", string>
  >;
  error?: string;
  duration: number;
  progress: number;
  classification?: ContentClassification;
  evaluated?: number;
  clips: {
    id: string;
    start: number;
    end: number;
    title: string;
    resolution: Resolution;
    encoder?: string;
    aspect?: AspectRatio;
    moment?: LocalMoment;
  }[];
  aspect: AspectRatio;
}

export const localApi = "/api/local/projects";
export const localId = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/;

export async function localRequest<T>(
  path: string,
  options?: RequestInit,
): Promise<T> {
  const response = await fetch(localApi + path, options);
  if (!response.headers.get("content-type")?.includes("application/json")) {
    throw new Error("Inicia Klipora en modo local con pnpm dev.");
  }
  const data = await response.json();
  if (!response.ok) throw new Error(data.error);
  return data as T;
}
