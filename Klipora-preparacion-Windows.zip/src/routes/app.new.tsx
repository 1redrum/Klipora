import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  CheckCircle2,
  FileVideo,
  Link2,
  Loader2,
  Upload,
  X,
} from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { parseSourceUrl, PLATFORM_LABEL } from "@/lib/source-url";
import {
  ACCEPT_ATTR,
  checkVideoFile,
  formatBytes,
  type FileCheck,
} from "@/lib/upload-validation";
import { formatDuration } from "@/lib/format";
import { CONTENT_MODE_OPTIONS, type ContentMode } from "@/lib/analysis/content";
import { localRequest, type LocalProject } from "@/lib/local";
import {
  ASPECT_OPTIONS,
  CLIP_LENGTHS,
  FRAMING_OPTIONS,
  type AspectRatio,
  type FramingMode,
  type Resolution,
} from "@/lib/types";

const searchSchema = z.object({
  url: z.string().optional(),
  tab: z.enum(["url", "upload"]).optional(),
});

export const Route = createFileRoute("/app/new")({
  validateSearch: searchSchema,
  head: () => ({ meta: [{ title: "Nuevo proyecto — Klipora" }] }),
  component: NewProject,
});

function NewProject() {
  const search = Route.useSearch();
  const [tab, setTab] = useState<"url" | "upload">(
    search.tab ?? (search.url ? "url" : "upload"),
  );
  const [url, setUrl] = useState(search.url ?? "");
  const [file, setFile] = useState<File | null>(null);
  const [check, setCheck] = useState<FileCheck | null>(null);
  const [checking, setChecking] = useState(false);

  const [workflow, setWorkflow] = useState<"semantic" | "speech" | "manual">(
    "semantic",
  );
  const [contentMode, setContentMode] = useState<ContentMode>("auto");
  const automatic = workflow !== "manual";
  const [length, setLength] = useState<number | "custom">(30);
  const [customLength, setCustomLength] = useState(40);
  const [aspect, setAspect] = useState<AspectRatio>("9:16");
  const [resolution, setResolution] = useState<Resolution>("1080p");
  const [framing, setFraming] = useState<FramingMode>("blur-fill");
  const [framingX, setFramingX] = useState(50);
  const [framingY, setFramingY] = useState(50);
  const [language, setLanguage] = useState<"auto" | "es" | "en">("auto");
  const [rights, setRights] = useState(false);
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function submit() {
    setSubmitting(true);
    setError("");
    const params = new URLSearchParams({
      title:
        tab === "url" && parsed?.ok
          ? parsed.canonicalUrl
          : file?.name || "Video",
      language,
      aspect,
      resolution,
      framing,
      framingX: String(framingX / 100),
      framingY: String(framingY / 100),
      target: String(targetLength),
      automatic: String(automatic),
      workflow,
      contentMode,
    });
    if (tab === "url" && parsed?.ok) params.set("url", parsed.canonicalUrl);
    try {
      const project = await localRequest<LocalProject>("?" + params, {
        method: "POST",
        headers: { "x-klipora-local": "1" },
        body: tab === "upload" ? file : undefined,
      });
      await navigate({
        to: "/app/projects/$projectId",
        params: { projectId: project.id },
      });
    } catch (failure) {
      setError(
        failure instanceof Error
          ? failure.message
          : "No se pudo guardar el proyecto.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  const parsed = url.trim() ? parseSourceUrl(url) : null;
  const sourceReady = tab === "url" ? parsed?.ok === true : check?.ok === true;
  const targetLength = length === "custom" ? customLength : length;
  const lengthValid = Number.isFinite(targetLength) && targetLength > 0;

  async function selectFile(f: File) {
    setFile(f);
    setCheck(null);
    setChecking(true);
    try {
      setCheck(await checkVideoFile(f));
    } finally {
      setChecking(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
      <div>
        <h1 className="text-3xl font-extrabold">Nuevo proyecto</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Importa un video y elige cómo quieres tus clips.
        </p>

        <Tabs
          value={tab}
          onValueChange={(v) => setTab(v as "url" | "upload")}
          className="mt-6"
        >
          <TabsList>
            <TabsTrigger value="url">
              <Link2 /> Enlace
            </TabsTrigger>
            <TabsTrigger value="upload">
              <Upload /> Subir archivo
            </TabsTrigger>
          </TabsList>

          <TabsContent value="url" className="mt-4">
            <Label htmlFor="source-url">Enlace de YouTube, Twitch o Kick</Label>
            <Input
              id="source-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://youtu.be/… · twitch.tv/videos/… · kick.com/canal/videos/…"
              className="mt-2 h-11"
              aria-invalid={parsed?.ok === false}
              aria-describedby="source-url-help"
            />
            <div id="source-url-help" className="mt-3">
              {parsed === null && (
                <p className="text-sm text-muted-foreground">
                  Admite videos, Shorts, VODs y clips. Las emisiones en directo
                  no se pueden procesar.
                </p>
              )}
              {parsed?.ok === false && (
                <div className="flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-sm">
                  <AlertCircle
                    className="mt-0.5 size-4 shrink-0 text-destructive"
                    aria-hidden
                  />
                  <div>
                    <p>{parsed.error}</p>
                    <button
                      type="button"
                      className="mt-1 underline underline-offset-4"
                      onClick={() => setTab("upload")}
                    >
                      Subir el archivo en su lugar
                    </button>
                  </div>
                </div>
              )}
              {parsed?.ok && (
                <div className="flex gap-4 rounded-xl border border-border bg-card p-3">
                  {parsed.thumbnailUrl ? (
                    <img
                      src={parsed.thumbnailUrl}
                      alt=""
                      className="aspect-video w-40 rounded-md object-cover"
                      onError={(e) => (e.currentTarget.style.display = "none")}
                    />
                  ) : (
                    <div className="grid aspect-video w-40 place-items-center rounded-md bg-muted text-xs text-muted-foreground">
                      {PLATFORM_LABEL[parsed.platform]}
                    </div>
                  )}
                  <div className="min-w-0 text-sm">
                    <p className="flex items-center gap-1.5 font-medium">
                      <CheckCircle2
                        className="size-4 text-primary"
                        aria-hidden
                      />
                      {PLATFORM_LABEL[parsed.platform]} ·{" "}
                      {KIND_LABEL[parsed.kind]}
                    </p>
                    <p className="mt-1 truncate font-mono text-xs text-muted-foreground">
                      {parsed.canonicalUrl}
                    </p>
                    <p className="mt-2 text-xs text-muted-foreground">
                      Título y duración se obtienen al crear el proyecto. Si la
                      plataforma bloquea la descarga o el video es privado, te
                      pediremos el archivo original.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="upload" className="mt-4">
            <Dropzone
              file={file}
              check={check}
              checking={checking}
              onFile={selectFile}
              onClear={() => {
                setFile(null);
                setCheck(null);
              }}
            />
          </TabsContent>
        </Tabs>

        <section className="mt-10 grid gap-8">
          <Field label="Modo de trabajo">
            <div className="flex flex-wrap gap-2">
              <Chip
                active={workflow === "semantic"}
                onClick={() => setWorkflow("semantic")}
              >
                Detectar momentos con IA
              </Chip>
              <Chip
                active={workflow === "speech"}
                onClick={() => setWorkflow("speech")}
              >
                Fragmentos hablados
              </Chip>
              <Chip
                active={workflow === "manual"}
                onClick={() => setWorkflow("manual")}
              >
                Cortes manuales
              </Chip>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {workflow === "semantic"
                ? "Requiere un modelo de lenguaje local en ejecución."
                : workflow === "speech"
                  ? "Transcripción y subtítulos locales con faster-whisper."
                  : "Elige los tiempos de cada corte después de importar el video."}
            </p>
          </Field>
          {workflow === "semantic" && (
            <Field label="Tipo de contenido">
              <div className="flex flex-wrap gap-2">
                {CONTENT_MODE_OPTIONS.map((mode) => (
                  <Chip
                    key={mode.value}
                    active={contentMode === mode.value}
                    onClick={() => setContentMode(mode.value)}
                  >
                    {mode.label}
                  </Chip>
                ))}
              </div>
            </Field>
          )}

          <Field
            label="Duración de cada clip"
            hint={
              workflow === "semantic"
                ? "La duración es orientativa. La IA busca momentos con suficiente contexto."
                : "Se buscan pausas y finales de frase alrededor de la duración elegida."
            }
          >
            <div className="flex flex-wrap gap-2">
              {CLIP_LENGTHS.map((l) => (
                <Chip
                  key={l}
                  active={length === l}
                  onClick={() => setLength(l)}
                >
                  {l} s
                </Chip>
              ))}
              <Chip
                active={length === "custom"}
                onClick={() => setLength("custom")}
              >
                Personalizada
              </Chip>
              {length === "custom" && (
                <span className="flex items-center gap-2">
                  <Input
                    type="number"
                    min={0.1}
                    step="any"
                    value={customLength}
                    onChange={(e) => setCustomLength(Number(e.target.value))}
                    className="w-20"
                    aria-label="Duración personalizada en segundos"
                    aria-invalid={!lengthValid}
                  />
                  <span className="text-sm text-muted-foreground">
                    s · mayor que 0
                  </span>
                </span>
              )}
            </div>
          </Field>

          <Field label="Formato">
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {ASPECT_OPTIONS.map((a) => (
                <Chip
                  key={a.value}
                  active={aspect === a.value}
                  onClick={() => setAspect(a.value)}
                  className="flex-col items-start py-2"
                >
                  <span className="font-mono font-semibold">{a.label}</span>
                  <span className="text-xs text-muted-foreground">
                    {a.hint}
                  </span>
                </Chip>
              ))}
            </div>
          </Field>

          <Field label="Encuadre">
            <div className="grid gap-2 sm:grid-cols-2">
              {FRAMING_OPTIONS.map((f) => (
                <Chip
                  key={f.value}
                  active={framing === f.value}
                  onClick={() => setFraming(f.value)}
                  className="flex-col items-start py-2"
                >
                  <span className="font-medium">{f.label}</span>
                  <span className="text-xs text-muted-foreground">
                    {f.hint}
                  </span>
                </Chip>
              ))}
            </div>
            {framing === "manual" && (
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                <div>
                  <Label htmlFor="framing-x">Posición horizontal</Label>
                  <Input
                    id="framing-x"
                    type="range"
                    min="0"
                    max="100"
                    value={framingX}
                    onChange={(e) => setFramingX(Number(e.target.value))}
                  />
                </div>
                <div>
                  <Label htmlFor="framing-y">Posición vertical</Label>
                  <Input
                    id="framing-y"
                    type="range"
                    min="0"
                    max="100"
                    value={framingY}
                    onChange={(e) => setFramingY(Number(e.target.value))}
                  />
                </div>
              </div>
            )}
          </Field>

          <div className="grid gap-8 sm:grid-cols-2">
            <Field label="Resolución">
              <div className="flex gap-2">
                {(["720p", "1080p"] as const).map((r) => (
                  <Chip
                    key={r}
                    active={resolution === r}
                    onClick={() => setResolution(r)}
                  >
                    {r}
                  </Chip>
                ))}
              </div>
            </Field>
            <Field label="Idioma del audio">
              <div className="flex gap-2">
                {(
                  [
                    ["auto", "Detectar"],
                    ["es", "Español"],
                    ["en", "Inglés"],
                  ] as const
                ).map(([v, l]) => (
                  <Chip
                    key={v}
                    active={language === v}
                    onClick={() => setLanguage(v)}
                  >
                    {l}
                  </Chip>
                ))}
              </div>
            </Field>
          </div>
        </section>
      </div>

      <aside className="lg:sticky lg:top-20 lg:self-start">
        <div className="rounded-xl border border-border bg-card p-5">
          <h2 className="text-lg font-bold">Resumen</h2>
          <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
            <dt className="text-muted-foreground">Fuente</dt>
            <dd className="truncate text-right">
              {tab === "url"
                ? parsed?.ok
                  ? PLATFORM_LABEL[parsed.platform]
                  : "—"
                : file
                  ? file.name
                  : "—"}
            </dd>
            <dt className="text-muted-foreground">Modo</dt>
            <dd className="text-right">
              {automatic
                ? `${workflow === "semantic" ? "Detección con IA" : "Fragmentos hablados"} · ~${targetLength} s`
                : "Cortes manuales"}
            </dd>
            <dt className="text-muted-foreground">Salida</dt>
            <dd className="text-right">
              {aspect} · {resolution} · H.264/AAC
            </dd>
          </dl>
          <div className="mt-5 flex items-start gap-2">
            <Checkbox
              id="rights"
              checked={rights}
              onCheckedChange={(v) => setRights(v === true)}
            />
            <Label
              htmlFor="rights"
              className="text-sm leading-snug font-normal text-muted-foreground"
            >
              Tengo derechos o permiso para usar este contenido y acepto las
              condiciones de la plataforma de origen.
            </Label>
          </div>
          <Button
            className="mt-5 w-full"
            size="lg"
            disabled={submitting || !sourceReady || !rights || !lengthValid}
            onClick={() => void submit()}
          >
            {submitting
              ? "Guardando proyecto…"
              : automatic
                ? "Generar clips"
                : "Importar video"}
          </Button>
          {error && (
            <p role="alert" className="mt-2 text-sm text-destructive">
              {error}
            </p>
          )}
          {!sourceReady && (
            <p className="mt-2 text-center text-xs text-muted-foreground">
              Añade un enlace válido o un archivo para continuar.
            </p>
          )}
        </div>
      </aside>
    </div>
  );
}

const KIND_LABEL = {
  video: "Video",
  short: "Short",
  live: "Directo grabado",
  vod: "VOD",
  clip: "Clip",
} as const;

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <fieldset>
      <legend className="mb-2 text-sm font-semibold">{label}</legend>
      {children}
      {hint && <p className="mt-2 text-xs text-muted-foreground">{hint}</p>}
    </fieldset>
  );
}

function Chip({
  active,
  className,
  ...props
}: React.ComponentProps<"button"> & { active: boolean }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      className={cn(
        "flex items-center rounded-lg border border-border bg-background px-3 py-1.5 text-left text-sm transition-colors hover:border-primary/50 aria-pressed:border-primary aria-pressed:bg-primary/10",
        className,
      )}
      {...props}
    />
  );
}

function Dropzone({
  file,
  check,
  checking,
  onFile,
  onClear,
}: {
  file: File | null;
  check: FileCheck | null;
  checking: boolean;
  onFile: (f: File) => void;
  onClear: () => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  if (file) {
    return (
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-start gap-3">
          <FileVideo
            className="mt-0.5 size-5 shrink-0 text-primary"
            aria-hidden
          />
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium">{file.name}</p>
            <p className="text-sm text-muted-foreground">
              {formatBytes(file.size)}
              {check?.durationSec
                ? ` · ${formatDuration(check.durationSec)}`
                : ""}
              {check?.width ? ` · ${check.width}×${check.height}` : ""}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={onClear}
            aria-label="Quitar archivo"
          >
            <X />
          </Button>
        </div>
        <div className="mt-3 text-sm">
          {checking && (
            <p className="flex items-center gap-2 text-muted-foreground">
              <Loader2
                className="size-4 animate-spin motion-reduce:animate-none"
                aria-hidden
              />{" "}
              Comprobando el archivo…
            </p>
          )}
          {check && !check.ok && (
            <p className="flex items-center gap-2 text-destructive">
              <AlertCircle className="size-4" aria-hidden /> {check.error}
            </p>
          )}
          {check?.ok && check.needsServerProbe && (
            <p className="flex items-center gap-2 text-warm">
              <AlertCircle className="size-4" aria-hidden /> El navegador no
              puede previsualizar .{check.extension}; FFmpeg lo validará en el
              equipo.
            </p>
          )}
          {check?.ok && !check.needsServerProbe && (
            <p className="flex items-center gap-2 text-primary">
              <CheckCircle2 className="size-4" aria-hidden /> Archivo válido
            </p>
          )}
        </div>
        {check?.ok && !check.needsServerProbe && <FilePreview file={file} />}
      </div>
    );
  }

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        const f = e.dataTransfer.files[0];
        if (f) onFile(f);
      }}
      className={cn(
        "grid place-items-center rounded-xl border-2 border-dashed border-border px-6 py-14 text-center transition-colors",
        over && "border-primary bg-primary/5",
      )}
    >
      <Upload className="size-8 text-muted-foreground" aria-hidden />
      <p className="mt-3 font-medium">Arrastra tu video aquí</p>
      <p className="text-sm text-muted-foreground">
        MP4, MOV, MKV, AVI, WEBM, M4V o FLV · sin topes de tamaño ni duración en
        la aplicación
      </p>
      <Button
        variant="outline"
        className="mt-4"
        onClick={() => inputRef.current?.click()}
      >
        Seleccionar archivo
      </Button>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPT_ATTR}
        className="sr-only"
        tabIndex={-1}
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onFile(f);
          e.target.value = "";
        }}
      />
    </div>
  );
}

function FilePreview({ file }: { file: File }) {
  const video = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const element = video.current!;
    const url = URL.createObjectURL(file);
    element.src = url;
    return () => {
      element.removeAttribute("src");
      URL.revokeObjectURL(url);
    };
  }, [file]);

  return (
    <video
      ref={video}
      controls
      muted
      className="mt-3 max-h-72 w-full rounded-lg bg-black"
    />
  );
}
