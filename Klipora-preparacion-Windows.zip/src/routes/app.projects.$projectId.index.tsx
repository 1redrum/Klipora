import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Copy,
  Download,
  ExternalLink,
  Heart,
  Pencil,
  Play,
  RefreshCw,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { LocalProjectPage } from "@/components/local-project";
import { localId } from "@/lib/local";
import { SampleDataNotice } from "@/components/app-shell";
import { AnalysisPanel, EngineBadge } from "@/components/analysis";
import { MOMENT_KIND_LABEL } from "@/lib/analysis/content";
import { CaptionOverlay } from "@/components/caption-overlay";
import { overallProgress, Pipeline } from "@/components/pipeline";
import { ASPECT_CLASS, Poster } from "@/components/poster";
import { ScoreBadge, ScoreBreakdownList } from "@/components/score";
import { cn } from "@/lib/utils";
import { CAPTION_PRESETS } from "@/lib/caption-styles";
import { getProject } from "@/lib/fixtures";
import { formatDuration, formatRelative } from "@/lib/format";
import { PLATFORM_LABEL } from "@/lib/source-url";
import { useClock } from "@/lib/use-clock";
import type { Clip, Project } from "@/lib/types";

export const Route = createFileRoute("/app/projects/$projectId/")({
  loader: ({ params }) => {
    if (localId.test(params.projectId)) return null;
    const project = getProject(params.projectId);
    if (!project) throw notFound();
    return project;
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `${loaderData?.title ?? "Proyecto"} — Klipora` }],
  }),
  component: ProjectPage,
});

function ProjectPage() {
  const initial = Route.useLoaderData();
  const { projectId } = Route.useParams();
  return initial ? (
    <SampleProject key={projectId} initial={initial} />
  ) : (
    <LocalProjectPage key={projectId} id={projectId} />
  );
}

function SampleProject({ initial }: { initial: Project }) {
  const [project, setProject] = useState<Project>(initial);

  return (
    <div>
      <SampleDataNotice />
      <Link
        to="/app"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" aria-hidden /> Proyectos
      </Link>
      <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-3xl font-extrabold">{project.title}</h1>
          {project.classification && (
            <EngineBadge
              engine={project.classification.engine}
              className="mt-2"
            />
          )}
          <p className="mt-1 flex flex-wrap items-center gap-x-2 text-sm text-muted-foreground">
            <span>{PLATFORM_LABEL[project.source]}</span>
            {project.channel && <span>· {project.channel}</span>}
            <span>· {formatDuration(project.durationSec)}</span>
            <span>
              · {project.language === "es" ? "Español" : "Inglés"} (detectado)
            </span>
            <span>· {formatRelative(project.createdAt)}</span>
            {project.sourceUrl && (
              <a
                href={project.sourceUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 underline-offset-4 hover:underline"
              >
                origen <ExternalLink className="size-3" aria-hidden />
              </a>
            )}
          </p>
        </div>
      </div>

      {project.status === "completed" ? (
        <Results project={project} setProject={setProject} />
      ) : (
        <Processing project={project} setProject={setProject} />
      )}
    </div>
  );
}

function Processing({
  project,
  setProject,
}: {
  project: Project;
  setProject: (p: Project) => void;
}) {
  const pct = overallProgress(project.stages);
  const failed = project.status === "failed";
  return (
    <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">
            {failed ? "El procesamiento se detuvo" : "Procesando"}
          </h2>
          <span className="font-mono text-sm text-muted-foreground">
            {pct}% total
          </span>
        </div>
        <Pipeline stages={project.stages} />
      </div>
      <div className="grid gap-4 self-start">
        {failed && project.error ? (
          <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-5">
            <p className="flex items-center gap-2 font-semibold">
              <AlertTriangle className="size-4 text-destructive" aria-hidden />{" "}
              {project.error.message}
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              {project.error.cause}
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                onClick={() => {
                  setProject({
                    ...project,
                    status: "processing",
                    error: undefined,
                    stages: project.stages.map((s) =>
                      s.status === "error"
                        ? {
                            ...s,
                            status: "running",
                            progress: 0,
                            detail: "Reintentando con conversión forzada",
                          }
                        : s,
                    ),
                  });
                  toast.success(
                    "Reintento en cola. Los pasos completados se conservan.",
                  );
                }}
              >
                <RefreshCw /> Reintentar
              </Button>
              <Button variant="outline" asChild>
                <Link to="/app/new" search={{ tab: "upload" }}>
                  Subir otro archivo
                </Link>
              </Button>
            </div>
          </div>
        ) : (
          <div className="rounded-xl border border-border bg-card p-5 text-sm text-muted-foreground">
            <p>
              El video se procesa en segundo plano. Puedes cerrar esta página o
              empezar otro proyecto: el progreso de cada paso lo informa el
              worker en tiempo real.
            </p>
          </div>
        )}
        <AnalysisPanel project={project} />
        <div className="rounded-xl border border-border bg-card p-5 text-sm">
          <p className="font-semibold">Ajustes del proyecto</p>
          <dl className="mt-3 grid grid-cols-2 gap-y-1.5 text-muted-foreground">
            <dt>Duración objetivo</dt>
            <dd className="text-right text-foreground">
              {project.clipLengthTarget} s
            </dd>
            <dt>Formato</dt>
            <dd className="text-right text-foreground">{project.aspect}</dd>
            <dt>Resolución</dt>
            <dd className="text-right text-foreground">{project.resolution}</dd>
            <dt>Conservación</dt>
            <dd className="text-right text-foreground">
              Hasta que lo elimines
            </dd>
          </dl>
        </div>
      </div>
    </div>
  );
}

function Results({
  project,
  setProject,
}: {
  project: Project;
  setProject: React.Dispatch<React.SetStateAction<Project>>;
}) {
  const [onlyFav, setOnlyFav] = useState(false);
  const clips = useMemo(
    () =>
      [...project.clips]
        .sort((a, b) => b.score - a.score)
        .filter((c) => !onlyFav || c.favorite),
    [project.clips, onlyFav],
  );
  const update = (id: string, patch: Partial<Clip> | null) =>
    setProject((p) => ({
      ...p,
      clips:
        patch === null
          ? p.clips.filter((c) => c.id !== id)
          : p.clips.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  const restore = (clip: Clip) =>
    setProject((p) =>
      p.clips.some((c) => c.id === clip.id)
        ? p
        : { ...p, clips: [...p.clips, clip] },
    );

  return (
    <div className="mt-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold">
            {project.clips.length} clips · ordenados por potencial
          </h2>
          <p className="text-sm text-muted-foreground">
            La puntuación estima el potencial de interés de cada momento; no
            garantiza que el clip sea viral.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={onlyFav ? "secondary" : "outline"}
            aria-pressed={onlyFav}
            onClick={() => setOnlyFav((v) => !v)}
          >
            <Heart className={cn(onlyFav && "fill-current")} /> Favoritos
          </Button>
          <PendingExport label="Descargar todo (ZIP)" />
        </div>
      </div>
      <AnalysisPanel project={project} className="mt-6" />
      {clips.length === 0 ? (
        <div className="mt-8 rounded-xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          {onlyFav
            ? "Aún no has marcado favoritos."
            : "Has eliminado todos los clips de este proyecto."}
        </div>
      ) : (
        <ul className="mt-6 grid gap-4">
          {clips.map((c) => (
            <ClipCard
              key={c.id}
              clip={c}
              onUpdate={(patch) => update(c.id, patch)}
              onRestore={restore}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function PendingExport({
  label,
  size,
}: {
  label: string;
  size?: "sm" | "default";
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <span tabIndex={0}>
          <Button variant="outline" size={size} disabled>
            <Download /> {label}
          </Button>
        </span>
      </TooltipTrigger>
      <TooltipContent>
        Las descargas se activan cuando el render con FFmpeg esté conectado.
      </TooltipContent>
    </Tooltip>
  );
}

function ClipCard({
  clip,
  onUpdate,
  onRestore,
}: {
  clip: Clip;
  onUpdate: (patch: Partial<Clip> | null) => void;
  onRestore: (clip: Clip) => void;
}) {
  const [playing, setPlaying] = useState(false);
  const len = clip.end - clip.start;
  const t = useClock(len, playing);

  const copy = (text: string, what: string) => {
    void navigator.clipboard.writeText(text).then(
      () => toast.success(`${what} copiado`),
      () => toast.error("No se pudo copiar"),
    );
  };

  return (
    <li className="grid gap-5 rounded-xl border border-border bg-card p-4 md:grid-cols-[200px_1fr_220px]">
      <div className="relative">
        <Poster
          hue={clip.hue}
          className={cn("w-full", ASPECT_CLASS[clip.aspect])}
        >
          <span className="absolute top-2 left-2 rounded bg-black/70 px-1.5 font-mono text-xs">
            #{clip.rank}
          </span>
          <span className="absolute right-2 bottom-2 rounded bg-black/70 px-1.5 font-mono text-xs">
            {formatDuration(len)}
          </span>
          {playing && (
            <CaptionOverlay
              segments={clip.captions}
              time={t}
              style={CAPTION_PRESETS.hormozi.style}
              scale={0.45}
            />
          )}
          <button
            type="button"
            onClick={() => setPlaying((p) => !p)}
            className="absolute inset-0 grid place-items-center opacity-80 transition-opacity hover:opacity-100"
            aria-label={
              playing
                ? "Pausar vista previa"
                : "Reproducir vista previa de subtítulos"
            }
          >
            {!playing && (
              <span className="grid size-12 place-items-center rounded-full bg-black/60">
                <Play className="size-5 fill-current" aria-hidden />
              </span>
            )}
          </button>
        </Poster>
        {playing && (
          <div className="mt-2 h-1 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-primary"
              style={{ width: `${(t / len) * 100}%` }}
            />
          </div>
        )}
      </div>

      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <ScoreBadge score={clip.score} />
          <Badge variant="outline">{MOMENT_KIND_LABEL[clip.kind]}</Badge>
          {clip.tags.map((tag) => (
            <Badge key={tag} variant="secondary" className="capitalize">
              {tag}
            </Badge>
          ))}
        </div>
        <h3 className="mt-2 text-lg font-bold leading-snug">{clip.title}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{clip.description}</p>
        <p className="mt-3 text-sm">
          <span className="text-muted-foreground">Gancho: </span>«{clip.hook}»
        </p>
        <div className="mt-3 flex flex-wrap items-center gap-1.5">
          {clip.hashtags.map((h) => (
            <span
              key={h}
              className="rounded bg-secondary px-1.5 py-0.5 font-mono text-xs text-cool"
            >
              {h}
            </span>
          ))}
          <Button
            variant="ghost"
            size="xs"
            onClick={() =>
              copy(
                `${clip.title}\n\n${clip.description}\n\n${clip.hashtags.join(" ")}`,
                "Texto de publicación",
              )
            }
          >
            <Copy /> Copiar texto
          </Button>
        </div>
        <p className="mt-3 rounded-lg bg-muted/60 p-2.5 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">
            Por qué este momento:{" "}
          </span>
          {clip.reason}
          {clip.evidence.length > 0 && (
            <span
              className="mt-1.5 flex flex-wrap gap-1"
              aria-label="Señales detectadas"
            >
              {clip.evidence.map((e) => (
                <span
                  key={e}
                  className="rounded bg-background/60 px-1.5 py-0.5"
                >
                  {e}
                </span>
              ))}
            </span>
          )}
        </p>
      </div>

      <div className="flex flex-col gap-3 text-sm">
        <dl className="grid grid-cols-2 gap-y-1 text-muted-foreground">
          <dt>Plataforma</dt>
          <dd className="text-right text-foreground">{clip.platform}</dd>
          <dt>Formato</dt>
          <dd className="text-right text-foreground">
            {clip.aspect} · {clip.resolution}
          </dd>
          <dt>En el original</dt>
          <dd className="text-right font-mono text-foreground">
            {formatDuration(clip.start)}
          </dd>
        </dl>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="link" size="xs" className="justify-start px-0">
              Ver desglose de la puntuación
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-72">
            <ScoreBreakdownList breakdown={clip.breakdown} />
            <p className="mt-3 text-xs text-muted-foreground">
              {clip.postingTip}
            </p>
          </PopoverContent>
        </Popover>
        <div className="mt-auto grid grid-cols-2 gap-2">
          <Button asChild size="sm" className="col-span-2">
            <Link
              to="/app/projects/$projectId/clips/$clipId"
              params={{ projectId: clip.projectId, clipId: clip.id }}
            >
              <Pencil /> Editar
            </Link>
          </Button>
          <Button
            variant="outline"
            size="sm"
            aria-pressed={clip.favorite}
            onClick={() => onUpdate({ favorite: !clip.favorite })}
          >
            <Heart className={cn(clip.favorite && "fill-hot text-hot")} />{" "}
            {clip.favorite ? "Favorito" : "Marcar"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              onUpdate(null);
              toast("Clip eliminado", {
                action: { label: "Deshacer", onClick: () => onRestore(clip) },
              });
            }}
          >
            <Trash2 /> Eliminar
          </Button>
          <Tooltip>
            <TooltipTrigger asChild>
              <span tabIndex={0}>
                <Button variant="outline" size="sm" disabled className="w-full">
                  <RefreshCw /> Regenerar
                </Button>
              </span>
            </TooltipTrigger>
            <TooltipContent>
              Vuelve a pedir el clip al worker; se activa con el motor de
              procesamiento.
            </TooltipContent>
          </Tooltip>
          <PendingExport label="MP4" size="sm" />
        </div>
      </div>
    </li>
  );
}
