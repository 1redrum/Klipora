import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowRight,
  AudioLines,
  Captions,
  Crop,
  Link2,
  Focus,
  HardDrive,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Logo } from "@/components/app-shell";
import { CaptionOverlay } from "@/components/caption-overlay";
import { Poster } from "@/components/poster";
import { CAPTION_PRESETS } from "@/lib/caption-styles";
import { projects } from "@/lib/fixtures";
import { useClock } from "@/lib/use-clock";

export const Route = createFileRoute("/")({
  component: Home,
});

const STEPS = [
  {
    icon: Link2,
    title: "Importa",
    text: "Sube el archivo original o importa un enlace compatible de YouTube, Twitch o Kick.",
  },
  {
    icon: AudioLines,
    title: "Transcribe",
    text: "faster-whisper transcribe el audio en el equipo por ventanas y genera subtítulos.",
  },
  {
    icon: Crop,
    title: "Recorta",
    text: "Genera fragmentos hablados por pausas y finales de frase o elige los tiempos de corte.",
  },
  {
    icon: Captions,
    title: "Exporta",
    text: "Descarga clips H.264/AAC en 720p o 1080p.",
  },
];

const FEATURES = [
  {
    icon: HardDrive,
    title: "Proyectos guardados en el equipo",
    text: "El procesamiento continúa con el navegador cerrado mientras el servidor local siga abierto.",
  },
  {
    icon: Captions,
    title: "Subtítulos incrustados",
    text: "Los fragmentos hablados incluyen el texto transcrito y sincronizado.",
  },
  {
    icon: Focus,
    title: "Ajusta el encuadre",
    text: "Usa recorte centrado o conserva el encuadre original con un fondo desenfocado.",
  },
  {
    icon: Crop,
    title: "Todos los formatos",
    text: "9:16, 16:9, 1:1 y 4:5. Sin estirar la imagen, con los FPS originales siempre que sea posible.",
  },
];

function Home() {
  const [url, setUrl] = useState("");
  const navigate = useNavigate();
  const demo = projects[0]!.clips[0]!;
  const t = useClock(demo.end - demo.start);

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex h-16 max-w-content items-center px-4 sm:px-6">
        <Logo />
        <div className="ml-auto flex items-center gap-2">
          <Button asChild variant="ghost" size="sm">
            <Link to="/app">Mis proyectos</Link>
          </Button>
          <Button asChild size="sm">
            <Link to="/app/new">Empezar</Link>
          </Button>
        </div>
      </header>

      <section className="mx-auto grid max-w-content items-center gap-12 px-4 pt-10 pb-20 sm:px-6 lg:grid-cols-[1.2fr_1fr]">
        <div>
          <h1 className="font-display text-5xl leading-[0.95] font-extrabold sm:text-7xl">
            Convierte tus videos en clips
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Corta, transcribe y exporta en tu ordenador. Guarda los originales y
            los clips en el disco que elijas.
          </p>
          <form
            className="mt-8 flex max-w-xl flex-col gap-2 sm:flex-row"
            onSubmit={(e) => {
              e.preventDefault();
              void navigate({
                to: "/app/new",
                search: { url: url || undefined },
              });
            }}
          >
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://www.twitch.tv/videos/…"
              aria-label="Enlace del video"
              className="h-12 text-base"
            />
            <Button type="submit" size="lg" className="h-12">
              Importar <ArrowRight />
            </Button>
          </form>
          <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
            <Upload className="size-4" aria-hidden /> ¿Tienes el archivo?{" "}
            <Link
              to="/app/new"
              search={{ tab: "upload" }}
              className="text-foreground underline underline-offset-4"
            >
              Súbelo desde tu ordenador
            </Link>
          </p>
        </div>

        <div className="relative mx-auto w-full max-w-[300px]">
          <Poster
            hue={demo.hue}
            className="aspect-[9/16] w-full shadow-2xl ring-1 ring-white/10"
          >
            <div className="absolute top-3 left-3 rounded-md bg-black/60 px-2 py-1 font-mono text-xs">
              Vista de ejemplo
            </div>
            <CaptionOverlay
              segments={demo.captions}
              time={t}
              style={CAPTION_PRESETS.mrbeast.style}
              scale={0.62}
            />
          </Poster>
          <div className="absolute -bottom-4 -left-8 hidden rounded-lg border border-border bg-card px-3 py-2 text-xs shadow-xl sm:block">
            <p className="font-medium">{demo.title}</p>
            <p className="text-muted-foreground">
              {demo.tags.map((x) => `#${x}`).join("  ")}
            </p>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-card/40">
        <div className="mx-auto grid max-w-content gap-6 px-4 py-14 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
          {STEPS.map((s) => (
            <div key={s.title}>
              <div className="flex items-center gap-3">
                <s.icon className="size-5 text-primary" aria-hidden />
              </div>
              <h2 className="mt-3 text-xl font-bold">{s.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-content px-4 py-20 sm:px-6">
        <h2 className="max-w-2xl font-display text-3xl font-extrabold sm:text-4xl">
          Procesamiento en tu ordenador
        </h2>
        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="rounded-xl border border-border bg-card p-6"
            >
              <f.icon className="size-6 text-primary" aria-hidden />
              <h3 className="mt-4 text-lg font-bold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
        <p className="mt-10 max-w-reading text-sm text-muted-foreground">
          Usa videos propios o que tengas permiso para procesar.
        </p>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-content items-center justify-between px-4 py-6 text-sm text-muted-foreground sm:px-6">
          <Logo />
          <span>© 2026 Klipora</span>
        </div>
      </footer>
    </div>
  );
}
