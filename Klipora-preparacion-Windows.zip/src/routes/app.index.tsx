import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Film,
  Loader2,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Poster } from "@/components/poster";
import { EngineBadge } from "@/components/analysis";
import { overallProgress } from "@/components/pipeline";
import { localRequest, type LocalProject } from "@/lib/local";
import { projects as seed } from "@/lib/fixtures";
import { formatDuration, formatRelative } from "@/lib/format";
import { PLATFORM_LABEL } from "@/lib/source-url";
import { PIPELINE_STAGES, type Project, type ProjectStatus } from "@/lib/types";

export const Route = createFileRoute("/app/")({
  head: () => ({ meta: [{ title: "Proyectos — Klipora" }] }),
  component: ProjectsPage,
});

const FILTERS: { value: "all" | ProjectStatus; label: string }[] = [
  { value: "all", label: "Todos" },
  { value: "processing", label: "En proceso" },
  { value: "completed", label: "Completados" },
  { value: "failed", label: "Con error" },
];

function ProjectsPage() {
  const [localProjects, setLocalProjects] = useState<LocalProject[]>([]);
  const [localError, setLocalError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    async function refresh() {
      try {
        const projects = await localRequest<LocalProject[]>("", {
          signal: controller.signal,
        });
        if (!controller.signal.aborted) {
          setLocalProjects(
            projects.sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
          );
          setLocalError("");
        }
      } catch (error) {
        if (!controller.signal.aborted) setLocalError((error as Error).message);
      } finally {
        if (!controller.signal.aborted) timer = setTimeout(refresh, 3000);
      }
    }
    void refresh();
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, []);
  const [items, setItems] = useState<Project[]>(seed);
  const [filter, setFilter] =
    useState<(typeof FILTERS)[number]["value"]>("all");
  const [query, setQuery] = useState("");
  const [toDelete, setToDelete] = useState<Project | null>(null);

  const visible = useMemo(
    () =>
      items.filter(
        (p) =>
          (filter === "all" || p.status === filter) &&
          p.title.toLowerCase().includes(query.trim().toLowerCase()),
      ),
    [items, filter, query],
  );

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold">Proyectos</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Videos procesados y su estado. Sin caducidad automática: tú decides
            cuándo eliminar tus proyectos y archivos.
          </p>
        </div>
        <Button asChild>
          <Link to="/app/new">
            <Plus /> Nuevo proyecto
          </Link>
        </Button>
      </div>

      <section className="mt-6 space-y-3">
        <h2 className="text-lg font-semibold">Proyectos locales</h2>
        {localError && (
          <p role="status" className="text-sm text-muted-foreground">
            {localError}
          </p>
        )}
        {!localError && !localProjects.length && (
          <p className="text-sm text-muted-foreground">
            Aún no hay proyectos locales.
          </p>
        )}
        {localProjects.map((project) => (
          <Link
            key={project.id}
            to="/app/projects/$projectId"
            params={{ projectId: project.id }}
            className="flex flex-wrap justify-between gap-2 rounded-lg border border-border bg-card p-4 hover:border-primary"
          >
            <span className="break-all font-medium">{project.title}</span>
            <span className="text-sm text-muted-foreground">
              {project.status === "failed" ? "Con error" : project.phase} ·{" "}
              {project.clips.length} clips
            </span>
          </Link>
        ))}
      </section>

      <h2 className="mt-8 text-lg font-semibold">Proyectos de ejemplo</h2>
      <div className="mt-6 flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search
            className="absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar proyecto"
            aria-label="Buscar proyecto"
            className="w-64 pl-8"
          />
        </div>
        <div
          className="flex gap-1 rounded-lg bg-secondary p-1"
          role="group"
          aria-label="Filtrar por estado"
        >
          {FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setFilter(f.value)}
              aria-pressed={filter === f.value}
              className="rounded-md px-3 py-1 text-sm text-muted-foreground transition-colors aria-pressed:bg-background aria-pressed:text-foreground"
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <div className="mt-10 rounded-xl border border-dashed border-border p-12 text-center">
          <Film className="mx-auto size-8 text-muted-foreground" aria-hidden />
          <p className="mt-3 font-medium">No hay proyectos que coincidan</p>
          <p className="text-sm text-muted-foreground">
            Cambia el filtro o crea un proyecto nuevo.
          </p>
        </div>
      ) : (
        <ul className="mt-6 grid gap-3">
          {visible.map((p) => (
            <li
              key={p.id}
              className="group relative grid grid-cols-[96px_1fr_auto] items-center gap-4 rounded-xl border border-border bg-card p-3 transition-colors hover:border-primary/40 sm:grid-cols-[160px_1fr_auto]"
            >
              <Poster hue={p.hue} className="aspect-video">
                <span className="absolute right-1.5 bottom-1.5 rounded bg-black/70 px-1.5 font-mono text-[11px]">
                  {formatDuration(p.durationSec)}
                </span>
              </Poster>
              <div className="min-w-0">
                <Link
                  to="/app/projects/$projectId"
                  params={{ projectId: p.id }}
                  className="line-clamp-1 font-semibold after:absolute after:inset-0"
                >
                  {p.title}
                </Link>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {PLATFORM_LABEL[p.source]}
                  {p.channel ? ` · ${p.channel}` : ""} ·{" "}
                  {formatRelative(p.createdAt)}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  {p.classification && (
                    <EngineBadge engine={p.classification.engine} />
                  )}
                  <StatusLine project={p} />
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="relative z-10 text-muted-foreground hover:text-destructive"
                aria-label={`Eliminar ${p.title}`}
                onClick={() => setToDelete(p)}
              >
                <Trash2 />
              </Button>
            </li>
          ))}
        </ul>
      )}

      <Dialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>¿Eliminar el proyecto?</DialogTitle>
            <DialogDescription>
              Se borrarán «{toDelete?.title}», sus {toDelete?.clips.length ?? 0}{" "}
              clips y los archivos almacenados. No se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancelar</Button>
            </DialogClose>
            <Button
              variant="destructive"
              onClick={() => {
                setItems((xs) => xs.filter((x) => x.id !== toDelete?.id));
                toast.success("Proyecto eliminado");
                setToDelete(null);
              }}
            >
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatusLine({ project: p }: { project: Project }) {
  if (p.status === "completed") {
    return (
      <span className="flex flex-wrap items-center gap-2 text-sm">
        <Badge className="bg-primary/15 text-primary">Completado</Badge>
        <span className="text-muted-foreground">
          {p.clips.length} clips · mejor{" "}
          {Math.max(...p.clips.map((c) => c.score))}/100
        </span>
      </span>
    );
  }
  if (p.status === "failed") {
    return (
      <span className="flex items-center gap-2 text-sm text-destructive">
        <AlertTriangle className="size-4" aria-hidden /> {p.error?.message}
      </span>
    );
  }
  const running = p.stages.find((s) => s.status === "running");
  const label = PIPELINE_STAGES.find((s) => s.key === running?.key)?.label;
  const pct = overallProgress(p.stages);
  return (
    <span className="flex items-center gap-3 text-sm">
      <Loader2
        className="size-4 animate-spin text-primary motion-reduce:animate-none"
        aria-hidden
      />
      <span>{label}</span>
      <span className="h-1.5 w-32 overflow-hidden rounded-full bg-muted">
        <span
          className="block h-full bg-primary"
          style={{ width: `${pct}%` }}
        />
      </span>
      <span className="font-mono text-xs text-muted-foreground">{pct}%</span>
    </span>
  );
}
