import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Download,
  FileVideo,
  Pause,
  Play,
  RotateCcw,
  Save,
  Volume2,
  VolumeX,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { RealClipEditor } from "@/components/real-clip-editor";
import { localId } from "@/lib/local";
import { SampleDataNotice } from "@/components/app-shell";
import { CaptionOverlay } from "@/components/caption-overlay";
import { ASPECT_CLASS, Poster } from "@/components/poster";
import { ScoreBadge } from "@/components/score";
import { cn } from "@/lib/utils";
import { MOMENT_KIND_LABEL } from "@/lib/analysis/content";
import {
  CAPTION_FONTS,
  CAPTION_PRESETS,
  type CaptionAnimation,
  type CaptionPresetKey,
  type CaptionStyle,
} from "@/lib/caption-styles";
import { getClip, getProject } from "@/lib/fixtures";
import { formatTimecode } from "@/lib/format";
import {
  ASPECT_OPTIONS,
  FRAMING_OPTIONS,
  type AspectRatio,
  type Clip,
  type Project,
  type CaptionSegment,
  type FramingMode,
  type Resolution,
} from "@/lib/types";

export const Route = createFileRoute("/app/projects/$projectId/clips/$clipId")({
  loader: ({ params }) => {
    if (localId.test(params.projectId)) return null;
    const clip = getClip(params.projectId, params.clipId);
    const project = getProject(params.projectId);
    if (!clip || !project) throw notFound();
    return { clip, project };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: `Editar: ${loaderData?.clip.title ?? "clip"} — Klipora` }],
  }),
  component: Editor,
});

/** Everything the render worker needs to produce the final MP4. */
interface EditState {
  trimStart: number;
  trimEnd: number;
  captionsOn: boolean;
  captions: CaptionSegment[];
  style: CaptionStyle;
  aspect: AspectRatio;
  resolution: Resolution;
  framing: FramingMode;
  cropX: number;
  volume: number;
  muted: boolean;
  overlayText: string;
  overlayPos: number;
  overlayColor: string;
}

const storageKey = (id: string) => `klipora:edit:${id}`;
const BITRATE: Record<Resolution, string> = {
  "720p": "5 Mbps",
  "1080p": "8–10 Mbps",
};

function retime(
  seg: CaptionSegment,
  start: number,
  end: number,
): CaptionSegment {
  const step = (end - start) / Math.max(1, seg.words.length);
  return {
    ...seg,
    start,
    end,
    words: seg.words.map((w, i) => ({
      ...w,
      start: +(start + i * step).toFixed(2),
      end: +(start + (i + 1) * step - 0.04).toFixed(2),
    })),
  };
}

function retext(seg: CaptionSegment, text: string): CaptionSegment {
  const tokens = text.split(/\s+/).filter(Boolean);
  const sameCount = tokens.length === seg.words.length;
  const words = tokens.map((t, i) => ({
    text: t,
    start: 0,
    end: 0,
    emphasis: sameCount ? seg.words[i]?.emphasis : false,
  }));
  return retime({ ...seg, words }, seg.start, seg.end);
}

function Editor() {
  const data = Route.useLoaderData();
  const { projectId, clipId } = Route.useParams();
  return data ? (
    <SampleEditor key={clipId} {...data} />
  ) : (
    <RealClipEditor
      key={projectId + "/" + clipId}
      projectId={projectId}
      clipId={clipId}
    />
  );
}

function SampleEditor({ clip, project }: { clip: Clip; project: Project }) {
  const initial: EditState = {
    trimStart: clip.start,
    trimEnd: clip.end,
    captionsOn: true,
    captions: clip.captions,
    style: CAPTION_PRESETS.hormozi.style,
    aspect: clip.aspect,
    resolution: clip.resolution,
    framing:
      project.source === "twitch" || project.source === "kick"
        ? "streamer-split"
        : "face-track",
    cropX: 50,
    volume: 100,
    muted: false,
    overlayText: "",
    overlayPos: 12,
    overlayColor: "#ffffff",
  };
  const [s, setS] = useState<EditState>(initial);
  const [dirty, setDirty] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const set = useCallback(
    <K extends keyof EditState>(k: K, v: EditState[K]) => {
      setS((prev) => ({ ...prev, [k]: v }));
      setDirty(true);
    },
    [],
  );

  // Restore saved edits after hydration (localStorage is browser-only).
  useEffect(() => {
    const raw = localStorage.getItem(storageKey(clip.id));
    if (raw) {
      try {
        setS((prev) => ({
          ...prev,
          ...(JSON.parse(raw) as Partial<EditState>),
        }));
      } catch {
        localStorage.removeItem(storageKey(clip.id));
      }
    }
  }, [clip.id]);

  // --- playback ---------------------------------------------------------
  const length = Math.max(1, s.trimEnd - s.trimStart);
  const offset = s.trimStart - clip.start; // caption times are relative to clip.start
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [localUrl, setLocalUrl] = useState<string | null>(null);
  const videoRefs = useRef<HTMLVideoElement[]>([]);
  const registerVideo = (el: HTMLVideoElement | null) => {
    if (el && !videoRefs.current.includes(el)) videoRefs.current.push(el);
  };

  useEffect(
    () => () => {
      if (localUrl) URL.revokeObjectURL(localUrl);
    },
    [localUrl],
  );

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      setT((prev) => (prev + dt >= length ? 0 : prev + dt));
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, length]);

  // Keep local preview videos in sync with the editor clock.
  useEffect(() => {
    for (const v of videoRefs.current) {
      if (!v.isConnected) continue;
      if (Math.abs(v.currentTime - t) > 0.3)
        v.currentTime = Math.min(
          t,
          Number.isFinite(v.duration) ? v.duration : t,
        );
      if (playing && v.paused) void v.play().catch(() => undefined);
      if (!playing && !v.paused) v.pause();
    }
  }, [t, playing]);

  useEffect(() => {
    videoRefs.current = videoRefs.current.filter((v) => v.isConnected);
    videoRefs.current.forEach((v, i) => {
      v.volume = s.volume / 100;
      v.muted = s.muted || i > 0;
    });
  }, [s.volume, s.muted, localUrl, s.framing]);

  useEffect(() => {
    if (t > length) setT(0);
  }, [length, t]);

  const save = () => {
    localStorage.setItem(storageKey(clip.id), JSON.stringify(s));
    setDirty(false);
    toast.success("Cambios guardados");
  };
  const reset = () => {
    localStorage.removeItem(storageKey(clip.id));
    setS(initial);
    setDirty(false);
    setT(0);
    toast("Clip restaurado a la versión generada por la IA");
  };

  const winStart = 0;
  const winEnd = project.durationSec;

  return (
    <div>
      <SampleDataNotice />
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <Link
            to="/app/projects/$projectId"
            params={{ projectId: project.id }}
            className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-4" aria-hidden /> {project.title}
          </Link>
          <h1 className="mt-1 flex items-center gap-3 text-2xl font-extrabold">
            <span className="truncate">{clip.title}</span>
            <ScoreBadge score={clip.score} />
          </h1>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={reset}>
            <RotateCcw /> Restaurar
          </Button>
          <Button variant="outline" onClick={save} disabled={!dirty}>
            <Save /> Guardar
          </Button>
          <Button onClick={() => setExportOpen(true)}>
            <Download /> Exportar
          </Button>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
        {/* Preview */}
        <div className="lg:sticky lg:top-20 lg:self-start">
          <div
            className="mx-auto"
            style={{
              maxWidth:
                s.aspect === "16:9" ? 420 : s.aspect === "9:16" ? 300 : 360,
            }}
          >
            <Stage
              s={s}
              hue={clip.hue}
              localUrl={localUrl}
              registerVideo={registerVideo}
            >
              {s.captionsOn && (
                <CaptionOverlay
                  segments={s.captions}
                  time={t + offset}
                  style={s.style}
                  scale={s.aspect === "16:9" ? 0.5 : 0.62}
                />
              )}
              {s.overlayText && (
                <p
                  className="pointer-events-none absolute inset-x-0 px-4 text-center font-display text-lg font-extrabold drop-shadow-[0_2px_6px_rgba(0,0,0,.8)]"
                  style={{ top: `${s.overlayPos}%`, color: s.overlayColor }}
                >
                  {s.overlayText}
                </p>
              )}
            </Stage>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <Button
              size="icon"
              onClick={() => setPlaying((p) => !p)}
              aria-label={playing ? "Pausar" : "Reproducir"}
            >
              {playing ? <Pause /> : <Play className="fill-current" />}
            </Button>
            <input
              type="range"
              min={0}
              max={length}
              step={0.05}
              value={Math.min(t, length)}
              onChange={(e) => setT(Number(e.target.value))}
              className="flex-1"
              aria-label="Posición de reproducción"
            />
            <span className="w-24 text-right font-mono text-xs text-muted-foreground">
              {formatTimecode(t)} / {formatTimecode(length)}
            </span>
          </div>

          <label className="mt-4 flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-border px-3 py-2 text-xs text-muted-foreground hover:border-primary/50">
            <FileVideo className="size-4 shrink-0" aria-hidden />
            <span>
              {localUrl
                ? "Usando tu archivo local para previsualizar el encuadre"
                : "Previsualiza el encuadre con un video de tu ordenador (no se sube)"}
            </span>
            <input
              type="file"
              accept="video/*"
              className="sr-only"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) {
                  setLocalUrl(URL.createObjectURL(f));
                  setT(0);
                }
              }}
            />
          </label>
        </div>

        {/* Controls */}
        <Tabs defaultValue="trim">
          <TabsList className="flex-wrap">
            <TabsTrigger value="trim">Recorte</TabsTrigger>
            <TabsTrigger value="captions">Subtítulos</TabsTrigger>
            <TabsTrigger value="style">Estilo</TabsTrigger>
            <TabsTrigger value="format">Formato</TabsTrigger>
            <TabsTrigger value="audio">Audio y texto</TabsTrigger>
          </TabsList>

          <TabsContent value="trim" className="mt-4 grid gap-5">
            <Panel
              title="Inicio y final"
              hint="Puedes ajustar el corte dentro de todo el video original. El render final ajusta el corte al límite de palabra más cercano."
            >
              <TrimBar
                winStart={winStart}
                winEnd={winEnd}
                start={s.trimStart}
                end={s.trimEnd}
                aiStart={clip.start}
                aiEnd={clip.end}
                playhead={s.trimStart + t}
              />
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <NumberSlider
                  label="Inicio"
                  min={winStart}
                  max={s.trimEnd - 3}
                  value={s.trimStart}
                  onChange={(v) => set("trimStart", v)}
                />
                <NumberSlider
                  label="Final"
                  min={s.trimStart + 3}
                  max={winEnd}
                  value={s.trimEnd}
                  onChange={(v) => set("trimEnd", v)}
                />
              </div>
              <p className="mt-3 text-sm">
                Duración:{" "}
                <span className="font-mono">{length.toFixed(1)} s</span>
                {length > 60 && (
                  <span className="ml-2 text-warm">
                    TikTok y Reels admiten hasta 90 s con buena retención;
                    Shorts, hasta 60 s.
                  </span>
                )}
              </p>
            </Panel>
            <Panel title="Por qué la IA eligió este momento">
              <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                {MOMENT_KIND_LABEL[clip.kind]}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">
                {clip.reason}
              </p>
              {clip.evidence.length > 0 && (
                <ul
                  className="mt-3 flex flex-wrap gap-1.5"
                  aria-label="Señales detectadas"
                >
                  {clip.evidence.map((e) => (
                    <li
                      key={e}
                      className="rounded bg-muted px-1.5 py-0.5 text-xs"
                    >
                      {e}
                    </li>
                  ))}
                </ul>
              )}
            </Panel>
          </TabsContent>

          <TabsContent value="captions" className="mt-4 grid gap-4">
            <div className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
              <div>
                <p className="font-semibold">Subtítulos quemados en el video</p>
                <p className="text-xs text-muted-foreground">
                  Transcripción{" "}
                  {project.language === "es" ? "en español" : "en inglés"} con
                  tiempos por palabra.
                </p>
              </div>
              <Switch
                checked={s.captionsOn}
                onCheckedChange={(v) => set("captionsOn", v)}
                aria-label="Activar subtítulos"
              />
            </div>
            <ol className={cn("grid gap-2", !s.captionsOn && "opacity-50")}>
              {s.captions.map((seg, i) => {
                const active = t + offset >= seg.start && t + offset <= seg.end;
                const update = (next: CaptionSegment) =>
                  set(
                    "captions",
                    s.captions.map((x, j) => (j === i ? next : x)),
                  );
                return (
                  <li
                    key={seg.id}
                    className={cn(
                      "rounded-lg border border-border bg-card p-3",
                      active && "border-primary/60",
                    )}
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <Input
                        type="number"
                        step={0.1}
                        value={seg.start}
                        onChange={(e) =>
                          update(
                            retime(
                              seg,
                              Math.min(Number(e.target.value), seg.end - 0.2),
                              seg.end,
                            ),
                          )
                        }
                        className="h-8 w-20 font-mono text-xs"
                        aria-label={`Inicio de la frase ${i + 1}`}
                      />
                      <span className="text-muted-foreground">→</span>
                      <Input
                        type="number"
                        step={0.1}
                        value={seg.end}
                        onChange={(e) =>
                          update(
                            retime(
                              seg,
                              seg.start,
                              Math.max(Number(e.target.value), seg.start + 0.2),
                            ),
                          )
                        }
                        className="h-8 w-20 font-mono text-xs"
                        aria-label={`Final de la frase ${i + 1}`}
                      />
                      <Input
                        key={seg.words.map((w) => w.text).join(" ")}
                        defaultValue={seg.words.map((w) => w.text).join(" ")}
                        onBlur={(e) => update(retext(seg, e.target.value))}
                        className="h-8 min-w-48 flex-1"
                        aria-label={`Texto de la frase ${i + 1}`}
                      />
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {seg.words.map((w, wi) => (
                        <button
                          key={wi}
                          type="button"
                          aria-pressed={!!w.emphasis}
                          onClick={() =>
                            update({
                              ...seg,
                              words: seg.words.map((x, k) =>
                                k === wi ? { ...x, emphasis: !x.emphasis } : x,
                              ),
                            })
                          }
                          className="rounded px-1.5 py-0.5 text-xs text-muted-foreground ring-1 ring-border aria-pressed:bg-warm/20 aria-pressed:text-warm aria-pressed:ring-warm/50"
                        >
                          {w.text}
                        </button>
                      ))}
                    </div>
                  </li>
                );
              })}
            </ol>
            <p className="text-xs text-muted-foreground">
              Pulsa una palabra para marcarla como importante (se resalta en
              Hormozi y Minimalista). Edita el texto y sal del campo para
              aplicarlo.
            </p>
          </TabsContent>

          <TabsContent value="style" className="mt-4 grid gap-5">
            <Panel title="Estilo base">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-5">
                {(Object.keys(CAPTION_PRESETS) as CaptionPresetKey[]).map(
                  (k) => (
                    <button
                      key={k}
                      type="button"
                      aria-pressed={s.style.preset === k}
                      onClick={() => set("style", CAPTION_PRESETS[k].style)}
                      className="rounded-lg border border-border bg-background p-2 text-left transition-colors hover:border-primary/50 aria-pressed:border-primary aria-pressed:bg-primary/10"
                    >
                      <span
                        className="block text-sm font-semibold"
                        style={{
                          fontFamily: CAPTION_PRESETS[k].style.font,
                          color: CAPTION_PRESETS[k].style.highlight,
                        }}
                      >
                        {CAPTION_PRESETS[k].label}
                      </span>
                      <span className="mt-0.5 block text-[11px] leading-tight text-muted-foreground">
                        {CAPTION_PRESETS[k].description}
                      </span>
                    </button>
                  ),
                )}
              </div>
            </Panel>
            <Panel title="Ajustes">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="font">Tipografía</Label>
                  <select
                    id="font"
                    value={s.style.font}
                    onChange={(e) =>
                      set("style", { ...s.style, font: e.target.value })
                    }
                    className="mt-1.5 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                  >
                    {CAPTION_FONTS.map((f) => (
                      <option key={f.value} value={f.value}>
                        {f.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label htmlFor="anim">Animación de entrada</Label>
                  <select
                    id="anim"
                    value={s.style.animation}
                    onChange={(e) =>
                      set("style", {
                        ...s.style,
                        animation: e.target.value as CaptionAnimation,
                      })
                    }
                    className="mt-1.5 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                  >
                    <option value="none">Ninguna</option>
                    <option value="pop">Pop</option>
                    <option value="slide">Deslizar</option>
                    <option value="fade">Fundido</option>
                  </select>
                </div>
                <RangeField
                  label="Tamaño"
                  min={16}
                  max={72}
                  value={s.style.size}
                  onChange={(v) => set("style", { ...s.style, size: v })}
                  unit="px"
                />
                <RangeField
                  label="Posición vertical"
                  min={8}
                  max={92}
                  value={s.style.position}
                  onChange={(v) => set("style", { ...s.style, position: v })}
                  unit="%"
                />
                <RangeField
                  label="Palabras por línea"
                  min={1}
                  max={8}
                  value={s.style.wordsPerLine}
                  onChange={(v) =>
                    set("style", { ...s.style, wordsPerLine: v })
                  }
                />
                <RangeField
                  label="Contorno"
                  min={0}
                  max={10}
                  value={s.style.outline}
                  onChange={(v) => set("style", { ...s.style, outline: v })}
                  unit="px"
                />
                <RangeField
                  label="Sombra"
                  min={0}
                  max={16}
                  value={s.style.shadow}
                  onChange={(v) => set("style", { ...s.style, shadow: v })}
                  unit="px"
                />
                <div className="grid grid-cols-3 gap-3">
                  <ColorField
                    label="Texto"
                    value={s.style.color}
                    onChange={(v) => set("style", { ...s.style, color: v })}
                  />
                  <ColorField
                    label="Resaltado"
                    value={s.style.highlight}
                    onChange={(v) => set("style", { ...s.style, highlight: v })}
                  />
                  <ColorField
                    label="Contorno"
                    value={s.style.outlineColor}
                    onChange={(v) =>
                      set("style", { ...s.style, outlineColor: v })
                    }
                  />
                </div>
              </div>
              <div className="mt-5 flex flex-wrap gap-6">
                <ToggleField
                  label="Mayúsculas"
                  checked={s.style.uppercase}
                  onChange={(v) => set("style", { ...s.style, uppercase: v })}
                />
                <ToggleField
                  label="Karaoke (rellenar al hablar)"
                  checked={s.style.karaoke}
                  onChange={(v) => set("style", { ...s.style, karaoke: v })}
                />
                <ToggleField
                  label="Resaltar solo palabras clave"
                  checked={s.style.emphasisOnly}
                  onChange={(v) =>
                    set("style", { ...s.style, emphasisOnly: v })
                  }
                />
                <ToggleField
                  label="Fondo detrás del texto"
                  checked={s.style.background}
                  onChange={(v) => set("style", { ...s.style, background: v })}
                />
              </div>
            </Panel>
          </TabsContent>

          <TabsContent value="format" className="mt-4 grid gap-5">
            <Panel title="Relación de aspecto">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {ASPECT_OPTIONS.map((a) => (
                  <OptionButton
                    key={a.value}
                    active={s.aspect === a.value}
                    onClick={() => set("aspect", a.value)}
                    title={a.label}
                    hint={a.hint}
                  />
                ))}
              </div>
            </Panel>
            <Panel
              title="Encuadre"
              hint="Nunca se estira la imagen: se recorta siguiendo al sujeto o se rellena con desenfoque."
            >
              <div className="grid gap-2 sm:grid-cols-2">
                {FRAMING_OPTIONS.filter(
                  (f) => f.value !== "gameplay-track",
                ).map((f) => (
                  <OptionButton
                    key={f.value}
                    active={s.framing === f.value}
                    onClick={() => set("framing", f.value)}
                    title={f.label}
                    hint={f.hint}
                  />
                ))}
              </div>
              {s.framing === "manual" && (
                <div className="mt-4">
                  <RangeField
                    label="Posición horizontal del recorte"
                    min={0}
                    max={100}
                    value={s.cropX}
                    onChange={(v) => set("cropX", v)}
                    unit="%"
                  />
                </div>
              )}
            </Panel>
            <Panel title="Resolución de exportación">
              <div className="grid grid-cols-2 gap-2">
                {(["720p", "1080p"] as const).map((r) => (
                  <OptionButton
                    key={r}
                    active={s.resolution === r}
                    onClick={() => set("resolution", r)}
                    title={r}
                    hint={`H.264 · AAC 192 kbps · ${BITRATE[r]}`}
                  />
                ))}
              </div>
            </Panel>
          </TabsContent>

          <TabsContent value="audio" className="mt-4 grid gap-5">
            <Panel title="Audio">
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => set("muted", !s.muted)}
                  aria-label={s.muted ? "Activar sonido" : "Silenciar"}
                  aria-pressed={s.muted}
                >
                  {s.muted ? <VolumeX /> : <Volume2 />}
                </Button>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={s.volume}
                  disabled={s.muted}
                  onChange={(e) => set("volume", Number(e.target.value))}
                  className="flex-1"
                  aria-label="Volumen"
                />
                <span className="w-12 text-right font-mono text-sm">
                  {s.muted ? "—" : `${s.volume}%`}
                </span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Por encima del 100 % el render aplica normalización para evitar
                saturación.
              </p>
            </Panel>
            <Panel title="Texto personalizado">
              <Label htmlFor="overlay">Texto superpuesto</Label>
              <Input
                id="overlay"
                value={s.overlayText}
                onChange={(e) => set("overlayText", e.target.value)}
                placeholder={clip.hook}
                className="mt-1.5"
                maxLength={80}
              />
              <div className="mt-3 flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => set("overlayText", clip.hook)}
                >
                  Usar el gancho sugerido
                </Button>
                {s.overlayText && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => set("overlayText", "")}
                  >
                    Quitar
                  </Button>
                )}
              </div>
              <div className="mt-4 grid gap-4 sm:grid-cols-[1fr_auto]">
                <RangeField
                  label="Posición vertical"
                  min={4}
                  max={90}
                  value={s.overlayPos}
                  onChange={(v) => set("overlayPos", v)}
                  unit="%"
                />
                <ColorField
                  label="Color"
                  value={s.overlayColor}
                  onChange={(v) => set("overlayColor", v)}
                />
              </div>
            </Panel>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={exportOpen} onOpenChange={setExportOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Exportar clip</DialogTitle>
            <DialogDescription>
              Estos ajustes forman el trabajo de render que FFmpeg procesará en
              segundo plano. El render real se conecta en la siguiente fase; tus
              cambios ya se pueden guardar.
            </DialogDescription>
          </DialogHeader>
          <dl className="grid grid-cols-2 gap-y-1.5 text-sm text-muted-foreground">
            <dt>Tramo</dt>
            <dd className="text-right font-mono text-foreground">
              {formatTimecode(s.trimStart)} → {formatTimecode(s.trimEnd)}
            </dd>
            <dt>Salida</dt>
            <dd className="text-right text-foreground">
              {s.aspect} · {s.resolution} · FPS original
            </dd>
            <dt>Vídeo / audio</dt>
            <dd className="text-right text-foreground">
              H.264 {BITRATE[s.resolution]} · AAC 192 kbps
            </dd>
            <dt>Encuadre</dt>
            <dd className="text-right text-foreground">
              {FRAMING_OPTIONS.find((f) => f.value === s.framing)?.label}
            </dd>
            <dt>Subtítulos</dt>
            <dd className="text-right text-foreground">
              {s.captionsOn
                ? `${CAPTION_PRESETS[s.style.preset].label} (quemados, ASS)`
                : "Desactivados"}
            </dd>
            <dt>Audio</dt>
            <dd className="text-right text-foreground">
              {s.muted ? "Silenciado" : `${s.volume}%`}
            </dd>
          </dl>
          <DialogFooter>
            <Button variant="outline" onClick={() => setExportOpen(false)}>
              Cerrar
            </Button>
            <Button
              onClick={() => {
                save();
                setExportOpen(false);
              }}
            >
              <Save /> Guardar ajustes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Stage({
  s,
  hue,
  localUrl,
  registerVideo,
  children,
}: {
  s: EditState;
  hue: number;
  localUrl: string | null;
  registerVideo: (el: HTMLVideoElement | null) => void;
  children: React.ReactNode;
}) {
  const vertical = s.aspect !== "16:9";
  const objectPos = s.framing === "manual" ? `${s.cropX}% 50%` : "50% 35%";

  if (!localUrl) {
    return (
      <Poster
        hue={hue}
        className={cn("w-full ring-1 ring-white/10", ASPECT_CLASS[s.aspect])}
      >
        {s.framing === "streamer-split" && vertical && (
          <div
            className="absolute inset-x-0 top-[34%] border-t-2 border-dashed border-white/40"
            aria-hidden
          >
            <span className="absolute top-1 left-2 text-[10px] text-white/70 uppercase">
              Gameplay
            </span>
            <span className="absolute -top-5 left-2 text-[10px] text-white/70 uppercase">
              Cámara
            </span>
          </div>
        )}
        {s.framing === "blur-fill" && vertical && (
          <div
            className="absolute inset-x-0 top-1/2 aspect-video -translate-y-1/2 border-y border-white/40 bg-white/5"
            aria-hidden
          />
        )}
        {(s.framing === "face-track" || s.framing === "subject-track") && (
          <div
            className="absolute top-[22%] left-1/2 size-16 -translate-x-1/2 rounded-full border-2 border-primary/80"
            aria-hidden
          />
        )}
        {s.framing === "manual" && (
          <div
            className="absolute inset-y-0 w-1 bg-primary/70"
            style={{ left: `${s.cropX}%` }}
            aria-hidden
          />
        )}
        {children}
      </Poster>
    );
  }

  return (
    <div
      className={cn(
        "relative w-full overflow-hidden rounded-lg bg-black ring-1 ring-white/10",
        ASPECT_CLASS[s.aspect],
      )}
    >
      {s.framing === "blur-fill" && vertical ? (
        <>
          <video
            ref={registerVideo}
            src={localUrl}
            playsInline
            loop
            className="absolute inset-0 size-full scale-110 object-cover blur-xl brightness-75"
          />
          <video
            ref={registerVideo}
            src={localUrl}
            playsInline
            loop
            className="absolute inset-0 size-full object-contain"
          />
        </>
      ) : s.framing === "streamer-split" && vertical ? (
        <>
          <div className="absolute inset-x-0 top-0 h-[34%] overflow-hidden">
            {/* Webcam region: top-right corner of the source, zoomed */}
            <video
              ref={registerVideo}
              src={localUrl}
              playsInline
              loop
              className="absolute size-full scale-[2.4] object-cover"
              style={{ transformOrigin: "92% 12%" }}
            />
          </div>
          <div className="absolute inset-x-0 bottom-0 h-[66%] overflow-hidden border-t border-black">
            <video
              ref={registerVideo}
              src={localUrl}
              playsInline
              loop
              className="size-full object-cover"
            />
          </div>
        </>
      ) : (
        <video
          ref={registerVideo}
          src={localUrl}
          playsInline
          loop
          className="absolute inset-0 size-full object-cover"
          style={{ objectPosition: objectPos }}
        />
      )}
      {children}
    </div>
  );
}

function TrimBar({
  winStart,
  winEnd,
  start,
  end,
  aiStart,
  aiEnd,
  playhead,
}: {
  winStart: number;
  winEnd: number;
  start: number;
  end: number;
  aiStart: number;
  aiEnd: number;
  playhead: number;
}) {
  const pct = (v: number) => ((v - winStart) / (winEnd - winStart)) * 100;
  return (
    <div
      className="relative h-12 overflow-hidden rounded-lg bg-muted"
      aria-hidden
    >
      <div className="absolute inset-y-0 flex w-full items-center gap-px px-1 opacity-40">
        {Array.from({ length: 60 }, (_, i) => (
          <span
            key={i}
            className="flex-1 rounded-sm bg-foreground"
            style={{ height: `${20 + ((i * 37) % 60)}%` }}
          />
        ))}
      </div>
      <div
        className="absolute inset-y-0 border-x-2 border-dashed border-cool/70"
        style={{
          left: `${pct(aiStart)}%`,
          width: `${pct(aiEnd) - pct(aiStart)}%`,
        }}
      />
      <div
        className="absolute inset-y-0 border-x-4 border-primary bg-primary/15"
        style={{ left: `${pct(start)}%`, width: `${pct(end) - pct(start)}%` }}
      />
      <div
        className="absolute inset-y-0 w-0.5 bg-foreground"
        style={{ left: `${pct(playhead)}%` }}
      />
      <span className="absolute top-1 right-2 text-[10px] text-cool">
        — momento detectado
      </span>
    </div>
  );
}

function Panel({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-xl border border-border bg-card p-4">
      <h2 className="mb-3 text-sm font-semibold">{title}</h2>
      {children}
      {hint && <p className="mt-3 text-xs text-muted-foreground">{hint}</p>}
    </section>
  );
}

function NumberSlider({
  label,
  min,
  max,
  value,
  onChange,
}: {
  label: string;
  min: number;
  max: number;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-sm">
        <span>{label}</span>
        <span className="font-mono text-xs text-muted-foreground">
          {formatTimecode(value)}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={0.1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full"
        aria-label={label}
      />
    </div>
  );
}

function RangeField({
  label,
  min,
  max,
  value,
  onChange,
  unit = "",
}: {
  label: string;
  min: number;
  max: number;
  value: number;
  onChange: (v: number) => void;
  unit?: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-sm">
        <span>{label}</span>
        <span className="font-mono text-xs text-muted-foreground">
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full"
        aria-label={label}
      />
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="grid gap-1.5 text-sm">
      {label}
      <input
        type="color"
        value={value.slice(0, 7)}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-full cursor-pointer rounded-md border border-input bg-background p-1"
      />
    </label>
  );
}

function ToggleField({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <Switch checked={checked} onCheckedChange={onChange} />
      {label}
    </label>
  );
}

function OptionButton({
  active,
  onClick,
  title,
  hint,
}: {
  active: boolean;
  onClick: () => void;
  title: string;
  hint: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className="rounded-lg border border-border bg-background px-3 py-2 text-left transition-colors hover:border-primary/50 aria-pressed:border-primary aria-pressed:bg-primary/10"
    >
      <span className="block text-sm font-semibold">{title}</span>
      <span className="block text-xs text-muted-foreground">{hint}</span>
    </button>
  );
}
