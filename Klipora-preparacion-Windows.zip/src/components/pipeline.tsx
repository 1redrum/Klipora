import { AlertTriangle, Check, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import { PIPELINE_STAGES, type StageState } from '@/lib/types'

export function Pipeline({ stages }: { stages: StageState[] }) {
  return (
    <ol className="grid gap-1">
      {stages.map((s, i) => {
        const label = PIPELINE_STAGES.find((p) => p.key === s.key)?.label ?? s.key
        return (
          <li
            key={s.key}
            className={cn(
              'grid grid-cols-[2rem_1fr_auto] items-center gap-3 rounded-lg px-3 py-2.5',
              s.status === 'running' && 'bg-primary/8 ring-1 ring-primary/30',
              s.status === 'error' && 'bg-destructive/10 ring-1 ring-destructive/40',
            )}
          >
            <span
              className={cn(
                'grid size-7 place-items-center rounded-full border font-mono text-xs',
                s.status === 'done' && 'border-primary bg-primary text-primary-foreground',
                s.status === 'running' && 'border-primary text-primary',
                s.status === 'error' && 'border-destructive bg-destructive text-white',
                s.status === 'pending' && 'border-border text-muted-foreground',
              )}
            >
              {s.status === 'done' ? (
                <Check className="size-3.5" aria-hidden />
              ) : s.status === 'running' ? (
                <Loader2 className="size-3.5 animate-spin motion-reduce:animate-none" aria-hidden />
              ) : s.status === 'error' ? (
                <AlertTriangle className="size-3.5" aria-hidden />
              ) : (
                i + 1
              )}
            </span>
            <div className="min-w-0">
              <p className={cn('text-sm font-medium', s.status === 'pending' && 'text-muted-foreground')}>{label}</p>
              {s.detail && <p className="truncate font-mono text-xs text-muted-foreground">{s.detail}</p>}
              {s.status === 'running' && (
                <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-muted">
                  <div className="h-full rounded-full bg-primary" style={{ width: `${s.progress}%` }} />
                </div>
              )}
            </div>
            <span className="font-mono text-xs text-muted-foreground">
              {s.status === 'done' ? '100%' : s.status === 'pending' ? '—' : `${s.progress}%`}
            </span>
          </li>
        )
      })}
    </ol>
  )
}

export function overallProgress(stages: StageState[]) {
  const total = stages.length - 1 // "completed" carries no work
  const sum = stages.slice(0, total).reduce((acc, s) => acc + (s.status === 'done' ? 100 : s.progress), 0)
  return Math.round(sum / total)
}
