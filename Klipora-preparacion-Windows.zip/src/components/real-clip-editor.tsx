import { Link } from "@tanstack/react-router";
import {
  cloneElement,
  useCallback,
  useId,
  useEffect,
  useRef,
  useState,
  type ReactElement,
} from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CAPTION_PRESETS } from "@/lib/caption-styles";
import {
  draftProblem,
  draftSchema,
  editorFonts,
  presetStyle,
  type ClipDraft,
  type EditorResponse,
} from "@/lib/editor-draft";
import { formatTimecode } from "@/lib/format";
import { localApi, localRequest, type LocalProject } from "@/lib/local";
import { ASPECT_OPTIONS, FRAMING_OPTIONS } from "@/lib/types";

type Recovery = { revision: string; draft: ClipDraft };
type Preview = {
  start: number;
  end: number;
  version: string;
  device?: string;
  draft: ClipDraft;
};
const headers = { "Content-Type": "application/json", "x-klipora-local": "1" };
const message = (error: unknown) =>
  error instanceof Error ? error.message : String(error);

export function RealClipEditor({
  projectId,
  clipId,
}: {
  projectId: string;
  clipId: string;
}) {
  const path = "/" + projectId;
  const clip = "/" + clipId;
  const key = "klipora:editor-recovery:" + projectId + ":" + clipId;
  const [loaded, setLoaded] = useState<{
    response: EditorResponse;
    recovery?: Recovery;
  }>();
  const [error, setError] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    localRequest<EditorResponse>(path + "/draft" + clip, {
      signal: controller.signal,
    })
      .then((response) => {
        let recovery: Recovery | undefined;
        try {
          const raw = window.localStorage.getItem(key);
          if (raw) {
            const data = JSON.parse(raw) as Recovery;
            const parsed = draftSchema.safeParse(data.draft);
            if (parsed.success && typeof data.revision === "string")
              recovery = { ...data, draft: parsed.data };
          }
        } catch {
          // The server draft remains available when browser storage is inaccessible.
        }
        if (!controller.signal.aborted) setLoaded({ response, recovery });
      })
      .catch((failure: unknown) => {
        if (!controller.signal.aborted) setError(message(failure));
      });
    return () => controller.abort();
  }, [path, clip, key]);

  if (error)
    return (
      <p role="alert" className="text-destructive">
        {error}
      </p>
    );
  if (!loaded) return <p role="status">Cargando editor…</p>;
  return (
    <Workspace
      {...loaded}
      path={path}
      clip={clip}
      projectId={projectId}
      storageKey={key}
    />
  );
}

function Workspace({
  response,
  recovery,
  path,
  clip,
  projectId,
  storageKey,
}: {
  response: EditorResponse;
  recovery?: Recovery;
  path: string;
  clip: string;
  projectId: string;
  storageKey: string;
}) {
  const original = response.draft;
  const { duration, title } = response;
  const [draft, setDraft] = useState(
    recovery?.revision === response.revision ? recovery.draft : original,
  );
  const [conflict, setConflict] = useState(
    recovery?.revision !== response.revision ? recovery : undefined,
  );
  const [saveStatus, setSaveStatus] = useState(
    draft === original ? "Guardado" : "Cambios pendientes",
  );
  const [saveError, setSaveError] = useState("");
  const [actionError, setActionError] = useState("");
  const [cursor, setCursor] = useState(draft.start);
  const [preview, setPreview] = useState<Preview>();
  const [previewing, setPreviewing] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [output, setOutput] = useState<{ id: string; ready: boolean }>();
  const [wordPage, setWordPage] = useState(0);
  const video = useRef<HTMLVideoElement>(null);
  const latest = useRef(draft);
  const saved = useRef({ draft: original, revision: response.revision });
  const flight = useRef<Promise<string> | null>(null);
  const pageSize = 30;

  const stash = useCallback(
    (value: ClipDraft, revision: string, clean = false) => {
      try {
        if (clean) window.localStorage.removeItem(storageKey);
        else
          window.localStorage.setItem(
            storageKey,
            JSON.stringify({ draft: value, revision }),
          );
      } catch {
        // A completed server write is authoritative.
      }
    },
    [storageKey],
  );

  function change(next: ClipDraft) {
    latest.current = next;
    setDraft(next);
    setSaveStatus("Cambios pendientes");
    stash(next, saved.current.revision);
  }

  const save = useCallback(() => {
    if (flight.current) return flight.current;
    const work = async () => {
      setSaveError("");
      while (latest.current !== saved.current.draft) {
        const value = latest.current;
        const invalid = draftProblem(value, duration);
        if (invalid) throw new Error(invalid);
        setSaveStatus("Guardando…");
        const result = await localRequest<EditorResponse>(
          path + "/draft" + clip,
          {
            method: "PUT",
            headers,
            body: JSON.stringify({
              draft: value,
              revision: saved.current.revision,
            }),
          },
        );
        saved.current = { draft: value, revision: result.revision };
        stash(latest.current, result.revision, latest.current === value);
      }
      setSaveStatus("Guardado");
      return saved.current.revision;
    };
    flight.current = work()
      .catch((failure: unknown) => {
        setSaveStatus("Cambios pendientes");
        setSaveError(message(failure));
        throw failure;
      })
      .finally(() => {
        flight.current = null;
      });
    return flight.current;
  }, [clip, duration, path, stash]);

  useEffect(() => {
    if (conflict || draft === saved.current.draft) return;
    const timer = window.setTimeout(() => void save().catch(() => {}), 300);
    return () => window.clearTimeout(timer);
  }, [conflict, draft, save]);

  const mediaStart = preview?.start ?? response.mediaStart;
  const mediaEnd = preview?.end ?? response.mediaEnd;
  const media = preview
    ? localApi + path + "/preview-media" + clip + "?v=" + preview.version
    : localApi + path + "/media" + clip;

  useEffect(() => {
    if (!video.current) return;
    video.current.volume = preview ? 1 : draft.volume / 100;
    video.current.muted = !preview && draft.muted;
  }, [draft.muted, draft.volume, preview]);

  const pendingId = output && !output.ready ? output.id : undefined;
  useEffect(() => {
    if (!pendingId) return;
    const controller = new AbortController();
    let timer: number;
    async function poll() {
      try {
        const project = await localRequest<LocalProject>(path, {
          signal: controller.signal,
        });
        if (controller.signal.aborted) return;
        if (project.clips.some((item) => item.id === pendingId)) {
          setOutput({ id: pendingId!, ready: true });
          setExporting(false);
          return;
        }
        if (project.status === "failed")
          throw new Error(project.error || "No se pudo exportar.");
        timer = window.setTimeout(poll, 1200);
      } catch (failure) {
        if (controller.signal.aborted) return;
        setActionError(message(failure));
        setOutput(undefined);
        setExporting(false);
      }
    }
    void poll();
    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [path, pendingId]);

  function move(time: number) {
    const clamped = Math.max(0, Math.min(duration, time));
    if (video.current) {
      video.current.pause();
      if (clamped >= mediaStart && clamped <= mediaEnd)
        video.current.currentTime = clamped - mediaStart;
    }
    setCursor(clamped);
  }

  async function previewDraft() {
    setPreviewing(true);
    setActionError("");
    const value = latest.current;
    try {
      const result = await localRequest<Omit<Preview, "draft">>(
        path + "/preview" + clip,
        {
          method: "POST",
          headers,
          body: JSON.stringify({ draft: value, cursor }),
        },
      );
      setCursor(result.start);
      setPreview({ ...result, draft: value });
    } catch (failure) {
      setActionError(message(failure));
    } finally {
      setPreviewing(false);
    }
  }

  async function exportDraft() {
    setExporting(true);
    setOutput(undefined);
    setActionError("");
    try {
      const revision = await save();
      const result = await localRequest<{ id: string }>(
        path + "/edit-export" + clip + "?revision=" + revision,
        {
          method: "POST",
          headers,
        },
      );
      setOutput({ id: result.id, ready: false });
    } catch (failure) {
      setExporting(false);
      setActionError(message(failure));
    }
  }

  function style<K extends keyof ClipDraft["style"]>(
    key: K,
    value: ClipDraft["style"][K],
  ) {
    change({ ...draft, style: { ...draft.style, [key]: value } });
  }
  function editWord(
    index: number,
    update: Partial<ClipDraft["words"][number]>,
  ) {
    change({
      ...draft,
      words: draft.words.map((word, i) =>
        i === index ? { ...word, ...update } : word,
      ),
    });
  }
  function editOverlay(
    index: number,
    update: Partial<ClipDraft["overlays"][number]>,
  ) {
    change({
      ...draft,
      overlays: draft.overlays.map((entry, i) =>
        i === index ? { ...entry, ...update } : entry,
      ),
    });
  }
  const pages = Math.max(1, Math.ceil(draft.words.length / pageSize));
  const page = Math.min(wordPage, pages - 1);
  const issue =
    draftProblem(draft, duration) ||
    (!draftSchema.safeParse(draft).success
      ? "Revisa los valores de los controles."
      : undefined);

  return (
    <div className="space-y-5">
      <Link
        to="/app/projects/$projectId"
        params={{ projectId }}
        className="text-sm text-muted-foreground hover:underline"
      >
        ← Volver al proyecto
      </Link>
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold">Editar clip</h1>
          <p className="text-muted-foreground">{title}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground" role="status">
            {saveStatus}
          </span>
          <Button
            variant="outline"
            disabled={Boolean(issue || conflict)}
            onClick={() => void save().catch(() => {})}
          >
            Guardar
          </Button>
          <Button
            disabled={Boolean(issue || conflict || exporting)}
            onClick={() => void exportDraft()}
          >
            {exporting ? "Exportando…" : "Exportar MP4"}
          </Button>
        </div>
      </header>
      {conflict && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border p-3">
          <p>
            Hay cambios locales y una versión más reciente guardada en disco.
          </p>
          <Button
            variant="outline"
            onClick={() => {
              change(conflict.draft);
              setConflict(undefined);
            }}
          >
            Recuperar cambios locales
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              stash(original, response.revision, true);
              setConflict(undefined);
            }}
          >
            Usar versión guardada
          </Button>
        </div>
      )}
      {(issue || saveError || actionError) && (
        <p role="alert" className="text-sm text-destructive">
          {actionError || saveError || issue}
        </p>
      )}
      {output?.ready && (
        <Button variant="outline" asChild>
          <a href={localApi + path + "/media/" + output.id} download>
            Descargar edición
          </a>
        </Button>
      )}
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(320px,420px)]">
        <section className="space-y-3 lg:sticky lg:top-20 lg:self-start">
          <video
            key={media}
            ref={video}
            src={media}
            controls
            preload="metadata"
            className="max-h-[55vh] w-full rounded-xl bg-black"
            aria-label="Vista previa del clip"
            onLoadedMetadata={(event) => {
              if (cursor >= mediaStart && cursor <= mediaEnd)
                event.currentTarget.currentTime = cursor - mediaStart;
            }}
            onTimeUpdate={(event) => {
              if (event.currentTarget.readyState >= 2)
                setCursor(mediaStart + event.currentTarget.currentTime);
            }}
          />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-sm text-muted-foreground">
              {preview
                ? preview.draft === draft
                  ? "Muestra actualizada"
                  : "Muestra de una edición anterior"
                : "Clip guardado"}
              {preview?.device && " · " + preview.device}
            </p>
            <div className="flex gap-2">
              {preview && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setPreview(undefined)}
                >
                  Ver clip guardado
                </Button>
              )}
              <Button
                size="sm"
                variant="outline"
                disabled={Boolean(issue || previewing)}
                onClick={() => void previewDraft()}
              >
                {previewing ? "Generando muestra…" : "Previsualizar cambios"}
              </Button>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">Línea de tiempo</h2>
              <span className="font-mono text-sm">
                {formatTimecode(cursor)} / {formatTimecode(duration)}
              </span>
            </div>
            <div
              className="relative mt-3 h-2 rounded-full bg-muted"
              aria-hidden
            >
              <div
                className="absolute h-full rounded-full bg-primary/65"
                style={{
                  left: (draft.start / duration) * 100 + "%",
                  width:
                    (Math.max(0, draft.end - draft.start) / duration) * 100 +
                    "%",
                }}
              />
            </div>
            <Input
              className="my-2"
              aria-label="Cursor de línea de tiempo"
              type="range"
              min={0}
              max={duration}
              step={0.01}
              value={cursor}
              onChange={(e) => move(Number(e.target.value))}
            />
            <div className="grid grid-cols-3 gap-2">
              <NumberField
                label="Cursor (s)"
                min={0}
                max={duration}
                value={Math.round(cursor * 1000) / 1000}
                change={move}
              />
              <NumberField
                label="Inicio (s)"
                min={0}
                max={duration}
                value={draft.start}
                change={(start) => change({ ...draft, start })}
              />
              <NumberField
                label="Fin (s)"
                min={0}
                max={duration}
                value={draft.end}
                change={(end) => change({ ...draft, end })}
              />
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="secondary"
                onClick={() =>
                  change({ ...draft, start: Number(cursor.toFixed(3)) })
                }
              >
                Inicio al cursor
              </Button>
              <Button
                size="sm"
                variant="secondary"
                onClick={() =>
                  change({
                    ...draft,
                    end: Math.min(duration, Number(cursor.toFixed(3))),
                  })
                }
              >
                Fin al cursor
              </Button>
              <NumberField
                label="Duración (s)"
                min={0.01}
                max={Math.max(0.01, duration - draft.start)}
                value={Number((draft.end - draft.start).toFixed(3))}
                change={(seconds) =>
                  change({
                    ...draft,
                    end: Math.min(
                      duration,
                      Number((draft.start + seconds).toFixed(3)),
                    ),
                  })
                }
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Los tiempos se refieren al video original. La muestra renderiza
            hasta cuatro segundos con los ajustes de exportación.
          </p>
        </section>
        <Tabs
          defaultValue="video"
          className="min-w-0 rounded-xl border border-border bg-card p-4"
        >
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="video">Video</TabsTrigger>
            <TabsTrigger value="captions">Subtítulos</TabsTrigger>
            <TabsTrigger value="texts">Textos</TabsTrigger>
            <TabsTrigger value="export">Salida</TabsTrigger>
          </TabsList>
          <TabsContent value="video" className="mt-4 space-y-4">
            <Field label="Encuadre">
              <select
                className={selectClass}
                value={draft.framing}
                onChange={(e) =>
                  change({
                    ...draft,
                    framing: e.target.value as ClipDraft["framing"],
                  })
                }
              >
                {FRAMING_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </Field>
            {draft.framing === "manual" && (
              <div className="grid grid-cols-2 gap-2">
                <NumberField
                  label="Posición horizontal (%)"
                  value={draft.x}
                  min={0}
                  max={100}
                  change={(x) => change({ ...draft, x })}
                />
                <NumberField
                  label="Posición vertical (%)"
                  value={draft.y}
                  min={0}
                  max={100}
                  change={(y) => change({ ...draft, y })}
                />
              </div>
            )}
            <NumberField
              label="Volumen (%)"
              value={draft.volume}
              min={0}
              max={100}
              change={(volume) => change({ ...draft, volume })}
            />
            <Toggle
              label="Silenciar audio"
              checked={draft.muted}
              change={(muted) => change({ ...draft, muted })}
            />
          </TabsContent>
          <TabsContent value="captions" className="mt-4 space-y-3">
            <Toggle
              label="Mostrar subtítulos"
              checked={draft.captions}
              change={(captions) => change({ ...draft, captions })}
            />
            <div className="grid grid-cols-2 gap-2">
              <Field label="Estilo">
                <select
                  className={selectClass}
                  value={draft.style.preset}
                  onChange={(e) =>
                    change({
                      ...draft,
                      style: presetStyle(
                        e.target.value as ClipDraft["style"]["preset"],
                      ),
                    })
                  }
                >
                  {Object.entries(CAPTION_PRESETS).map(([id, item]) => (
                    <option key={id} value={id}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Fuente">
                <select
                  className={selectClass}
                  value={draft.style.font}
                  onChange={(e) =>
                    style("font", e.target.value as ClipDraft["style"]["font"])
                  }
                >
                  {editorFonts.map((font) => (
                    <option key={font}>{font}</option>
                  ))}
                </select>
              </Field>
              <NumberField
                label="Tamaño"
                value={draft.style.size}
                min={8}
                max={160}
                change={(v) => style("size", v)}
              />
              <NumberField
                label="Palabras por línea"
                value={draft.style.wordsPerLine}
                min={1}
                max={24}
                step={1}
                change={(v) => style("wordsPerLine", v)}
              />
              <ColorField
                label="Color del texto"
                value={draft.style.color}
                change={(v) => style("color", v)}
              />
              <ColorField
                label="Color de resaltado"
                value={draft.style.highlight}
                change={(v) => style("highlight", v)}
              />
              <ColorField
                label="Color de contorno"
                value={draft.style.outlineColor}
                change={(v) => style("outlineColor", v)}
              />
              <NumberField
                label="Contorno"
                value={draft.style.outline}
                min={0}
                max={24}
                change={(v) => style("outline", v)}
              />
              <NumberField
                label="Sombra"
                value={draft.style.shadow}
                min={0}
                max={30}
                change={(v) => style("shadow", v)}
              />
              <NumberField
                label="Posición vertical (%)"
                value={draft.style.position}
                min={0}
                max={100}
                change={(v) => style("position", v)}
              />
              <Field label="Animación">
                <select
                  className={selectClass}
                  value={draft.style.animation}
                  onChange={(e) =>
                    style(
                      "animation",
                      e.target.value as ClipDraft["style"]["animation"],
                    )
                  }
                >
                  <option value="none">Ninguna</option>
                  <option value="pop">Rebote</option>
                  <option value="slide">Deslizar</option>
                  <option value="fade">Fundido</option>
                </select>
              </Field>
            </div>
            <div className="flex flex-wrap gap-3">
              <Toggle
                label="Mayúsculas"
                checked={draft.style.uppercase}
                change={(v) => style("uppercase", v)}
              />
              <Toggle
                label="Fondo"
                checked={draft.style.background}
                change={(v) => style("background", v)}
              />
              <Toggle
                label="Resaltado progresivo"
                checked={draft.style.karaoke}
                change={(v) => style("karaoke", v)}
              />
              <Toggle
                label="Solo palabras marcadas"
                checked={draft.style.emphasisOnly}
                change={(v) => style("emphasisOnly", v)}
              />
            </div>
            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-3">
              <h2 className="font-semibold">Palabras y tiempos</h2>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  const start = Math.max(0, Math.min(cursor, duration - 0.1));
                  change({
                    ...draft,
                    words: [
                      ...draft.words,
                      {
                        text: "",
                        start,
                        end: Math.min(duration, start + 0.35),
                        emphasis: false,
                      },
                    ],
                  });
                  setWordPage(Math.floor(draft.words.length / pageSize));
                }}
              >
                Añadir palabra
              </Button>
            </div>
            <div className="space-y-2">
              {draft.words
                .slice(page * pageSize, (page + 1) * pageSize)
                .map((word, row) => {
                  const index = page * pageSize + row;
                  return (
                    <div
                      key={index}
                      className="space-y-2 rounded-md border border-border p-2"
                    >
                      <Input
                        aria-label={"Palabra " + (index + 1)}
                        value={word.text}
                        onChange={(e) =>
                          editWord(index, { text: e.target.value })
                        }
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <NumberField
                          label={`Inicio palabra ${index + 1} (s)`}
                          min={0}
                          max={duration}
                          value={word.start}
                          change={(start) => editWord(index, { start })}
                        />
                        <NumberField
                          label={`Fin palabra ${index + 1} (s)`}
                          min={0}
                          max={duration}
                          value={word.end}
                          change={(end) => editWord(index, { end })}
                        />
                      </div>
                      <div className="flex items-center justify-between gap-1">
                        <Toggle
                          label={`Resaltar palabra ${index + 1}`}
                          checked={word.emphasis}
                          change={(emphasis) => editWord(index, { emphasis })}
                        />
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => move(word.start)}
                        >
                          Ir
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          aria-label={`Eliminar palabra ${index + 1}`}
                          onClick={() =>
                            change({
                              ...draft,
                              words: draft.words.filter((_, i) => i !== index),
                            })
                          }
                        >
                          Quitar
                        </Button>
                      </div>
                    </div>
                  );
                })}
            </div>
            {pages > 1 && (
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={!page}
                  onClick={() => setWordPage(page - 1)}
                >
                  Anterior
                </Button>
                <span className="text-xs">
                  {page + 1} / {pages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === pages - 1}
                  onClick={() => setWordPage(page + 1)}
                >
                  Siguiente
                </Button>
              </div>
            )}
          </TabsContent>
          <TabsContent value="texts" className="mt-4 space-y-4">
            <Button
              variant="outline"
              onClick={() => {
                const start = Math.max(
                  draft.start,
                  Math.min(cursor, draft.end - 0.1),
                );
                change({
                  ...draft,
                  overlays: [
                    ...draft.overlays,
                    {
                      text: "",
                      start,
                      end: Math.min(draft.end, start + 3),
                      x: 50,
                      y: 14,
                      size: 36,
                      color: "#ffffff",
                    },
                  ],
                });
              }}
              disabled={Boolean(issue)}
            >
              Añadir texto
            </Button>
            {draft.overlays.map((entry, index) => (
              <div
                key={index}
                className="space-y-2 rounded-md border border-border p-3"
              >
                <Field label={`Texto personalizado ${index + 1}`}>
                  <Textarea
                    value={entry.text}
                    onChange={(e) =>
                      editOverlay(index, { text: e.target.value })
                    }
                  />
                </Field>
                <div className="grid grid-cols-2 gap-2">
                  <NumberField
                    label="Inicio del texto (s)"
                    min={0}
                    max={duration}
                    value={entry.start}
                    change={(start) => editOverlay(index, { start })}
                  />
                  <NumberField
                    label="Fin del texto (s)"
                    min={0}
                    max={duration}
                    value={entry.end}
                    change={(end) => editOverlay(index, { end })}
                  />
                  <NumberField
                    label="Horizontal del texto (%)"
                    min={0}
                    max={100}
                    value={entry.x}
                    change={(x) => editOverlay(index, { x })}
                  />
                  <NumberField
                    label="Vertical del texto (%)"
                    min={0}
                    max={100}
                    value={entry.y}
                    change={(y) => editOverlay(index, { y })}
                  />
                  <NumberField
                    label="Tamaño del texto"
                    min={8}
                    max={160}
                    value={entry.size}
                    change={(size) => editOverlay(index, { size })}
                  />
                  <ColorField
                    label="Color personalizado"
                    value={entry.color}
                    change={(color) => editOverlay(index, { color })}
                  />
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() =>
                    change({
                      ...draft,
                      overlays: draft.overlays.filter((_, i) => i !== index),
                    })
                  }
                >
                  Quitar texto
                </Button>
              </div>
            ))}
          </TabsContent>
          <TabsContent value="export" className="mt-4 space-y-4">
            <Field label="Relación de aspecto">
              <select
                className={selectClass}
                value={draft.aspect}
                onChange={(e) =>
                  change({
                    ...draft,
                    aspect: e.target.value as ClipDraft["aspect"],
                  })
                }
              >
                {ASPECT_OPTIONS.map((o) => (
                  <option key={o.value}>{o.value}</option>
                ))}
              </select>
            </Field>
            <Field label="Resolución">
              <select
                className={selectClass}
                value={draft.resolution}
                onChange={(e) =>
                  change({
                    ...draft,
                    resolution: e.target.value as ClipDraft["resolution"],
                  })
                }
              >
                <option>720p</option>
                <option>1080p</option>
              </select>
            </Field>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

const selectClass =
  "h-9 w-full rounded-md border border-input bg-background px-2 text-sm";

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactElement<{ id?: string }>;
}) {
  const id = useId();
  return (
    <div className="space-y-1">
      <label htmlFor={id} className="block text-xs font-medium">
        {label}
      </label>
      {cloneElement(children, { id })}
    </div>
  );
}

function NumberField({
  label,
  value,
  min,
  max,
  step = 0.01,
  change,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  change: (value: number) => void;
}) {
  return (
    <Field label={label}>
      <Input
        type="number"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => change(Number(e.target.value))}
      />
    </Field>
  );
}

function ColorField({
  label,
  value,
  change,
}: {
  label: string;
  value: string;
  change: (value: string) => void;
}) {
  return (
    <Field label={label}>
      <Input
        type="color"
        className="w-full p-1"
        value={value.slice(0, 7)}
        onChange={(e) => change(e.target.value + value.slice(7))}
      />
    </Field>
  );
}

function Toggle({
  label,
  checked,
  change,
}: {
  label: string;
  checked: boolean;
  change: (value: boolean) => void;
}) {
  return (
    <label className="inline-flex items-center gap-2 text-sm">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => change(e.target.checked)}
      />
      {label}
    </label>
  );
}
