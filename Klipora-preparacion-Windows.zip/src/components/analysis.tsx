import { Gamepad2, MessagesSquare, ScanSearch } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { LOW_CONFIDENCE } from '@/lib/analysis/classifier'
import { CATEGORY_LABEL, CONTENT_MODE_OPTIONS, ENGINES, type EngineKey } from '@/lib/analysis/content'
import { REJECTION_LABEL, type RejectionReason } from '@/lib/analysis/selection'
import type { Project } from '@/lib/types'

const ENGINE_ICON = { general: MessagesSquare, gaming: Gamepad2 } as const

export function EngineBadge({ engine, className }: { engine: EngineKey; className?: string }) {
  const Icon = ENGINE_ICON[engine]
  return (
    <Badge variant="outline" className={cn('gap-1', engine === 'gaming' ? 'border-cool/50 text-cool' : 'border-warm/50 text-warm', className)}>
      <Icon className="size-3" aria-hidden />
      {engine === 'gaming' ? 'Motor B · Gaming' : 'Motor A · General'}
    </Badge>
  )
}

/** Which engine analysed the project, why, and what the selection discarded. */
export function AnalysisPanel({ project, className }: { project: Project; className?: string }) {
  const c = project.classification
  const modeLabel = CONTENT_MODE_OPTIONS.find((o) => o.value === project.contentMode)?.label

  if (!c) {
    return (
      <section className={cn('rounded-xl border border-border bg-card p-5 text-sm', className)} aria-labelledby="analysis-title">
        <h2 id="analysis-title" className="flex items-center gap-2 font-semibold">
          <ScanSearch className="size-4 text-muted-foreground" aria-hidden /> Tipo de contenido
        </h2>
        <p className="mt-2 text-muted-foreground">
          {modeLabel}.{' '}
          {project.contentMode === 'auto'
            ? 'La IA identifica el tipo de video en el paso «Identificando tipo de contenido» y elige el motor de análisis antes de buscar momentos.'
            : `Se usará el ${ENGINES[project.contentMode].label} cuando el video esté preparado.`}
        </p>
      </section>
    )
  }

  const def = ENGINES[c.engine]
  const pct = Math.round(c.confidence * 100)
  const rejected = Object.entries(project.selection?.rejected ?? {}) as [RejectionReason, number][]
  const discarded = rejected.reduce((a, [, n]) => a + n, 0)

  return (
    <section className={cn('rounded-xl border border-border bg-card p-5 text-sm', className)} aria-labelledby="analysis-title">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 id="analysis-title" className="flex items-center gap-2 font-semibold">
          <ScanSearch className="size-4 text-muted-foreground" aria-hidden /> Análisis del contenido
        </h2>
        <EngineBadge engine={c.engine} />
      </div>
      <p className="mt-2 text-muted-foreground">{def.description}</p>

      <dl className="mt-4 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5">
        <dt className="text-muted-foreground">Tipo detectado</dt>
        <dd className="text-right font-medium">{CATEGORY_LABEL[c.category]}</dd>
        <dt className="text-muted-foreground">Selección del motor</dt>
        <dd className="text-right">{c.decidedBy === 'auto' ? 'Automática' : 'Elegido por ti'}</dd>
        {c.decidedBy === 'auto' && (
          <>
            <dt className="text-muted-foreground">Confianza</dt>
            <dd className="flex items-center justify-end gap-2">
              <span className="h-1.5 w-20 overflow-hidden rounded-full bg-muted" aria-hidden>
                <span className={cn('block h-full rounded-full', c.confidence < LOW_CONFIDENCE ? 'bg-warm' : 'bg-primary')} style={{ width: `${pct}%` }} />
              </span>
              <span className="font-mono">{pct}%</span>
            </dd>
          </>
        )}
      </dl>
      {c.decidedBy === 'auto' && c.confidence < LOW_CONFIDENCE && (
        <p className="mt-2 text-xs text-warm">Confianza baja: si el motor no encaja, crea el proyecto eligiendo el tipo de contenido manualmente.</p>
      )}

      {c.evidence.length > 0 && (
        <>
          <p className="mt-4 text-xs font-semibold tracking-wide text-muted-foreground uppercase">Señales usadas</p>
          <ul className="mt-1.5 grid gap-1">
            {c.evidence.map((e) => (
              <li key={e} className="flex gap-2">
                <span className="mt-2 size-1 shrink-0 rounded-full bg-primary" aria-hidden />
                {e}
              </li>
            ))}
          </ul>
        </>
      )}

      {project.selection && (
        <>
          <p className="mt-4 text-xs font-semibold tracking-wide text-muted-foreground uppercase">Selección</p>
          <p className="mt-1.5">
            {project.selection.candidates} momentos candidatos · {project.clips.length} clips elegidos · {discarded} descartados
          </p>
          {rejected.length > 0 && (
            <ul className="mt-1.5 grid gap-1 text-muted-foreground">
              {rejected
                .sort((a, b) => b[1] - a[1])
                .map(([r, n]) => (
                  <li key={r} className="flex justify-between gap-3">
                    <span>{REJECTION_LABEL[r]}</span>
                    <span className="font-mono">{n}</span>
                  </li>
                ))}
            </ul>
          )}
        </>
      )}
    </section>
  )
}
