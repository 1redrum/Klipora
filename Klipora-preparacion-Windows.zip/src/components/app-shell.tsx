import { Link } from "@tanstack/react-router";
import { FolderOpen, Plus, Scissors } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Logo() {
  return (
    <Link
      to="/"
      className="flex items-center gap-2 font-display text-lg font-extrabold tracking-tight"
    >
      <span className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground">
        <Scissors className="size-4" aria-hidden />
      </span>
      Klipora
    </Link>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-content items-center gap-6 px-4 sm:px-6">
          <Logo />
          <nav className="flex items-center gap-1 text-sm">
            <Link
              to="/app"
              activeOptions={{ exact: true }}
              className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-muted-foreground transition-colors hover:text-foreground data-[status=active]:bg-secondary data-[status=active]:text-foreground"
            >
              <FolderOpen className="size-4" aria-hidden />
              Proyectos
            </Link>
          </nav>
          <div className="ml-auto">
            <Button asChild size="sm">
              <Link to="/app/new">
                <Plus /> Nuevo proyecto
              </Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-content px-4 py-8 sm:px-6">
        {children}
      </main>
    </div>
  );
}

export function SampleDataNotice() {
  return (
    <p className="mb-6 rounded-lg border border-dashed border-warm/50 bg-warm/5 px-4 py-2 text-sm text-warm">
      Proyecto de ejemplo con datos de demostración.
    </p>
  );
}
