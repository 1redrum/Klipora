import type { CaptionStyle } from '@/lib/caption-styles'
import type { CaptionSegment, Word } from '@/lib/types'

/** Picks the chunk of `wordsPerLine` words that contains the current time. */
function activeChunk(segments: CaptionSegment[], t: number, perLine: number) {
  const seg = segments.find((s) => t >= s.start && t <= s.end + 0.12)
  if (!seg) return null
  const idx = seg.words.findIndex((w) => t < w.end)
  const wordIdx = idx === -1 ? seg.words.length - 1 : idx
  const chunkStart = Math.floor(wordIdx / perLine) * perLine
  return { key: `${seg.id}-${chunkStart}`, words: seg.words.slice(chunkStart, chunkStart + perLine) }
}

export function CaptionOverlay({
  segments,
  time,
  style,
  scale = 1,
}: {
  segments: CaptionSegment[]
  time: number
  style: CaptionStyle
  scale?: number
}) {
  const chunk = activeChunk(segments, time, style.wordsPerLine)
  if (!chunk) return null
  const outline = style.outline * scale
  const textShadow = [
    style.shadow ? `0 ${style.shadow * 0.4 * scale}px ${style.shadow * scale}px rgba(0,0,0,.85)` : '',
  ]
    .filter(Boolean)
    .join(',')

  const render = (w: Word, i: number) => {
    const spoken = time >= w.start
    const active = time >= w.start && time <= w.end + 0.05
    let color = style.color
    if (style.karaoke) color = spoken ? style.highlight : style.color
    else if (style.emphasisOnly) color = w.emphasis ? style.highlight : style.color
    else color = active ? style.highlight : style.color
    return (
      <span
        key={i}
        className="inline-block transition-[color,transform] duration-100 motion-reduce:transition-none"
        style={{
          color,
          transform: !style.karaoke && active && style.animation === 'pop' ? 'scale(1.12)' : undefined,
        }}
      >
        {w.text}
      </span>
    )
  }

  return (
    <div
      className="pointer-events-none absolute inset-x-0 flex justify-center px-[6%]"
      style={{ top: `${style.position}%`, transform: 'translateY(-50%)' }}
    >
      <p
        key={chunk.key}
        className={`flex flex-wrap justify-center gap-x-[0.28em] text-center leading-[1.05] ${style.animation === 'none' ? '' : `anim-${style.animation}`} ${style.background ? 'rounded-md bg-black/55 px-[0.4em] py-[0.15em]' : ''}`}
        style={{
          fontFamily: style.font,
          fontSize: style.size * scale,
          fontWeight: 800,
          textTransform: style.uppercase ? 'uppercase' : 'none',
          WebkitTextStroke: outline ? `${outline}px ${style.outlineColor}` : undefined,
          paintOrder: 'stroke fill',
          textShadow: textShadow || undefined,
        }}
      >
        {chunk.words.map(render)}
      </p>
    </div>
  )
}
