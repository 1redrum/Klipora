import { cn } from '@/lib/utils'
import type { AspectRatio } from '@/lib/types'

export const ASPECT_CLASS: Record<AspectRatio, string> = {
  '9:16': 'aspect-[9/16]',
  '16:9': 'aspect-video',
  '1:1': 'aspect-square',
  '4:5': 'aspect-[4/5]',
}

/** Placeholder frame until real FFmpeg thumbnails are served. */
export function Poster({ hue, className, children }: { hue: number; className?: string; children?: React.ReactNode }) {
  return (
    <div
      className={cn('relative overflow-hidden rounded-lg', className)}
      style={{
        background: `radial-gradient(120% 80% at 30% 20%, oklch(0.55 0.16 ${hue}) 0%, oklch(0.28 0.08 ${hue + 30}) 55%, oklch(0.16 0.03 ${hue + 60}) 100%)`,
      }}
    >
      <div
        className="absolute inset-0 opacity-25 mix-blend-overlay"
        style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent 0 3px, rgba(255,255,255,.25) 3px 4px)' }}
        aria-hidden
      />
      {children}
    </div>
  )
}
