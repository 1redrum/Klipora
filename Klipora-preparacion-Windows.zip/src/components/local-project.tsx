import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { CATEGORY_LABEL } from "@/lib/analysis/content";
import type { LocalMoment } from "@/lib/local";
import { formatTimecode } from "@/lib/format";
import { localApi, localRequest, type LocalProject } from "@/lib/local";

export function LocalProjectPage({ id }: { id: string }) {
  const [project, setProject] = useState<LocalProject>();
  const [loadError, setLoadError] = useState("");
  const [actionError, setActionError] = useState("");
  const [sending, setSending] = useState(false);
  const path = "/" + id;
  const navigate = useNavigate();

  useEffect(() => {
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout>;
    async function refresh() {
      try {
        const data = await localRequest<LocalProject>(path, {
          signal: controller.signal,
        });
        if (!controller.signal.aborted) {
          setProject(data);
          setLoadError("");
        }
      } catch (error) {
        if (!controller.signal.aborted) setLoadError((error as Error).message);
      } finally {
        if (!controller.signal.aborted) timer = setTimeout(refresh, 2000);
      }
    }
    void refresh();
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [path]);

  async function mutate(action: string) {
    setSending(true);
    setActionError("");
    try {
      setProject(
        await localRequest<LocalProject>(path + action, {
          method: "POST",
          headers: { "x-klipora-local": "1" },
        }),
      );
    } catch (error) {
      setActionError((error as Error).message);
    } finally {
      setSending(false);
    }
  }

  async function removeProject() {
    if (
      !window.confirm("¿Eliminar el proyecto, el original y todos sus clips?")
    )
      return;
    setSending(true);
    setActionError("");
    try {
      await localRequest(path, {
        method: "DELETE",
        headers: { "x-klipora-local": "1" },
      });
      await navigate({ to: "/app" });
    } catch (error) {
      setActionError((error as Error).message);
    } finally {
      setSending(false);
    }
  }

  function submitCut(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    const params = new URLSearchParams();
    for (const key of ["start", "end", "resolution"])
      params.set(key, String(values.get(key)));
    void mutate("/cut?" + params);
  }

  const busy = project?.status === "processing" || project?.status === "queued";

  return (
    <div className="space-y-6">
      <Link to="/app" className="text-sm text-muted-foreground hover:underline">
        ← Proyectos
      </Link>
      {loadError && (
        <p role="alert" className="text-destructive">
          {loadError}
        </p>
      )}
      {!project && !loadError && <p role="status">Cargando proyecto…</p>}
      {project && (
        <>
          <header>
            <h1 className="break-words text-3xl font-extrabold">
              {project.title}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {project.aspect} ·{" "}
              {project.duration
                ? formatTimecode(project.duration)
                : "Determinando duración"}
            </p>
            {!busy && (
              <Button
                variant="outline"
                size="sm"
                className="mt-3"
                disabled={sending}
                onClick={() => void removeProject()}
              >
                Eliminar proyecto
              </Button>
            )}
          </header>
          <section className="space-y-3 rounded-xl border border-border bg-card p-5">
            <p role="status">{project.phase}</p>
            {project.devices && (
              <dl className="grid gap-x-3 gap-y-1 text-sm text-muted-foreground sm:grid-cols-[max-content_1fr]">
                {Object.entries(project.devices).map(([stage, detail]) => (
                  <div key={stage} className="contents">
                    <dt className="font-medium">
                      {deviceNames[stage as keyof typeof deviceNames]}
                    </dt>
                    <dd>{detail}</dd>
                  </div>
                ))}
              </dl>
            )}
            {project.classification && (
              <div className="text-sm text-muted-foreground">
                <p>
                  {project.classification.engine === "gaming"
                    ? "Gaming y streaming"
                    : "Contenido general"}{" "}
                  · {CATEGORY_LABEL[project.classification.category]}
                </p>
                {project.classification.evidence.map((reason) => (
                  <p key={reason}>{reason}</p>
                ))}
                {project.evaluated !== undefined && (
                  <p>{project.evaluated} candidatos evaluados</p>
                )}
              </div>
            )}
            {busy && (
              <Progress
                aria-label="Progreso de la etapa"
                value={project.progress}
              />
            )}
            {project.error && (
              <>
                <p
                  role="alert"
                  className="whitespace-pre-wrap break-words text-sm text-destructive"
                >
                  {project.error}
                </p>
                <Button
                  variant="outline"
                  disabled={sending}
                  onClick={() => void mutate("/retry")}
                >
                  Reintentar
                </Button>
              </>
            )}
            {actionError && (
              <p role="alert" className="text-sm text-destructive">
                {actionError}
              </p>
            )}
          </section>
          {project.status === "completed" && (
            <form
              onSubmit={submitCut}
              className="space-y-3 rounded-xl border border-border bg-card p-5"
            >
              <h2 className="font-semibold">Exportar corte manual</h2>
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <Label htmlFor="cut-start">Inicio (s)</Label>
                  <Input
                    id="cut-start"
                    name="start"
                    type="number"
                    step="any"
                    min={0}
                    max={project.duration}
                    defaultValue={0}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="cut-end">Fin (s)</Label>
                  <Input
                    id="cut-end"
                    name="end"
                    type="number"
                    step="any"
                    min={0}
                    max={project.duration}
                    defaultValue={Math.min(30, project.duration)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="cut-resolution">Resolución</Label>
                  <select
                    id="cut-resolution"
                    name="resolution"
                    className="h-9 rounded-md border border-input bg-background px-3"
                  >
                    <option>720p</option>
                    <option>1080p</option>
                  </select>
                </div>
                <Button type="submit" disabled={sending}>
                  Exportar MP4
                </Button>
              </div>
            </form>
          )}
          {project.clips.length > 0 && (
            <section className="space-y-3">
              <h2 className="text-xl font-semibold">Clips</h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {[...project.clips]
                  .sort(
                    (a, b) => (b.moment?.score ?? 0) - (a.moment?.score ?? 0),
                  )
                  .map((clip) => {
                    const src = localApi + path + "/media/" + clip.id;
                    return (
                      <article
                        key={clip.id}
                        className="space-y-2 rounded-xl border border-border bg-card p-4"
                      >
                        <video
                          className="w-full max-h-80 rounded-md bg-black"
                          controls
                          preload="none"
                          src={src}
                          aria-label={clip.title}
                        />
                        <h3 className="font-medium">{clip.title}</h3>
                        {clip.moment && <MomentDetails moment={clip.moment} />}
                        <p className="text-sm text-muted-foreground">
                          {formatTimecode(clip.start)} –{" "}
                          {formatTimecode(clip.end)} ·{" "}
                          {clip.aspect ?? project.aspect} · {clip.resolution}
                          {clip.encoder && " · " + clip.encoder}
                        </p>
                        <Button variant="outline" size="sm" asChild>
                          <Link
                            to="/app/projects/$projectId/clips/$clipId"
                            params={{ projectId: id, clipId: clip.id }}
                          >
                            Editar clip
                          </Link>
                        </Button>
                        <Button variant="outline" size="sm" asChild>
                          <a href={src} download={clip.id + ".mp4"}>
                            Descargar MP4
                          </a>
                        </Button>
                        {project.status === "completed" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            disabled={sending}
                            onClick={() => void mutate("/variant/" + clip.id)}
                          >
                            Exportar en{" "}
                            {clip.resolution === "720p" ? "1080p" : "720p"}
                          </Button>
                        )}
                      </article>
                    );
                  })}
              </div>
            </section>
          )}
          {!project.clips.length && project.status === "completed" && (
            <p className="text-sm text-muted-foreground">
              Aún no hay clips. Puedes elegir un corte manual.
            </p>
          )}
        </>
      )}
    </div>
  );
}

function MomentDetails({ moment }: { moment: LocalMoment }) {
  const labels = [
    ["Interés", moment.breakdown.interest],
    ["Entretenimiento", moment.breakdown.entertainment],
    ["Intensidad", moment.breakdown.emotion],
    ["Contexto", moment.breakdown.context],
    ["Impacto", moment.breakdown.impact],
    ["Gancho", moment.breakdown.hook],
  ];
  return (
    <div className="space-y-2 text-sm">
      <p>
        <strong className="text-primary">{moment.score}/100</strong> · Potencial
        estimado
      </p>
      <div>
        <p className="font-medium">Motivo registrado</p>
        <p>{moment.reason}</p>
      </div>
      <details className="text-muted-foreground">
        <summary className="cursor-pointer">Puntuación y evidencia</summary>
        <dl className="my-2 grid grid-cols-2 gap-1">
          {labels.map(([label, score]) => (
            <div key={label}>
              <dt className="inline">{label} </dt>
              <dd className="inline">{score}/100</dd>
            </div>
          ))}
        </dl>
        <ul className="list-disc space-y-1 pl-4">
          {moment.evidence.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </details>
    </div>
  );
}

const deviceNames = {
  whisper: "Transcripción",
  vision: "Visión",
  llm: "Análisis semántico",
  encoder: "Exportación",
  ocr: "OCR",
  audio: "Análisis de audio",
};
