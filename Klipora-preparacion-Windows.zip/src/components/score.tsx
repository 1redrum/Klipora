import { cn } from '@/lib/utils'
import { scoreTone } from '@/lib/format'
import type { ScoreBreakdown } from '@/lib/types'

const toneClass = {
  hot: 'text-hot border-hot/50 bg-hot/10',
  warm: 'text-warm border-warm/50 bg-warm/10',
  cool: 'text-cool border-cool/50 bg-cool/10',
}
const barClass = { hot: 'bg-hot', warm: 'bg-warm', cool: 'bg-cool' }

export function ScoreBadge({ score, className }: { score: number; className?: string }) {
  return (
    <span
      className={cn('inline-flex items-baseline gap-1 rounded-md border px-2 py-0.5 font-mono text-sm font-semibold', toneClass[scoreTone(score)], className)}
      title="Estimación de potencial de interés (1–100). No garantiza viralidad."
    >
      {score}
      <span className="text-[10px] font-normal opacity-70">/100</span>
    </span>
  )
}

const LABELS: Record<keyof ScoreBreakdown, string> = {
  interest: 'Interés',
  emotion: 'Intensidad emocional',
  entertainment: 'Entretenimiento',
  context: 'Claridad de contexto',
  impact: 'Impacto de frase/reacción',
  hook: 'Gancho (primeros 3 s)',
}

export function ScoreBreakdownList({ breakdown }: { breakdown: ScoreBreakdown }) {
  return (
    <dl className="grid gap-2">
      {(Object.keys(LABELS) as (keyof ScoreBreakdown)[]).map((k) => (
        <div key={k} className="grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1 text-xs">
          <dt className="text-muted-foreground">{LABELS[k]}</dt>
          <dd className="font-mono">{breakdown[k]}</dd>
          <div className="col-span-2 h-1.5 overflow-hidden rounded-full bg-muted">
            <div className={cn('h-full rounded-full', barClass[scoreTone(breakdown[k])])} style={{ width: `${breakdown[k]}%` }} />
          </div>
        </div>
      ))}
    </dl>
  )
}
