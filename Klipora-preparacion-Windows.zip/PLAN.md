# Klipora — roadmap

Klipora turns long videos (uploads or YouTube / Twitch / Kick links) into as many complete, distinct clips as the content supports with an estimated
interest score, burned-in word-level captions, smart vertical framing and H.264/AAC exports up to 1080p.

## Target architecture

| Concern                        | Choice                                                                                                                                                                                                                                                                                                                                      |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Web app + public API           | TanStack Start on Netlify (React, TypeScript, Tailwind). API lives in `src/routes/api.*.ts` server routes.                                                                                                                                                                                                                                  |
| Auth + per-user isolation      | Netlify Identity; every project/clip row carries `user_id`, every API route checks it.                                                                                                                                                                                                                                                      |
| Relational data                | Netlify Database (Postgres + Drizzle): users' projects, sources, jobs, stage progress, clips, captions, edits.                                                                                                                                                                                                                              |
| Media storage                  | Netlify Blobs for persistent originals, proxies, audio, renders and ZIPs. Design chunked transfers around actual platform request/storage constraints; never buffer whole multi-hour videos in a request.                                                                                                                                   |
| Media worker (heavy work)      | Dedicated local media executor on the owner’s computer: FFmpeg, faster-whisper, local language and vision models. CPU support is required; use compatible GPU and hardware encoders when available. It pulls durable jobs from the Netlify API; it does not expose a public backend. Netlify cannot execute multi-hour FFmpeg/Whisper jobs. |
| Job orchestration              | API stores jobs and stage checkpoints in Postgres. The local executor claims jobs with renewable leases and reports progress through an authenticated Netlify API. Lease expiry makes interrupted jobs recoverable; browser lifetime never owns a job. Resource-based parallelism is configurable, with no commercial priority or cooldown. |
| LLM analysis, titles, hashtags | Local open-weight model through a `MomentAnalyzer` / `CopyWriter` interface (evaluate llama.cpp / Ollama). No paid API key is required. Any remote model is strictly optional and never blocks local processing.                                                                                                                            |
| Cleanup                        | Retain originals, projects and results until explicit deletion by the owner. Clean only disposable intermediate artefacts after verifying durable outputs/checkpoints; never remove recovery data from active or interrupted jobs.                                                                                                          |

Model choices sit behind interfaces (`Transcriber`, `MomentDetector`, `Framer`, `Renderer`) so any one can be replaced without
touching the rest.

## Milestones

1. **Product surface — done.** Landing page, project history, new-project import (real URL detection/validation, real drag-and-drop
   file checks for format/size/duration/corruption, local preview), processing view with the 9 pipeline stages and error/retry state,
   results dashboard (score, breakdown, title, description, hashtags, platform, favorites, delete/undo), and the clip editor (trim,
   caption text/timing/emphasis editing, 5 caption presets with full styling, aspect, framing modes with local-file preview,
   volume/mute, custom text, saved edits). Sample data lives only in `src/lib/fixtures.ts`.
   **Adaptive detection — contract done.** Content-type selector on import (automatic / general / gaming), two specialised engines
   (Motor A general, Motor B gaming) with their own signals, weights and boundary rules, an evidence-based classifier, per-engine
   LLM prompts + response schemas, and the selection pass that rejects intensity-only, context-free, incomplete, repeated and
   too-similar moments and requires a reason per clip. All in `src/lib/analysis/` (unit-tested); the UI shows the engine, the
   classification evidence, rejected-candidate counts and each clip's moment type, reason and signals. The worker must feed
   `classifyContent` (stage "analyzing") and `selectMoments` (stage "detecting") — never one algorithm for every video.
2. **Accounts & data model.** Netlify Identity login/signup, protected `/app/*`. Drizzle schema: `projects`, `sources`, `jobs`,
   `job_stages`, `clips`, `caption_segments`, `clip_edits`. Projects API (list/get/delete) replacing fixtures.
3. **Uploads.** Netlify Blobs chunked uploads with progress, cancel and resume; server-side type/integrity checks; actual storage failures explained without arbitrary duration/size caps; upload-complete endpoint that creates a durable job.
4. **Worker foundation.** local Python media executor, authenticated polling/claims and worker → Netlify API callbacks for stage progress
   and errors, renewable leases and retry from the failed stage keeping completed artefacts. FFmpeg probe/normalize (MKV/AVI/FLV → mezzanine MP4,
   audio extraction, proxy for the editor).
5. **URL import.** Platform-specific metadata (YouTube Data API, Twitch Helix, Kick public endpoints) for title/thumbnail/duration;
   download via a pluggable extractor chain (official APIs where possible, `yt-dlp` as fallback) respecting each platform's terms;
   clear errors for private/unavailable/blocked videos with a "upload the original" fallback.
6. **Transcription.** local faster-whisper (large-v3 when resources allow, configurable model) with word timestamps + language detection (ES/EN minimum), VAD-based chunking for
   long videos, stored per word.
7. **Moment detection & scoring** (implements the `src/lib/analysis/` contract: classify first, then the chosen engine). Audio energy/pitch peaks, silences, laughter/shout detection, scene changes, chat-free signal
   fusion; LLM pass over transcript windows with surrounding context; boundaries snapped to sentence/word edges; 1–100 score with the
   six-factor breakdown and a reason. Evaluation set of real videos to tune thresholds.
8. **Clip rendering.** Frame-accurate FFmpeg cuts (re-encode, no A/V drift), H.264 (CRF/bitrate per resolution) + AAC, original FPS,
   720p/1080p, 9:16 / 16:9 / 1:1 / 4:5. Framing: face tracking, subject tracking, blur fill, streamer cam + gameplay split, manual crop.
9. **Burned-in captions.** Generate ASS subtitles from the editor's style config (font, size, colors, outline, shadow, position,
   words per line, karaoke `\k` timings, entry animations) and burn them in during render.
10. **Editor ↔ render.** Persist edits to the DB, re-render a single clip, "regenerate" a clip, real preview from the proxy video.
11. **Results delivery.** Individual MP4 downloads (presigned URLs), ZIP of all clips, AI titles/descriptions/hashtags/hooks/posting
    tips grounded in the clip transcript.
12. **Operations.** Explicit deletion and safe temporary-file cleanup, resource monitoring, recoverable jobs and hardware-aware parallelism. No quotas, commercial limits or cooldowns. Technical backpressure must explain the exhausted resource and preserve queued work.

## Personal-use requirements (applies to every milestone)

No subscriptions, plans, credits, advertisements, mandatory watermarks, paid resolutions, project/clip/minute quotas or processing cooldowns. Both 720p and 1080p use the same access rules. Do not promise virality: scores estimate interest.

The app imposes no file-size or video-duration cap. Validate actual integrity, available storage and codec support; browser codec failure requires local FFmpeg probing rather than rejection. Clip count is automatic and uncapped; retain narrative quality and deduplication criteria without per-category quotas. Target duration is an editing preference, not a processing entitlement.

Use segmented reads, VAD/transcript windows and bounded decoder/model batches so memory use does not scale with source duration. Store stage progress and artefact references durably. After restart, validate existing artefacts and resume the incomplete stage; do not repeat completed stages unnecessarily. Keep multiple jobs durable while active parallelism follows available RAM, GPU memory and disk space.

Local model inference does not require per-request API payments. Hosting and storage still have real provider capacities and potential infrastructure costs; do not present Netlify or any external infrastructure as unlimited or guaranteed free.

## Current implementation boundary

The personal workflow now uses a loopback Vite API and filesystem-backed jobs rather than hosted Identity, Database, or Blobs. It can import originals, retry jobs, resume completed transcription windows, and export manual or transcript-based clips in both resolutions. The hosted milestones above describe the original architecture. The local roadmap still includes resumable browser uploads, broader visual event recognition and tracking, persistent editing, and bulk export. Semantic selection now runs against a local language model, with Whisper transcripts and gaming OCR/audio cues. See [semantic analysis](docs/semantic-analysis.md) for the validation status. See [local setup](docs/local-processing.md).

Phase 3 adds local vision observations, evidence-grounded editorial boundaries, and tracked layouts. See [visual analysis and validation](docs/visual-analysis.md).

Phase 4 connects the clip editor to filesystem-backed drafts, bounded FFmpeg previews, and persistent exports. See [clip editor](docs/clip-editor.md).

Phase 5 validates stability and recovery on Linux CPU. Windows 10/11 and physical GPU verification are tracked in [stability](docs/stability.md).
