import process from "node:process";
import { writeFile } from "node:fs/promises";
import { clearTimeout, setTimeout } from "node:timers";
import { spawn } from "node:child_process";
import { join } from "node:path";

// The IPC pipe is owned by the server. Its closure also reaches this process after a hard kill.
const [command, ...args] = process.argv.slice(2);
const child = spawn(command, args, {
  windowsHide: true,
  stdio: ["inherit", "inherit", "inherit"],
});
let finished = false;
let terminating = false;
let orphaned = false;
let escalation;
child.once("error", (error) => {
  if (process.connected)
    process.send({ code: error.code, message: error.message });
});
child.once("close", async (code) => {
  finished = true;
  clearTimeout(escalation);
  process.exitCode = code ?? 1;
  if (orphaned && process.env.KLIPORA_ORPHAN_RENDER_DIR) {
    // The encoder owns this private directory and is already closed.
    await writeFile(
      join(process.env.KLIPORA_ORPHAN_RENDER_DIR, ".encoder-closed"),
      "closed",
      { flag: "wx" },
    ).catch(() => {});
  }
  if (process.connected) process.disconnect();
});

function stopTree() {
  if (finished || terminating || !child.pid) return;
  terminating = true;
  if (process.platform === "win32") {
    const taskkill = join(
      process.env.SystemRoot || "C:\\Windows",
      "System32",
      "taskkill.exe",
    );
    const stop = spawn(taskkill, ["/PID", String(child.pid), "/T", "/F"], {
      windowsHide: true,
      stdio: "ignore",
    });
    stop.once("error", () => child.kill());
    stop.once("exit", (code) => {
      if (code !== 0) child.kill();
    });
  } else {
    process.kill(-process.pid, "SIGTERM");
    escalation = setTimeout(() => process.kill(-process.pid, "SIGKILL"), 1200);
    escalation.unref();
  }
}

process.once("disconnect", () => {
  orphaned = !finished;
  stopTree();
});
process.on("SIGTERM", stopTree);
