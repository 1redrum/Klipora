import type { ClipDraft } from "../src/lib/editor-draft.ts";

const centiseconds = (seconds: number) =>
  Math.max(0, Math.round(seconds * 100));

function stamp(value: number) {
  const rest = Math.floor(value / 100);
  return `${Math.floor(rest / 3600)}:${String(Math.floor(rest / 60) % 60).padStart(2, "0")}:${String(rest % 60).padStart(2, "0")}.${String(value % 100).padStart(2, "0")}`;
}

function channels(css: string) {
  const rgb = css.slice(1, 7).match(/../g)!.reverse().join("");
  const opacity = css.length === 9 ? Number.parseInt(css.slice(7), 16) : 255;
  return { rgb, alpha: (255 - opacity).toString(16).padStart(2, "0") };
}

function assColor(css: string) {
  const { rgb, alpha } = channels(css);
  return `&H${alpha}${rgb.toUpperCase()}`;
}

function fill(css: string) {
  const { rgb, alpha } = channels(css);
  return `\\1c&H${rgb}&\\1a&H${alpha}&`;
}

function safeText(value: string) {
  // Fullwidth marks leave user text visible without treating it as ASS syntax.
  return value
    .replaceAll("\\", "＼")
    .replaceAll("{", "｛")
    .replaceAll("}", "｝")
    .replace(/\r\n?|\n/g, "\\N");
}

export function makeAss(
  edit: ClipDraft,
  from: number,
  to: number,
  width: number,
  height: number,
) {
  const { style } = edit;
  const scale = Math.min(width, height) / 720;
  const dim = (value: number) => Math.round(value * scale * 100) / 100;
  const left = Math.round(width * 0.06);
  const lines = [
    "[Script Info]",
    "ScriptType: v4.00+",
    `PlayResX: ${width}`,
    `PlayResY: ${height}`,
    "WrapStyle: 0",
    "ScaledBorderAndShadow: yes",
    "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    `Style: Caption,${style.font},${dim(style.size)},${assColor(style.color)},${assColor(style.highlight)},${assColor(style.outlineColor)},&H60000000,-1,0,0,0,100,100,0,0,1,${dim(style.outline)},${dim(style.shadow)},5,${left},${left},0,1`,
    `Style: Background,${style.font},${dim(style.size)},&HFF000000,&HFF000000,&H70000000,&HFF000000,-1,0,0,0,100,100,0,0,3,${dim(7)},0,5,${left},${left},0,1`,
    `Style: Text,Inter,${dim(36)},&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,${dim(2)},${dim(2)},5,${left},${left},0,1`,
    "",
    "[Events]",
    "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
  ];
  function event(
    layer: number,
    name: string,
    start: number,
    end: number,
    text: string,
  ) {
    const a = centiseconds(start - from);
    const b = centiseconds(end - from);
    if (b > a)
      lines.push(
        `Dialogue: ${layer},${stamp(a)},${stamp(b)},${name},,0,0,0,,${text}`,
      );
  }
  if (edit.captions) {
    const words = edit.words
      .filter(
        (word) =>
          word.text.trim() && word.end > edit.start && word.start < edit.end,
      )
      .sort((a, b) => a.start - b.start || a.end - b.end);
    for (let index = 0; index < words.length;) {
      const group = [words[index++]];
      while (
        index < words.length &&
        group.length < style.wordsPerLine &&
        words[index].start - group.at(-1)!.end <= 0.65
      ) {
        group.push(words[index++]);
      }
      const originalStart = Math.max(edit.start, group[0].start);
      const start = Math.max(from, originalStart);
      const end = Math.min(
        to,
        edit.end,
        Math.max(...group.map((word) => word.end)) + 0.12,
        words[index]?.start ?? Infinity,
      );
      if (end <= start) continue;
      const x = Math.round(width / 2);
      const y = Math.round((height * style.position) / 100);
      const startMs = Math.round((start - originalStart) * 1000);
      const remaining = Math.max(0, 140 - startMs);
      const pos =
        style.animation === "slide" && remaining > 0
          ? `\\move(${x},${y + Math.round((dim(18) * remaining) / 140)},${x},${y},0,${remaining})`
          : `\\pos(${x},${y})`;
      let motion = "";
      if (remaining > 0 && style.animation === "fade")
        motion = `\\fad(${remaining},0)`;
      if (remaining > 0 && style.animation === "pop") {
        const size = Math.round(100 - (18 * remaining) / 140);
        motion = `\\fscx${size}\\fscy${size}\\t(0,${remaining},\\fscx100\\fscy100)`;
      }
      const textOf = (word: (typeof group)[number]) =>
        safeText(
          style.uppercase ? word.text.trim().toUpperCase() : word.text.trim(),
        );
      if (style.background)
        event(
          0,
          "Background",
          start,
          end,
          `{${pos}${motion}}${group.map(textOf).join(" ")}`,
        );
      const colored = group.map((word) => {
        const emphasize =
          word.emphasis ||
          (!style.emphasisOnly &&
            start >= word.start &&
            (style.karaoke || start < word.end));
        let tags = fill(emphasize ? style.highlight : style.color);
        if (!word.emphasis && !style.emphasisOnly) {
          for (const [point, css] of [
            [word.start, style.highlight],
            ...(style.karaoke ? [] : [[word.end, style.color]]),
          ] as [number, string][]) {
            const t = Math.round((point - start) * 1000);
            if (t > 0 && point < end)
              tags += `\\t(${t},${t + 10},${fill(css)})`;
          }
        }
        return `{${tags}}${textOf(word)}`;
      });
      event(1, "Caption", start, end, `{${pos}${motion}}${colored.join(" ")}`);
    }
  }
  for (const text of edit.overlays) {
    const start = Math.max(from, edit.start, text.start);
    const end = Math.min(to, edit.end, text.end);
    if (end > start && text.text.trim()) {
      event(
        2,
        "Text",
        start,
        end,
        `{\\an5\\pos(${Math.round((width * text.x) / 100)},${Math.round((height * text.y) / 100)})\\fs${dim(text.size)}${fill(text.color)}}${safeText(text.text)}`,
      );
    }
  }
  return lines.length > 15 ? lines.join("\n") + "\n" : undefined;
}
