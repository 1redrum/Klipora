import { AsyncLocalStorage } from "node:async_hooks";
import {
  spawn,
  type ChildProcess,
  type ChildProcessWithoutNullStreams,
  type SpawnOptionsWithoutStdio,
} from "node:child_process";
import { join } from "node:path";

export type ProcessDevice =
  "whisper" | "vision" | "llm" | "encoder" | "ocr" | "audio";
type LocalOptions = SpawnOptionsWithoutStdio & { orphanRenderDir?: string };
type Scope = {
  signal: AbortSignal;
  report?: (stage: ProcessDevice, detail: string) => void;
};
const context = new AsyncLocalStorage<Scope>();
const completion = new WeakMap<ChildProcess, Promise<void>>();

export const runLocal = <T>(scope: Scope, run: () => T): T =>
  context.run(scope, run);
export const localSignal = () => context.getStore()?.signal;
export function reportDevice(stage: ProcessDevice, detail: string) {
  context.getStore()?.report?.(stage, detail);
}

export const pythonCommand =
  process.env.KLIPORA_PYTHON ||
  (process.platform === "win32" ? "python" : "python3");

function terminate(child: ChildProcess) {
  if (!child.pid || child.exitCode !== null || child.signalCode !== null)
    return;
  if (process.platform === "win32") {
    // All PIDs come from our own immediate children. /T also stops FFmpeg started by Python.
    const image = join(
      process.env.SystemRoot || "C:\\Windows",
      "System32",
      "taskkill.exe",
    );
    const kill = spawn(image, ["/PID", String(child.pid), "/T", "/F"], {
      windowsHide: true,
      stdio: "ignore",
    });
    kill.once("error", () => child.kill());
    kill.once("exit", (code) => {
      if (code !== 0) child.kill();
    });
    return;
  }
  const signalGroup = (signal: NodeJS.Signals) => {
    try {
      process.kill(-child.pid!, signal);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ESRCH") child.kill(signal);
    }
  };
  signalGroup("SIGTERM");
  const timer = setTimeout(() => signalGroup("SIGKILL"), 1500);
  timer.unref();
  child.once("close", () => clearTimeout(timer));
}

export function spawnLocal(
  command: string,
  args: string[],
  options: LocalOptions = {},
) {
  const signal = localSignal();
  signal?.throwIfAborted();
  const guard = join(process.cwd(), "local", "child-guard.mjs");
  const { orphanRenderDir, ...spawnOptions } = options;
  const child = spawn(process.execPath, [guard, command, ...args], {
    ...spawnOptions,
    env: {
      ...process.env,
      ...options.env,
      KLIPORA_ORPHAN_RENDER_DIR: orphanRenderDir ?? "",
      ...(command === pythonCommand
        ? { PYTHONUTF8: "1", PYTHONIOENCODING: "utf-8" }
        : {}),
    },
    stdio: ["pipe", "pipe", "pipe", "ipc"],
    detached: process.platform !== "win32",
    windowsHide: true,
  }) as ChildProcessWithoutNullStreams;
  child.on("message", (data) => {
    if (
      data &&
      typeof data === "object" &&
      "message" in data &&
      typeof data.message === "string"
    ) {
      child.emit(
        "error",
        Object.assign(new Error(data.message), {
          code: "code" in data ? data.code : undefined,
        }),
      );
    }
  });
  const stop = () => terminate(child);
  signal?.addEventListener("abort", stop, { once: true });
  completion.set(
    child,
    new Promise((resolve) => {
      child.once("close", () => {
        signal?.removeEventListener("abort", stop);
        resolve();
      });
    }),
  );
  return child;
}

export async function closeLocal(child: ChildProcess) {
  const timer = setTimeout(() => terminate(child), 1200);
  timer.unref();
  child.stdin?.end();
  try {
    await completion.get(child);
  } finally {
    clearTimeout(timer);
  }
}

export function execLocal(
  command: string,
  args: string[],
  options: LocalOptions = {},
) {
  const signal = localSignal();
  return new Promise<{ stdout: string; stderr: string }>((resolve, reject) => {
    const child = spawnLocal(command, args, options);
    child.stdin.on("error", () => {});
    child.stdin.end();
    const chunks: Buffer[] = [];
    let stdoutSize = 0;
    let stderr = "";
    let failure: Error | undefined;
    child.once("error", (error) => {
      failure = error;
    });
    child.stdout.on("data", (data: Buffer) => {
      stdoutSize += data.length;
      if (stdoutSize <= 8 * 1024 * 1024) chunks.push(data);
      else if (!failure) {
        failure = new Error(
          `${command} produjo demasiados datos de diagnóstico.`,
        );
        terminate(child);
      }
    });
    child.stderr.setEncoding("utf8").on("data", (data: string) => {
      stderr = (stderr + data).slice(-12_000);
    });
    child.once("close", (code) => {
      if (signal?.aborted) return reject(signal.reason);
      if (failure) return reject(failure);
      if (code !== 0)
        return reject(
          new Error(
            `${command} terminó con código ${code ?? "de señal"}.${stderr ? "\n" + stderr.trim() : ""}`,
          ),
        );
      resolve({ stdout: Buffer.concat(chunks).toString("utf8"), stderr });
    });
  });
}
