"""Read bounded, uniformly sampled frames from FFmpeg and emit normalized observations."""
import json
import os
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

WIDTH, HEIGHT, FPS = 384, 216, 8
cv2.setNumThreads(1)
source, start, end = sys.argv[1:]
start, end = float(start), float(end)
model = Path(__file__).parent / "models" / "face_detection_yunet_2023mar.onnx"
backend, target = cv2.dnn.DNN_BACKEND_OPENCV, cv2.dnn.DNN_TARGET_CPU
requested = os.environ.get("KLIPORA_VISION_DEVICE", "auto")

def make_detector(selected):
    return cv2.FaceDetectorYN.create(str(model), "", (WIDTH, HEIGHT), .78, .3, 40, backend, selected)

try:
    if requested != "cpu" and cv2.ocl.haveOpenCL():
        cv2.ocl.setUseOpenCL(True)
        if cv2.ocl.useOpenCL() and (cv2.ocl.Device_getDefault().type() & cv2.ocl.Device_TYPE_GPU):
            target = cv2.dnn.DNN_TARGET_OPENCL_FP16
    detector = make_detector(target)
except (AttributeError, cv2.error):
    target = cv2.dnn.DNN_TARGET_CPU
    detector = make_detector(target)
process = subprocess.Popen([
    "ffmpeg", "-nostdin", "-loglevel", "error", "-ss", str(start), "-i", source,
    "-t", str(end - start), "-an", "-filter_threads", "1", "-vf",
    f"fps={FPS}:start_time=0,scale={WIDTH}:{HEIGHT}", "-pix_fmt", "bgr24",
    "-threads", "1", "-f", "rawvideo", "pipe:1"
], stdout=subprocess.PIPE)

previous = None
previous_faces = []
samples = []
try:
    while raw := process.stdout.read(WIDTH * HEIGHT * 3):
        if len(raw) != WIDTH * HEIGHT * 3:
            raise RuntimeError("FFmpeg entregó un fotograma incompleto.")
        frame = np.frombuffer(raw, dtype=np.uint8).reshape(HEIGHT, WIDTH, 3)
        gray = cv2.GaussianBlur(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        motion, scene = 0., False
        center = [.5, .5]
        if previous is not None:
            diff = cv2.absdiff(previous, gray)
            motion = float(np.mean(diff) / 255)
            scene = motion > .20 and float(np.mean(diff > 45)) > .48
            if not scene:
                # Exclude the outside border where scoreboards and channel bugs often sit.
                roi = diff[12:-12, 20:-20]
                mask = np.uint8(roi >= max(18, np.percentile(roi, 88))) * 255
                count, _, stats, centroids = cv2.connectedComponentsWithStats(mask)
                if count > 1:
                    candidate = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
                    if stats[candidate, cv2.CC_STAT_AREA] >= 22:
                        x, y = centroids[candidate]
                        center = [(x + 20) / WIDTH, (y + 12) / HEIGHT]
        try:
            _, detections = detector.detect(frame)
        except cv2.error:
            if target == cv2.dnn.DNN_TARGET_CPU:
                raise
            target = cv2.dnn.DNN_TARGET_CPU
            detector = make_detector(target)
            _, detections = detector.detect(frame)
        faces, patches = [], []
        for detection in detections if detections is not None else []:
            x, y, w, h = map(float, detection[:4])
            if w < 14 or h < 14:
                continue
            cx, cy = (x + w / 2) / WIDTH, (y + h / 2) / HEIGHT
            # Compare aligned mouth patches against the same nearby face in the prior sample.
            mx, my = (detection[10] + detection[12]) / 2, (detection[11] + detection[13]) / 2
            patch = gray[max(0, int(my - h * .14)):min(HEIGHT, int(my + h * .14)),
                         max(0, int(mx - w * .22)):min(WIDTH, int(mx + w * .22))]
            activity = 0.
            if patch.size:
                patch = cv2.resize(patch, (24, 12)).astype(np.float32)
                patch -= patch.mean()
                matches = sorted(previous_faces, key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)
                if matches and not scene and abs(matches[0][0] - cx) + abs(matches[0][1] - cy) < .11:
                    activity = float(np.mean(np.abs(patch - matches[0][2])) / 45)
                patches.append((cx, cy, patch))
            faces.append([round(cx, 4), round(cy, 4), round(w / WIDTH, 4), round(h / HEIGHT, 4), round(min(activity, 1), 3)])
        samples.append({
            "t": round(start + len(samples) / FPS, 3), "faces": faces,
            "focus": [round(float(value), 4) for value in center],
            "motion": round(motion, 4), "scene": scene,
        })
        previous, previous_faces = gray, patches
    if process.wait() != 0:
        raise RuntimeError("Falló la decodificación visual de FFmpeg.")
    device = "OpenCL solicitado (OpenCV puede usar CPU)" if target != cv2.dnn.DNN_TARGET_CPU else "CPU · YuNet"
    print("KLIPORA_VISION_DEVICE=" + device, file=sys.stderr)
    print(json.dumps(samples, separators=(",", ":")))
finally:
    if process.poll() is None:
        process.kill()
        process.wait()
