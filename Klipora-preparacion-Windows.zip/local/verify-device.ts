import { copyFile, mkdtemp, rm } from "node:fs/promises";
import { arch, cpus, platform, release, tmpdir } from "node:os";
import { basename, join, resolve } from "node:path";
import { probe, render, transcript, type TimedWord } from "./media.ts";
import { execLocal, pythonCommand, runLocal } from "./processes.ts";

const input = process.argv[2];
if (!input) {
  console.error(
    "Uso: node --experimental-strip-types local/verify-device.ts <video-con-voz>",
  );
  process.exit(2);
}

const controller = new AbortController();
process.once("SIGINT", () =>
  controller.abort(new Error("Prueba interrumpida")),
);
const devices: Record<string, string> = {};
const report: Record<string, unknown> = {
  system: {
    platform: platform(),
    release: release(),
    arch: arch(),
    node: process.version,
    cpu: cpus()[0]?.model,
  },
  input: basename(input),
  devices,
  checks: {},
};
const checks = report.checks as Record<string, unknown>;
const dir = await mkdtemp(join(tmpdir(), "klipora-validación-"));

try {
  await runLocal(
    {
      signal: controller.signal,
      report: (stage, device) => {
        devices[stage] = device;
      },
    },
    async () => {
      async function check<T>(name: string, execute: () => Promise<T>) {
        try {
          const value = await execute();
          checks[name] = { status: "ok", value };
          return value;
        } catch (error) {
          checks[name] = {
            status: "error",
            message: error instanceof Error ? error.message : String(error),
          };
        }
      }
      if (platform() === "win32") {
        await check("Windows y adaptadores detectados", async () =>
          JSON.parse(
            (
              await execLocal("powershell.exe", [
                "-NoProfile",
                "-Command",
                "[Console]::OutputEncoding=[Text.Encoding]::UTF8; [ordered]@{ os=(Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber); gpu=@(Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion) } | ConvertTo-Json -Depth 4 -Compress",
              ])
            ).stdout,
          ),
        );
      }
      await check(
        "FFmpeg",
        async () =>
          (await execLocal("ffmpeg", ["-version"])).stdout.split("\n")[0],
      );
      await check("NVENC presente en la compilación", async () =>
        /\bh264_nvenc\b/.test(
          (await execLocal("ffmpeg", ["-hide_banner", "-encoders"])).stdout,
        ),
      );
      await check("Python y bibliotecas", async () =>
        JSON.parse(
          (
            await execLocal(pythonCommand, [
              "-c",
              "import sys,json,cv2,ctranslate2,importlib.metadata as m; print(json.dumps(dict(python=sys.version.split()[0],opencv=cv2.__version__,ctranslate2=ctranslate2.__version__,whisper=m.version('faster-whisper'),cuda_devices=ctranslate2.get_cuda_device_count())))",
            ])
          ).stdout,
        ),
      );
      const source = "original";
      const metadata = await check(
        "Copia y lectura en ruta acentuada",
        async () => {
          await copyFile(resolve(input), join(dir, source));
          return probe(dir, source);
        },
      );
      if (!metadata) throw new Error("No se pudo preparar el video de prueba.");
      const end = Math.min(metadata.duration, 15);
      const words: TimedWord[] = [];
      await check("Whisper real", async () => {
        if (!metadata.audio)
          throw new Error("El archivo no tiene pista de audio.");
        for await (const word of transcript(
          dir,
          source,
          end,
          "auto",
          async () => {},
        ))
          words.push(word);
        if (!words.length)
          throw new Error(
            "Whisper no encontró palabras en los primeros 15 segundos.",
          );
        return { words: words.length, device: devices.whisper };
      });
      for (const resolution of ["720p", "1080p"]) {
        await check("Exportación real " + resolution, async () => {
          const device = await render(
            dir,
            source,
            { start: 0, end, title: "Diagnóstico", words },
            resolution,
            "9:16",
            resolution,
            "manual",
            metadata.duration,
          );
          const { stdout } = await execLocal(
            "ffprobe",
            [
              "-v",
              "error",
              "-select_streams",
              "v:0",
              "-show_entries",
              "stream=width,height",
              "-of",
              "json",
              resolution + ".mp4",
            ],
            { cwd: dir },
          );
          const [size] = (
            JSON.parse(stdout) as {
              streams: { width: number; height: number }[];
            }
          ).streams;
          const width = Number.parseInt(resolution, 10);
          if (
            size?.width !== width ||
            size?.height !== Math.round((width * 16) / 18) * 2
          ) {
            throw new Error(
              "El archivo exportado tiene dimensiones incorrectas.",
            );
          }
          return {
            device,
            ...size,
            ...(await probe(dir, resolution + ".mp4")),
          };
        });
      }
    },
  );
} catch (error) {
  report.error = error instanceof Error ? error.message : String(error);
} finally {
  await rm(dir, {
    recursive: true,
    force: true,
    maxRetries: 4,
    retryDelay: 100,
  });
  console.log(JSON.stringify(report, null, 2));
  if (
    report.error ||
    Object.values(checks).some(
      (item) => (item as { status: string }).status === "error",
    )
  )
    process.exitCode = 1;
}
