import { renameLocal as rename } from "./files.ts";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import type { Observation } from "./game-signals.ts";

import { execLocal as exec, reportDevice, pythonCommand } from "./processes.ts";
const span = 30;
type Point = [number, number];
type Face = [
  x: number,
  y: number,
  width: number,
  height: number,
  mouth: number,
];
export type VisualSample = {
  t: number;
  faces: Face[];
  focus: Point;
  motion: number;
  scene: boolean;
};

const pending = new Map<string, Promise<VisualSample[]>>();

export async function* visualSamples(
  cwd: string,
  source: string,
  start: number,
  end: number,
  duration: number,
) {
  const folder = join(cwd, "vision-v1");
  await mkdir(folder, { recursive: true });
  for (let base = Math.floor(start / span) * span; base < end; base += span) {
    const path = join(folder, base + ".json");
    let work = pending.get(path);
    if (!work) {
      const from = base;
      work = loadVision(
        path,
        cwd,
        source,
        from,
        Math.min(duration, from + span),
      ).finally(() => pending.delete(path));
      pending.set(path, work);
    }
    for (const sample of await work)
      if (sample.t >= start && sample.t < end) yield sample;
  }
}

async function loadVision(
  path: string,
  cwd: string,
  source: string,
  start: number,
  end: number,
) {
  try {
    const cached = JSON.parse(await readFile(path, "utf8")) as VisualSample[];
    const saved = await readFile(path + ".device", "utf8").catch(
      (error: NodeJS.ErrnoException) => {
        if (error.code !== "ENOENT") throw error;
        return "dispositivo sin registro";
      },
    );
    reportDevice("vision", "Caché · " + saved);
    return cached;
  } catch (error) {
    if (
      (error as NodeJS.ErrnoException).code !== "ENOENT" &&
      !(error instanceof SyntaxError)
    )
      throw error;
  }
  const { stdout, stderr } = await exec(
    pythonCommand,
    [
      join(process.cwd(), "local", "vision.py"),
      source,
      String(start),
      String(end),
    ],
    { cwd },
  );
  const samples = JSON.parse(stdout) as VisualSample[];
  const device =
    stderr.match(/KLIPORA_VISION_DEVICE=([^\r\n]+)/)?.[1] ??
    "dispositivo sin registro";
  reportDevice("vision", device);
  await writeFile(path + ".device", device);
  await writeFile(path + ".tmp", stdout);
  await rename(path + ".tmp", path);
  return samples;
}

export async function visualObservations(
  cwd: string,
  source: string,
  start: number,
  end: number,
  duration: number,
) {
  const observations: Observation[] = [];
  let lastScene = -Infinity;
  let lastMotion = -Infinity;
  let lastReaction = -Infinity;
  let previousMotion = 0;
  for await (const sample of visualSamples(cwd, source, start, end, duration)) {
    if (sample.scene && sample.t - lastScene > 1) {
      observations.push({
        kind: "scene-change",
        t: sample.t,
        strength: Math.min(1, sample.motion * 2),
        text: "Cambio de plano por diferencia global entre fotogramas",
        origin: "vision",
      });
      lastScene = sample.t;
    }
    if (
      !sample.scene &&
      sample.motion > 0.065 &&
      sample.motion > previousMotion * 1.3 &&
      sample.t - lastMotion > 5
    ) {
      observations.push({
        kind: "motion",
        t: sample.t,
        strength: Math.min(1, sample.motion * 5),
        text: "Aumento de movimiento entre fotogramas",
        origin: "vision",
      });
      lastMotion = sample.t;
    }
    if (
      !sample.scene &&
      sample.t - lastReaction > 5 &&
      sample.faces.some(
        ([x, y, w, , mouth]) =>
          (x < 0.28 || x > 0.72) &&
          (y < 0.35 || y > 0.65) &&
          w < 0.22 &&
          mouth > 0.32,
      )
    ) {
      observations.push({
        kind: "facecam-reaction",
        t: sample.t,
        strength: 0.55,
        text: "Cambio facial localizado en cámara periférica",
        origin: "vision",
      });
      lastReaction = sample.t;
    }
    previousMotion = sample.motion;
  }
  return observations;
}

export async function* followSubject(
  samples: AsyncIterable<VisualSample>,
  speech: readonly [number, number, string][],
  mode: "face-track" | "subject-track" | "gameplay-track",
) {
  let position: Point = [0.5, 0.5];
  let targeted = false;
  let faceTime = -Infinity;
  let word = 0;
  for await (const sample of samples) {
    while (word < speech.length && speech[word][1] < sample.t - 0.25) word++;
    const talking = speech[word]?.[0] <= sample.t + 0.25;
    if (sample.scene) {
      targeted = false;
      faceTime = -Infinity;
    }
    const face =
      mode === "gameplay-track"
        ? undefined
        : [...sample.faces].sort((a, b) => priority(b) - priority(a))[0];
    function priority(face: Face) {
      const near = Math.hypot(face[0] - position[0], face[1] - position[1]);
      return (
        Math.sqrt(face[2] * face[3]) +
        (talking ? face[4] * 0.36 : 0) -
        (targeted ? near * 0.42 : 0)
      );
    }
    const preferred: Point = face
      ? [face[0], face[1] + face[3] * 0.25]
      : sample.t - faceTime < 1.75
        ? position
        : mode !== "face-track" && sample.motion > 0.022 && !sample.scene
          ? sample.focus
          : [0.5, 0.5];
    if (face) faceTime = sample.t;
    if (!targeted) {
      position = preferred;
      targeted = true;
    } else {
      position = position.map((p, i) =>
        Math.min(
          1,
          Math.max(
            0,
            p + Math.max(-0.018, Math.min(0.018, (preferred[i] - p) * 0.14)),
          ),
        ),
      ) as Point;
    }
    yield { t: sample.t, position, face, motion: sample.motion };
  }
}
