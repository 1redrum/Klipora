import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { presetStyle, type ClipDraft } from "../src/lib/editor-draft.ts";
import type { LocalProject } from "../src/lib/local.ts";
import type { FramingMode } from "../src/lib/types.ts";
import type { Cut } from "./media.ts";

type Clip = LocalProject["clips"][number];
export const fingerprint = (value: unknown) =>
  createHash("sha256").update(JSON.stringify(value)).digest("hex");
export const draftFile = (cwd: string, clip: string) =>
  join(cwd, clip + ".draft.json");
export const snapshotFile = (cwd: string, id: string) =>
  join(cwd, id + ".snapshot.json");

export async function readCut(cwd: string, clip: Clip): Promise<Cut> {
  try {
    return JSON.parse(
      await readFile(join(cwd, clip.id + ".cut.json"), "utf8"),
    ) as Cut;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    return { start: clip.start, end: clip.end, title: clip.title, words: [] };
  }
}

export async function loadDraft(
  cwd: string,
  clip: Clip,
  aspect: LocalProject["aspect"],
  framing: FramingMode,
  x = 0.5,
  y = 0.5,
) {
  try {
    return JSON.parse(
      await readFile(draftFile(cwd, clip.id), "utf8"),
    ) as ClipDraft;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }

  const original = await readCut(cwd, clip);
  if (original.edit) return { ...original.edit, resolution: clip.resolution };
  return {
    start: clip.start,
    end: clip.end,
    volume: 100,
    muted: false,
    aspect: clip.aspect ?? aspect,
    resolution: clip.resolution,
    framing,
    x: x * 100,
    y: y * 100,
    captions: true,
    style: presetStyle("minimal"),
    words: original.words
      .filter(([start, end]) => end > clip.start && start < clip.end)
      .map(([start, end, text]) => ({
        start: Math.max(start, clip.start),
        end: Math.min(end, clip.end),
        text: text.trim(),
        emphasis: false,
      }))
      .filter(({ start, end }) => end > start),
    overlays: [],
  } satisfies ClipDraft;
}

export function editedCut(
  draft: ClipDraft,
  title: string,
  start = draft.start,
  end = draft.end,
): Cut {
  return {
    start,
    end,
    title,
    edit: draft,
    words: draft.words
      .filter((w) => w.end > start && w.start < end)
      .sort((a, b) => a.start - b.start)
      .map((w) => [w.start, w.end, w.text]),
  };
}
