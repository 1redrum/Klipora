import { open } from "node:fs/promises";
import { join } from "node:path";
import type { FramingMode } from "../src/lib/types.ts";
import type { Cut } from "./media.ts";
import { followSubject, visualSamples } from "./vision.ts";

const axis = (letter: "w" | "h", value: number) =>
  `clip(in_${letter}*${value.toFixed(4)}-out_${letter}/2,0,in_${letter}-out_${letter})`;

export async function framingFilter(
  cwd: string,
  source: string,
  cut: Cut,
  duration: number,
  width: number,
  height: number,
  mode: FramingMode,
  commandFile: string,
  x: number,
  y: number,
) {
  const size = width + ":" + height;
  const scale = `scale=${size}:force_original_aspect_ratio=increase:force_divisible_by=2`;
  const crop = `${scale},crop=${size}`;
  const fit = `scale=${size}:force_original_aspect_ratio=decrease:force_divisible_by=2`;
  const blur = `[0:v]split[bg][fg];[bg]${crop},setsar=1,boxblur=20[b];[fg]${fit},setsar=1[f];[b][f]overlay=(W-w)/2:(H-h)/2`;
  if (mode === "blur-fill") return blur;
  if (mode === "manual")
    return `[0:v]${crop}:x='${axis("w", x)}':y='${axis("h", y)}',setsar=1`;

  const frames = visualSamples(cwd, source, cut.start, cut.end, duration);
  if (mode === "streamer-split") {
    type Region = { x: number; y: number; w: number; h: number; count: number };
    const corner = new Map<string, Region>();
    const other = new Map<string, Region>();
    let sampled = 0;
    for await (const sample of frames) {
      sampled++;
      for (const [cx, cy, w, h] of sample.faces) {
        const peripheral =
          Math.abs(cx - 0.5) >= 0.22 && Math.abs(cy - 0.5) >= 0.15 && w <= 0.23;
        const regions = peripheral ? corner : other;
        const key = peripheral
          ? `${cx < 0.5}:${cy < 0.5}`
          : `${Math.floor(cx * 3)}:${Math.floor(cy * 3)}`;
        const sum = regions.get(key) ?? { x: 0, y: 0, w: 0, h: 0, count: 0 };
        sum.x += cx;
        sum.y += cy;
        sum.w += w;
        sum.h += h;
        sum.count++;
        regions.set(key, sum);
      }
    }
    const regions = [...corner.values()].some(
      (entry) => entry.count >= Math.max(3, sampled * 0.45),
    )
      ? corner
      : other;
    const region = [...regions.values()].sort((a, b) => b.count - a.count)[0];
    if (!region || region.count < Math.max(3, sampled * 0.45)) return blur;
    const w = Math.min(0.45, Math.max(0.13, (region.w / region.count) * 2.5));
    const h = Math.min(0.55, Math.max(0.19, (region.h / region.count) * 2.15));
    const top = Math.round((height * 0.36) / 2) * 2;
    const bottom = height - top;
    const regionCrop = `crop=w='trunc(iw*${w.toFixed(4)}/2)*2':h='trunc(ih*${h.toFixed(4)}/2)*2':x='${axis("w", region.x / region.count)}':y='${axis("h", Math.min(1, region.y / region.count + h * 0.08))}'`;
    return `[0:v]split[webcam][game];[webcam]${regionCrop},scale=${width}:${top}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=${width}:${top}:(ow-iw)/2:(oh-ih)/2,setsar=1[a];[game]scale=${width}:${bottom}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=${width}:${bottom}:(ow-iw)/2:(oh-ih)/2,setsar=1[b];[a][b]vstack`;
  }

  let previous = [-1, -1];
  let haveSignal = false;
  const file = await open(join(cwd, commandFile), "w");
  try {
    for await (const p of followSubject(frames, cut.words, mode)) {
      haveSignal ||=
        Boolean(p.face) || (mode !== "face-track" && p.motion > 0.022);
      if (
        Math.hypot(p.position[0] - previous[0], p.position[1] - previous[1]) <
        0.003
      )
        continue;
      const time = previous[0] < 0 ? 0 : p.t - cut.start;
      await file.write(
        `${time.toFixed(3)} crop@focus x '${axis("w", p.position[0])}', crop@focus y '${axis("h", p.position[1])}';\n`,
      );
      previous = p.position;
    }
  } finally {
    await file.close();
  }
  if (!haveSignal || previous[0] < 0) return blur;
  if (mode === "gameplay-track") {
    const overviewHeight = Math.round((height * 0.34) / 2) * 2;
    const focusHeight = height - overviewHeight;
    const action = `scale=${width}:${focusHeight}:force_original_aspect_ratio=increase:force_divisible_by=2,sendcmd=f=${commandFile},crop@focus=${width}:${focusHeight},setsar=1`;
    const overview = `scale=${width}:${overviewHeight}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=${width}:${overviewHeight}:(ow-iw)/2:(oh-ih)/2,setsar=1`;
    return `[0:v]split[game][full];[game]${action}[action];[full]${overview}[overview];[action][overview]vstack`;
  }
  return `[0:v]${scale},sendcmd=f=${commandFile},crop@focus=${size},setsar=1`;
}
