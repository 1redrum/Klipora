import { renameLocal as rename } from "./files.ts";
import { randomUUID } from "node:crypto";
import { setMaxListeners } from "node:events";
import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, readdir, readFile, rm, stat } from "node:fs/promises";
import type { IncomingMessage, ServerResponse } from "node:http";
import { join, resolve } from "node:path";
import { pipeline } from "node:stream/promises";
import { normalizePath, type Plugin } from "vite";
import { z } from "zod";
import {
  localApi,
  localId,
  type LocalProject,
  type LocalMoment,
} from "../src/lib/local.ts";
import { parseSourceUrl } from "../src/lib/source-url.ts";
import {
  exists,
  importUrl,
  probe,
  render,
  saveJson,
  transcript,
  type Cut,
} from "./media.ts";

import {
  draftProblem,
  draftSchema,
  type ClipDraft,
} from "../src/lib/editor-draft.ts";
import {
  draftFile,
  editedCut,
  fingerprint,
  loadDraft,
  readCut,
  snapshotFile,
} from "./editor.ts";
import { runLocal, type ProcessDevice } from "./processes.ts";
import { semanticCut, semanticMoments } from "./semantic.ts";

const optionsSchema = z.object({
  title: z.string().trim().min(1),
  url: z.string().optional(),
  language: z.enum(["auto", "es", "en"]),
  aspect: z.enum(["16:9", "9:16", "1:1", "4:5"]),
  resolution: z.enum(["720p", "1080p"]),
  framing: z.enum([
    "blur-fill",
    "manual",
    "face-track",
    "subject-track",
    "gameplay-track",
    "streamer-split",
  ]),
  framingX: z.coerce.number().min(0).max(1).optional(),
  framingY: z.coerce.number().min(0).max(1).optional(),
  target: z.coerce.number().positive(),
  automatic: z.stringbool(),
  workflow: z.enum(["semantic", "speech", "manual"]).optional(),
  contentMode: z.enum(["auto", "general", "gaming"]).optional(),
});
const cutSchema = z.object({
  start: z.coerce.number().min(0),
  end: z.coerce.number().positive(),
  resolution: z.enum(["720p", "1080p"]),
});
type Job = LocalProject & {
  options: z.infer<typeof optionsSchema>;
  pending?: z.infer<typeof cutSchema> & {
    id: string;
    variantOf?: string;
    editOf?: string;
  };
};

class RequestError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

async function readJson(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(Buffer.from(chunk));
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new RequestError(400, "El borrador recibido no es válido.");
  }
}

function verifyDraft(draft: ClipDraft, duration: number) {
  const issue = draftProblem(draft, duration);
  if (issue) throw new RequestError(400, issue);
}

async function cleanClosedRenderDirs(cwd: string) {
  for (const entry of await readdir(cwd, { withFileTypes: true })) {
    if (
      !entry.isDirectory() ||
      !/^\.klipora-render-[A-Za-z0-9]+$/.test(entry.name)
    )
      continue;
    const directory = join(cwd, entry.name);
    try {
      if (
        (await readFile(join(directory, ".encoder-closed"), "utf8")) ===
        "closed"
      ) {
        await rm(directory, {
          recursive: true,
          force: true,
          maxRetries: 4,
          retryDelay: 75,
        });
      }
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") {
        console.warn(
          "No se pudo limpiar un temporal confirmado de FFmpeg.",
          error,
        );
      }
    }
  }
}

async function mediaDevice(cwd: string, name: string) {
  try {
    return JSON.parse(
      await readFile(join(cwd, name + ".encoder.json"), "utf8"),
    ) as string;
  } catch (error) {
    if (
      (error as NodeJS.ErrnoException).code !== "ENOENT" &&
      !(error instanceof SyntaxError)
    )
      throw error;
    return undefined;
  }
}

export function localProcessing(): Plugin {
  const storage = resolve(process.env.KLIPORA_STORAGE || ".klipora");
  const parallel = Number(process.env.KLIPORA_WORKERS || 1);
  if (!Number.isSafeInteger(parallel) || parallel < 1)
    throw new Error("KLIPORA_WORKERS debe ser un entero positivo.");
  const scope = new AbortController();
  setMaxListeners(0, scope.signal);
  const tasks = new Set<Promise<unknown>>();
  let timer: ReturnType<typeof setInterval> | undefined;
  const track = (task: Promise<unknown>) => {
    tasks.add(task);
    const forget = () => tasks.delete(task);
    void task.then(forget, forget);
  };
  const stop = () => {
    clearInterval(timer);
    if (!scope.signal.aborted)
      scope.abort(
        new Error(
          "Klipora se está cerrando. El trabajo se retomará al volver a iniciar.",
        ),
      );
  };
  let detachSignals: (() => void) | undefined;
  const active = new Set<string>();
  const mutating = new Set<string>();
  const previewing = new Set<string>();
  let scheduling = false;
  const directory = (id: string) => join(storage, id);
  const jobFile = (id: string) => join(directory(id), "project.json");
  const get = async (id: string) => {
    try {
      return JSON.parse(await readFile(jobFile(id), "utf8")) as Job;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT")
        throw new RequestError(404, "Proyecto no encontrado.");
      throw error;
    }
  };
  const save = (job: Job) => saveJson(jobFile(job.id), job, true);
  const ids = async () =>
    (await readdir(storage)).filter((id) => localId.test(id));
  const phase = async (job: Job, label: string, progress = 0) => {
    job.phase = label;
    job.progress = progress;
    await save(job);
  };

  async function processJob(job: Job) {
    const cwd = directory(job.id);
    const source = "original";
    try {
      job.status = "processing";
      job.error = undefined;
      if (!(await exists(join(cwd, source)))) {
        await phase(job, "Descargando el original");
        // An interrupted yt-dlp invocation can resume its partial files.
        const downloaded = await importUrl(cwd, job.options.url!);
        await rename(join(cwd, downloaded), join(cwd, source));
      }
      await cleanClosedRenderDirs(cwd);
      const { duration, audio } = await probe(cwd, source);
      job.duration = duration;
      const { language, aspect, resolution, framing, target, automatic } =
        job.options;
      async function exportCut(
        id: string,
        cut: Cut,
        quality: Job["options"]["resolution"],
        moment?: LocalMoment,
      ) {
        const file = join(cwd, id + ".mp4");
        const registered = job.clips.findIndex((entry) => entry.id === id);
        if (registered >= 0 && (await exists(file))) return;
        const reusable =
          (await exists(file)) &&
          (await probe(cwd, id + ".mp4").then(
            () => true,
            () => false,
          ));
        const encoder = reusable
          ? await mediaDevice(cwd, id)
          : await render(
              cwd,
              source,
              cut,
              id,
              cut.edit?.aspect ?? aspect,
              quality,
              cut.edit?.framing ?? framing,
              duration,
              cut.edit ? cut.edit.x / 100 : job.options.framingX,
              cut.edit ? cut.edit.y / 100 : job.options.framingY,
            );
        await saveJson(join(cwd, id + ".cut.json"), cut);
        const { start, end, title } = cut;
        const result = {
          id,
          start,
          end,
          title,
          resolution: quality,
          moment,
          aspect: cut.edit?.aspect,
          encoder,
        };
        if (registered < 0) job.clips.push(result);
        else job.clips[registered] = result;
        await save(job);
      }

      if (job.pending) {
        const {
          start,
          end,
          id,
          resolution: quality,
          variantOf,
          editOf,
        } = job.pending;
        await phase(job, editOf ? "Exportando edición" : "Exportando corte");
        const parent = job.clips.find(
          (entry) => entry.id === (editOf ?? variantOf),
        );
        const cut = editOf
          ? editedCut(
              draftSchema.parse(
                JSON.parse(await readFile(snapshotFile(cwd, id), "utf8")),
              ),
              parent!.title,
            )
          : parent
            ? await readCut(cwd, parent)
            : { start, end, title: "Corte manual", words: [] };
        await exportCut(id, cut, quality, parent?.moment);
        delete job.pending;
      } else if (job.options.workflow === "semantic") {
        if (audio) {
          await phase(job, "Transcribiendo audio");
          for await (const _ of transcript(
            cwd,
            source,
            duration,
            language,
            (percent) => phase(job, job.phase, percent),
          )) {
            // Whisper writes each window to disk, where the semantic pass reads it.
            void _;
          }
        }
        await phase(job, "Clasificando contenido");
        const parsed = job.options.url ? parseSourceUrl(job.options.url) : null;
        const result = await semanticMoments({
          cwd,
          source,
          audio,
          duration,
          title: job.title,
          platform: parsed?.ok ? parsed.platform : "upload",
          mode: job.options.contentMode ?? "auto",
          target,
          prepared: async (classification) => {
            job.classification = classification;
            await phase(
              job,
              classification.engine === "gaming"
                ? "Analizando transcripción, audio y HUD"
                : "Analizando momentos con el modelo local",
            );
          },
          progress: (percent) => phase(job, job.phase, percent),
        });
        job.evaluated = result.evaluated;
        await phase(job, "Exportando momentos seleccionados");
        for (const [index, moment] of result.selected.entries()) {
          const { score, kind, reason, evidence, breakdown } = moment;
          await exportCut(
            moment.candidateId,
            await semanticCut(cwd, moment, audio),
            resolution,
            { score, kind, reason, evidence, breakdown },
          );
          await phase(
            job,
            job.phase,
            ((index + 1) * 100) / result.selected.length,
          );
        }
      } else if (
        (job.options.workflow === "speech" ||
          (!job.options.workflow && automatic)) &&
        audio
      ) {
        await phase(job, "Transcribiendo y exportando fragmentos");
        // Preserve whole sentences. Break at natural silences or the next sentence after the target.
        let words: Cut["words"] = [];
        let index = 0;
        const flush = async () => {
          if (!words.length) return;
          const start = words[0][0];
          const end = Math.min(duration, words.at(-1)![1]);
          if (end > start) {
            const title =
              words
                .slice(0, 12)
                .map((word) => word[2])
                .join("")
                .trim() || "Fragmento hablado";
            await exportCut(
              "auto-" + ++index,
              { start, end, title, words },
              resolution,
            );
          }
          words = [];
        };
        for await (const word of transcript(
          cwd,
          source,
          duration,
          language,
          (percent) => phase(job, job.phase, percent),
        )) {
          const previous = words.at(-1);
          if (
            previous &&
            (word[0] - previous[1] >= 2 ||
              (previous[1] - words[0][0] >= target &&
                /[.!?…]["»']?\s*$/.test(previous[2])))
          )
            await flush();
          words.push(word);
        }
        await flush();
      }
      job.status = "completed";
      await phase(job, "Listo", 100);
    } catch (error) {
      if (scope.signal.aborted) return;
      job.status = "failed";
      job.error = (
        error instanceof Error ? error.message : String(error)
      ).slice(-3600);
      await save(job);
    }
  }

  async function schedule() {
    if (scope.signal.aborted || scheduling) return;
    scheduling = true;
    try {
      for (const id of await ids()) {
        if (scope.signal.aborted || active.size >= parallel) break;
        if (active.has(id) || mutating.has(id)) continue;
        const job = await get(id).catch((error) => {
          if (error instanceof RequestError && error.status === 404)
            return undefined;
          throw error;
        });
        if (
          scope.signal.aborted ||
          mutating.has(id) ||
          !job ||
          (job.status !== "queued" && job.status !== "processing")
        )
          continue;
        active.add(id);
        const report = (stage: ProcessDevice, detail: string) => {
          job.devices ??= {};
          job.devices[stage] = detail;
        };
        track(
          runLocal({ signal: scope.signal, report }, () => processJob(job))
            .catch(console.error)
            .finally(() => active.delete(id)),
        );
      }
    } finally {
      scheduling = false;
    }
  }

  async function handle(req: IncomingMessage, res: ServerResponse, url: URL) {
    const tail = url.pathname.slice(localApi.length).split("/").filter(Boolean);
    const [id, action, clip] = tail;
    const send = (status: number, data: unknown) => {
      res.writeHead(status, {
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      });
      res.end(JSON.stringify(data));
    };
    try {
      if (scope.signal.aborted)
        throw new RequestError(503, "Klipora se está cerrando.");
      // Loopback and same-origin requests only. The custom header prevents form CSRF.
      if (
        !["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(
          req.socket.remoteAddress ?? "",
        ) ||
        !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) ||
        (req.method !== "GET" &&
          (req.headers["x-klipora-local"] !== "1" ||
            (req.headers.origin && req.headers.origin !== url.origin)))
      ) {
        throw new RequestError(403, "Acceso reservado al equipo local.");
      }
      if (!id && req.method === "GET") {
        const projects = await Promise.all(
          (await ids()).map((key) =>
            get(key).catch((error) => {
              if (error instanceof RequestError && error.status === 404)
                return undefined;
              throw error;
            }),
          ),
        );
        return send(200, projects.filter(Boolean));
      }
      if (!id && req.method === "POST") {
        const options = optionsSchema.parse(
          Object.fromEntries(url.searchParams),
        );
        if (options.url) {
          const parsed = parseSourceUrl(options.url);
          if (!parsed.ok) throw new RequestError(400, parsed.error);
          options.url = parsed.canonicalUrl;
        }
        const key = randomUUID();
        const cwd = directory(key);
        await mkdir(cwd);
        const job: Job = {
          id: key,
          title: options.title,
          options,
          createdAt: new Date().toISOString(),
          status: "queued",
          phase: "En espera",
          progress: 0,
          duration: 0,
          aspect: options.aspect,
          clips: [],
        };
        try {
          if (!options.url) {
            await pipeline(req, createWriteStream(join(cwd, "original")), {
              signal: scope.signal,
            });
            if (!(await stat(join(cwd, "original"))).size)
              throw new RequestError(400, "El archivo está vacío.");
          }
          await save(job);
        } catch (error) {
          await rm(cwd, { recursive: true, force: true });
          throw error;
        }
        return send(201, job);
      }
      if (!localId.test(id ?? ""))
        throw new RequestError(404, "Proyecto no encontrado.");
      const job = await get(id);
      if (!action && req.method === "GET") return send(200, job);
      if (
        (action === "media" || action === "preview-media") &&
        req.method === "GET" &&
        job.clips.some((entry) => entry.id === clip)
      ) {
        const file = join(
          directory(id),
          clip + (action === "media" ? ".mp4" : ".preview.mp4"),
        );
        if (action === "preview-media") {
          const revision = url.searchParams.get("v");
          const marker = join(directory(id), clip + ".preview.json");
          if (
            !revision ||
            !(await exists(marker)) ||
            (await readFile(marker, "utf8")) !== JSON.stringify(revision)
          ) {
            throw new RequestError(
              410,
              "Genera una muestra actualizada para reproducirla.",
            );
          }
        }
        const { size } = await stat(file);
        const range = req.headers.range?.match(/^bytes=(\d+)-(\d*)$/);
        const start = range ? Number(range[1]) : 0;
        const end =
          range && range[2] ? Math.min(size - 1, Number(range[2])) : size - 1;
        if (start > end) {
          res.writeHead(416, { "Content-Range": "bytes */" + size });
          return res.end();
        }
        res.writeHead(range ? 206 : 200, {
          "Content-Type": "video/mp4",
          "Content-Length": end - start + 1,
          "Accept-Ranges": "bytes",
          "X-Content-Type-Options": "nosniff",
          ...(range
            ? { "Content-Range": "bytes " + start + "-" + end + "/" + size }
            : {}),
        });
        await pipeline(createReadStream(file, { start, end }), res, {
          signal: scope.signal,
        });
        return;
      }
      if ((action === "draft" || action === "preview") && clip) {
        const base = job.clips.find((entry) => entry.id === clip);
        if (!base) throw new RequestError(404, "Clip no encontrado.");
        const cwd = directory(id);
        const fetchDraft = () =>
          loadDraft(
            cwd,
            base,
            job.aspect,
            job.options.framing,
            job.options.framingX,
            job.options.framingY,
          );
        const reply = (draft: ClipDraft) => ({
          draft,
          revision: fingerprint(draft),
          duration: job.duration,
          mediaStart: base.start,
          mediaEnd: base.end,
          title: base.title,
        });
        if (action === "draft" && req.method === "GET")
          return send(200, reply(await fetchDraft()));
        if (action === "draft" && req.method === "PUT") {
          const payload = z
            .object({ revision: z.string(), draft: draftSchema })
            .parse(await readJson(req));
          verifyDraft(payload.draft, job.duration);
          if (mutating.has(id))
            throw new RequestError(409, "Hay otro cambio en curso.");
          mutating.add(id);
          try {
            if (fingerprint(await fetchDraft()) !== payload.revision) {
              throw new RequestError(
                409,
                "El borrador cambió en otra sesión. Recarga antes de recuperar tus cambios.",
              );
            }
            await saveJson(draftFile(cwd, clip), payload.draft, true);
            return send(200, reply(payload.draft));
          } finally {
            mutating.delete(id);
          }
        }
        if (action === "preview" && req.method === "POST") {
          const { draft, cursor } = z
            .object({ draft: draftSchema, cursor: z.number().nonnegative() })
            .parse(await readJson(req));
          verifyDraft(draft, job.duration);
          if (previewing.has(id) || mutating.has(id))
            throw new RequestError(409, "Ya hay una muestra en curso.");
          previewing.add(id);
          try {
            const start = Math.max(
              draft.start,
              Math.min(cursor, draft.end - 4),
            );
            const end = Math.min(draft.end, start + 4);
            const version = fingerprint([draft, start, end]);
            const name = clip + ".preview";
            const marker = join(cwd, name + ".json");
            const last = await readFile(marker, "utf8").catch(
              (error: NodeJS.ErrnoException) => {
                if (error.code !== "ENOENT") throw error;
                return "";
              },
            );
            if (
              last !== JSON.stringify(version) ||
              !(await exists(join(cwd, name + ".mp4")))
            ) {
              await render(
                cwd,
                "original",
                editedCut(draft, base.title, start, end),
                name,
                draft.aspect,
                "360p",
                draft.framing,
                job.duration,
                draft.x / 100,
                draft.y / 100,
              );
              await saveJson(marker, version);
            }
            return send(200, {
              start,
              end,
              version,
              device: await mediaDevice(cwd, name),
            });
          } finally {
            previewing.delete(id);
          }
        }
      }
      if (
        (req.method === "POST" &&
          (action === "retry" ||
            action === "cut" ||
            action === "variant" ||
            action === "edit-export")) ||
        (req.method === "DELETE" && !action)
      ) {
        if (
          active.has(id) ||
          mutating.has(id) ||
          (req.method === "DELETE" && previewing.has(id))
        ) {
          throw new RequestError(
            409,
            "El proyecto ya tiene un trabajo en curso.",
          );
        }
        mutating.add(id);
        try {
          const current = await get(id);
          if (current.status === "processing" || current.status === "queued") {
            throw new RequestError(
              409,
              "El proyecto ya tiene un trabajo en curso.",
            );
          }
          if (req.method === "DELETE") {
            const trash = join(storage, ".deleted-" + id);
            await rename(directory(id), trash);
            await rm(trash, { recursive: true, force: true });
            return send(200, { deleted: true });
          }
          if (
            action === "cut" ||
            action === "variant" ||
            action === "edit-export"
          ) {
            if (current.pending)
              throw new RequestError(
                409,
                "Reintenta primero el corte pendiente.",
              );
            if (action === "edit-export") {
              const base = current.clips.find((entry) => entry.id === clip);
              if (!base) throw new RequestError(404, "Clip no encontrado.");
              const cwd = directory(id);
              const draft = await loadDraft(
                cwd,
                base,
                current.aspect,
                current.options.framing,
                current.options.framingX,
                current.options.framingY,
              );
              verifyDraft(draft, current.duration);
              if (fingerprint(draft) !== url.searchParams.get("revision"))
                throw new RequestError(
                  409,
                  "Vuelve a guardar el borrador antes de exportar.",
                );
              const output = "edit-" + fingerprint(draft).slice(0, 32);
              if (
                current.clips.some((entry) => entry.id === output) &&
                (await exists(join(cwd, output + ".mp4")))
              ) {
                return send(200, { id: output });
              }
              current.clips = current.clips.filter(
                (entry) => entry.id !== output,
              );
              await saveJson(snapshotFile(cwd, output), draft, true);
              current.pending = {
                id: output,
                editOf: base.id,
                start: draft.start,
                end: draft.end,
                resolution: draft.resolution,
              };
              current.error = undefined;
              current.status = "queued";
              await phase(current, "En espera");
              return send(202, { id: output });
            } else if (action === "variant") {
              const original = current.clips.find((entry) => entry.id === clip);
              if (!original) throw new RequestError(404, "Clip no encontrado.");
              const quality = original.resolution === "720p" ? "1080p" : "720p";
              const cwd = directory(id);
              const output =
                "variant-" +
                fingerprint([await readCut(cwd, original), quality]).slice(
                  0,
                  32,
                );
              if (
                current.clips.some((entry) => entry.id === output) &&
                (await exists(join(cwd, output + ".mp4")))
              )
                return send(200, current);
              current.pending = {
                id: output,
                variantOf: original.id,
                start: original.start,
                end: original.end,
                resolution: quality,
              };
            } else {
              const cut = cutSchema.parse(Object.fromEntries(url.searchParams));
              if (cut.end <= cut.start || cut.end > current.duration)
                throw new RequestError(
                  400,
                  "El corte debe quedar dentro del video.",
                );
              const output = "cut-" + fingerprint(cut).slice(0, 32);
              if (
                current.clips.some((entry) => entry.id === output) &&
                (await exists(join(directory(id), output + ".mp4")))
              )
                return send(200, current);
              current.pending = { ...cut, id: output };
            }
          } else if (current.status !== "failed") {
            throw new RequestError(409, "El trabajo ya terminó.");
          }
          current.error = undefined;
          current.status = "queued";
          await phase(current, "En espera");
          return send(200, current);
        } finally {
          mutating.delete(id);
        }
      }
      throw new RequestError(404, "Acción no disponible.");
    } catch (error) {
      if (res.headersSent || res.destroyed) return;
      if (scope.signal.aborted)
        return send(503, { error: "Klipora se está cerrando." });
      if (error instanceof RequestError)
        return send(error.status, { error: error.message });
      if (error instanceof z.ZodError)
        return send(400, {
          error: "Revisa los datos del proyecto o del corte.",
        });
      return send(500, {
        error:
          error instanceof Error ? error.message : "Error de almacenamiento.",
      });
    }
  }

  return {
    name: "klipora-local",
    config() {
      const dataFiles = normalizePath(storage) + "/**";
      return {
        server: {
          cors: false,
          fs: {
            deny: [".env", ".env.*", "*.{crt,pem}", "**/.git/**", dataFiles],
          },
          watch: { ignored: [dataFiles] },
        },
      };
    },
    async configureServer(server) {
      await mkdir(storage, { recursive: true, mode: 0o700 });
      if (server.httpServer && "requestTimeout" in server.httpServer)
        server.httpServer.requestTimeout = 0;
      const start = () => {
        if (scope.signal.aborted) return;
        timer = setInterval(() => track(schedule().catch(console.error)), 1000);
      };
      if (server.httpServer?.listening) start();
      else server.httpServer?.once("listening", start);
      server.httpServer?.once("close", stop);
      const interrupt = () => {
        stop();
        void server
          .close()
          .then(() => {
            process.exitCode = 130;
          })
          .catch(console.error);
      };
      process.prependListener("SIGTERM", stop);
      process.prependListener("SIGINT", interrupt);
      if (process.platform === "win32")
        process.prependListener("SIGBREAK", interrupt);
      detachSignals = () => {
        process.off("SIGTERM", stop);
        process.off("SIGINT", interrupt);
        if (process.platform === "win32") process.off("SIGBREAK", interrupt);
      };
      server.middlewares.use((req, res, next) => {
        let url: URL;
        try {
          url = new URL(
            req.url || "/",
            "http://" + (req.headers.host || "invalid"),
          );
        } catch {
          return next();
        }
        if (
          url.pathname !== localApi &&
          !url.pathname.startsWith(localApi + "/")
        )
          return next();
        const cancel = () => {
          if (!req.complete) req.destroy();
        };
        scope.signal.addEventListener("abort", cancel, { once: true });
        track(
          runLocal({ signal: scope.signal }, () =>
            handle(req, res, url),
          ).finally(() => scope.signal.removeEventListener("abort", cancel)),
        );
      });
    },
    async closeServer() {
      stop();
      detachSignals?.();
      await Promise.allSettled(tasks);
    },
  };
}
