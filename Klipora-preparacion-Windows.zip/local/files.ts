import { rename } from "node:fs/promises";
import { setTimeout } from "node:timers/promises";

export async function renameLocal(from: string, to: string) {
  for (let attempt = 0; ; attempt++) {
    try {
      await rename(from, to);
      return;
    } catch (error) {
      const code = (error as NodeJS.ErrnoException).code;
      if (
        process.platform !== "win32" ||
        attempt >= 4 ||
        !["EBUSY", "EPERM", "EACCES"].includes(code ?? "")
      )
        throw error;
      // Antivirus/indexing may hold a handle briefly. Keep the previous committed file until replacement succeeds.
      await setTimeout(60 * (attempt + 1));
    }
  }
}
