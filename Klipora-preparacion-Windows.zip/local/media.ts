import { renameLocal as rename } from "./files.ts";
import { framingFilter } from "./framing.ts";
import { makeAss } from "./ass.ts";
import type { ClipDraft } from "../src/lib/editor-draft.ts";
import type { FramingMode } from "../src/lib/types.ts";
import {
  closeLocal,
  execLocal as exec,
  localSignal,
  pythonCommand,
  reportDevice,
  spawnLocal,
} from "./processes.ts";
import { createInterface } from "node:readline";
import {
  cp,
  mkdir,
  mkdtemp,
  readFile,
  rm,
  stat,
  writeFile,
} from "node:fs/promises";
import { basename, join } from "node:path";

const ff = (args: string[], cwd: string, orphanRenderDir?: string) =>
  exec(
    "ffmpeg",
    ["-nostdin", "-hide_banner", "-loglevel", "error", "-y", ...args],
    { cwd, orphanRenderDir },
  );

export type TimedWord = [start: number, end: number, text: string];
export type Cut = {
  start: number;
  end: number;
  title: string;
  words: TimedWord[];
  edit?: ClipDraft;
};

export async function saveJson(path: string, value: unknown, durable = false) {
  await writeFile(path + ".tmp", JSON.stringify(value), { flush: durable });
  await rename(path + ".tmp", path);
}

export async function probe(cwd: string, file: string) {
  const { stdout } = await exec(
    "ffprobe",
    [
      "-v",
      "error",
      "-show_entries",
      "format=duration:stream=codec_type",
      "-of",
      "json",
      file,
    ],
    { cwd },
  );
  const result = JSON.parse(stdout) as {
    streams: { codec_type: string }[];
    format: { duration: string };
  };
  const duration = Number(result.format.duration);
  if (
    !result.streams.some((s) => s.codec_type === "video") ||
    !Number.isFinite(duration) ||
    duration <= 0
  ) {
    throw new Error("El archivo no contiene un video con duración válida.");
  }
  return {
    duration,
    audio: result.streams.some((s) => s.codec_type === "audio"),
  };
}

export async function importUrl(cwd: string, url: string) {
  const { stdout } = await exec(
    pythonCommand,
    [
      "-m",
      "yt_dlp",
      "--ignore-config",
      "--no-playlist",
      "--no-progress",
      "--no-simulate",
      "--print",
      "after_move:filepath",
      "-o",
      "download.%(ext)s",
      "--",
      url,
    ],
    { cwd },
  );
  const file = basename(stdout.trim().split("\n").at(-1) || "");
  if (!/^download\.[a-z0-9]+$/i.test(file))
    throw new Error(
      "La plataforma no entregó un archivo. Puedes subir el original.",
    );
  return file;
}

async function cachedWords(
  checkpoint: string,
): Promise<TimedWord[] | undefined> {
  const cached: unknown = await readFile(checkpoint, "utf8").then(
    (value) => {
      try {
        return JSON.parse(value) as unknown;
      } catch (error) {
        if (!(error instanceof SyntaxError)) throw error;
      }
    },
    (error: NodeJS.ErrnoException) => {
      if (error.code !== "ENOENT") throw error;
    },
  );
  if (
    Array.isArray(cached) &&
    cached.every(
      (word) =>
        Array.isArray(word) &&
        word.length === 3 &&
        Number.isFinite(word[0]) &&
        Number.isFinite(word[1]) &&
        typeof word[2] === "string",
    )
  ) {
    return cached as TimedWord[];
  }
}

export const transcriptWindow = 300;

export async function* transcript(
  cwd: string,
  source: string,
  duration: number,
  language: string,
  progress: (n: number) => Promise<void>,
) {
  const window = transcriptWindow;
  const overlap = 4;
  let python: ReturnType<typeof spawnLocal> | undefined;
  let replies: AsyncIterableIterator<string> | undefined;
  let failure = "";
  let stage: string | undefined;
  await mkdir(join(cwd, "transcript"), { recursive: true });
  try {
    for (let start = 0; start < duration; start += window) {
      const checkpoint = join(cwd, "transcript", start + ".json");
      let words: TimedWord[];
      localSignal()?.throwIfAborted();
      const cached = await cachedWords(checkpoint);
      if (cached) {
        words = cached;
        const device = await readFile(checkpoint + ".device", "utf8").catch(
          (error: NodeJS.ErrnoException) => {
            if (error.code !== "ENOENT") throw error;
            return "dispositivo sin registro";
          },
        );
        reportDevice("whisper", "Caché · " + device);
      } else {
        stage ??= await mkdtemp(join(cwd, ".klipora-audio-"));
        const scratch = join(stage, "audio.wav");
        const from = Math.max(0, start - overlap);
        await ff(
          [
            "-ss",
            String(from),
            "-i",
            source,
            "-t",
            String(Math.min(duration, start + window + overlap) - from),
            "-vn",
            "-ac",
            "1",
            "-ar",
            "16000",
            scratch,
          ],
          cwd,
        );
        if (!python) {
          const child = spawnLocal(
            pythonCommand,
            [join(process.cwd(), "local", "transcribe.py")],
            { cwd },
          );
          python = child;
          child.on("error", (e) => {
            failure = e.message;
          });
          child.stdin.on("error", (e) => {
            failure ||= e.message;
          });
          child.stderr.on("data", (data: Buffer) => {
            failure = (failure + data.toString()).slice(-3000);
          });
          replies = createInterface({ input: child.stdout })[
            Symbol.asyncIterator
          ]();
        }
        python.stdin!.write(JSON.stringify([scratch, language]) + "\n");
        const reply = await replies!.next();
        localSignal()?.throwIfAborted();
        if (reply.done) throw new Error(failure || "Se detuvo faster-whisper.");
        const result = JSON.parse(reply.value) as {
          words?: TimedWord[];
          error?: string;
          device?: string;
        };
        if (!result.words)
          throw new Error(result.error || "No se pudo transcribir.");
        words = result.words
          .map(([a, b, label]): TimedWord => [a + from, b + from, label])
          .filter(
            ([a, b]) => (a + b) / 2 >= start && (a + b) / 2 < start + window,
          );
        const device = result.device || "dispositivo sin registro";
        reportDevice("whisper", device);
        await writeFile(checkpoint + ".device", device);
        await saveJson(checkpoint, words, true);
      }
      yield* words;
      await progress(Math.min(100, ((start + window) * 100) / duration));
    }
  } finally {
    if (python) await closeLocal(python);
    if (stage)
      await rm(stage, {
        recursive: true,
        force: true,
        maxRetries: 4,
        retryDelay: 75,
      });
  }
}

function timecode(seconds: number) {
  const ms = Math.max(0, Math.round(seconds * 1000));
  return (
    [
      Math.floor(ms / 3600000),
      Math.floor(ms / 60000) % 60,
      Math.floor(ms / 1000) % 60,
    ]
      .map((part) => String(part).padStart(2, "0"))
      .join(":") +
    "," +
    String(ms % 1000).padStart(3, "0")
  );
}

export async function render(
  cwd: string,
  source: string,
  cut: Cut,
  name: string,
  aspect: string,
  resolution: string,
  framing: FramingMode,
  duration: number,
  x = 0.5,
  y = 0.5,
) {
  const short = Number.parseInt(resolution, 10);
  const [width, height] =
    aspect === "16:9"
      ? [Math.round((short * 16) / 18) * 2, short]
      : aspect === "9:16"
        ? [short, Math.round((short * 16) / 18) * 2]
        : aspect === "4:5"
          ? [short, Math.round((short * 5) / 8) * 2]
          : [short, short];
  const dir = await mkdtemp(join(cwd, ".klipora-render-"));
  const relative = basename(dir);
  const commandFile = relative + "/crop.txt";
  const subs = relative + (cut.edit ? "/captions.ass" : "/captions.srt");
  const output = relative + "/output.mp4";
  try {
    const filter = await framingFilter(
      cwd,
      source,
      cut,
      duration,
      width,
      height,
      framing,
      commandFile,
      x,
      y,
    );
    const captions = [];
    for (let i = 0; !cut.edit && i < cut.words.length; i += 6) {
      const words = cut.words.slice(i, i + 6);
      captions.push(
        [
          captions.length + 1,
          timecode(words[0][0] - cut.start) +
            " --> " +
            timecode(words.at(-1)![1] - cut.start),
          words
            .map((word) => word[2].replace(/[<>\r\n]/g, ""))
            .join("")
            .trim(),
        ].join("\n"),
      );
    }
    const ass =
      cut.edit && makeAss(cut.edit, cut.start, cut.end, width, height);
    const subtitles =
      ass || (captions.length ? captions.join("\n\n") + "\n" : "");
    if (subtitles) {
      if (ass) await editorFonts(cwd);
      await writeFile(join(cwd, subs), subtitles);
    }
    const audio = cut.edit?.muted
      ? ["-an"]
      : [
          "-map",
          "0:a:0?",
          "-c:a",
          "aac",
          ...(cut.edit && cut.edit.volume !== 100
            ? ["-af", `volume=${cut.edit.volume / 100}`]
            : []),
        ];
    const args = [
      "-ss",
      String(cut.start),
      "-i",
      source,
      "-t",
      String(cut.end - cut.start),
      "-filter_complex_threads",
      "1",
      "-filter_complex",
      filter +
        (subtitles
          ? ",subtitles=" + subs + (ass ? ":fontsdir=.editor-fonts" : "")
          : "") +
        "[video]",
      "-map",
      "[video]",
      ...audio,
      "-pix_fmt",
      "yuv420p",
      "-movflags",
      "+faststart",
    ];
    const preview = resolution === "360p";
    const encoders = preview ? ["libx264"] : await usableEncoders(cwd);
    let fallback = preview ? "" : encoderFallback;
    let used = "libx264";
    for (const encoder of encoders) {
      const quality =
        encoder === "libx264"
          ? preview
            ? ["-preset", "veryfast", "-crf", "22"]
            : ["-crf", "19"]
          : ["-b:v", resolution === "720p" ? "6M" : "10M"];
      try {
        await ff([...args, "-c:v", encoder, ...quality, output], cwd, dir);
        used = encoder;
        break;
      } catch (error) {
        localSignal()?.throwIfAborted();
        if (encoder === "libx264") throw error;
        rejectedEncoders.add(encoder);
        fallback = encoderFallback = encoder + ": " + encoderFailure(error);
      }
    }
    await probe(cwd, output);
    localSignal()?.throwIfAborted();
    await rename(join(cwd, output), join(cwd, name + ".mp4"));
    const kind =
      used === "libx264"
        ? "CPU"
        : /^h264_(nvenc|qsv|amf|videotoolbox|vaapi)$/.test(used)
          ? "GPU"
          : "Dispositivo sin confirmar";
    const device =
      kind +
      " · " +
      used +
      (used === "libx264" && fallback ? " (" + fallback + ")" : "");
    reportDevice("encoder", device);
    await saveJson(join(cwd, name + ".encoder.json"), device);
    return device;
  } finally {
    await rm(dir, {
      recursive: true,
      force: true,
      maxRetries: 4,
      retryDelay: 75,
    });
  }
}

const fontCopies = new Map<string, Promise<void>>();

async function editorFonts(cwd: string) {
  let copy = fontCopies.get(cwd);
  if (!copy) {
    const destination = join(cwd, ".editor-fonts");
    const ready = join(destination, ".ready");
    copy = (async () => {
      if (await exists(ready)) return;
      await cp(join(process.cwd(), "local", "fonts"), destination, {
        recursive: true,
      });
      await writeFile(ready, "");
    })().finally(() => fontCopies.delete(cwd));
    fontCopies.set(cwd, copy);
  }
  await copy;
}

const rejectedEncoders = new Set<string>();
let encoderFallback = "";

function encoderFailure(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);
  return (message.split(/\r?\n/).slice(1).find(Boolean) ?? message).slice(
    0,
    180,
  );
}
let hardwareProbe: Promise<string[]> | undefined;

async function usableEncoders(cwd: string) {
  const configured = process.env.KLIPORA_ENCODER;
  if (configured === "cpu" || configured === "libx264") return ["libx264"];
  hardwareProbe ??= detectEncoders(cwd, configured).catch((error: unknown) => {
    hardwareProbe = undefined;
    throw error;
  });
  return [
    ...(await hardwareProbe).filter(
      (encoder) => !rejectedEncoders.has(encoder),
    ),
    "libx264",
  ];
}

async function detectEncoders(cwd: string, configured?: string) {
  const candidates = configured
    ? [configured]
    : process.platform === "darwin"
      ? ["h264_videotoolbox"]
      : ["h264_nvenc", "h264_qsv", "h264_amf"];
  const { stdout } = await exec("ffmpeg", ["-hide_banner", "-encoders"], {
    cwd,
  });
  const available = new Set(
    stdout.split("\n").map((line) => line.trim().split(/\s+/)[1]),
  );
  const usable: string[] = [];
  for (const encoder of candidates) {
    if (!available.has(encoder)) {
      encoderFallback ||= encoder + ": ausente en esta compilación de FFmpeg";
      continue;
    }
    try {
      // Listing an encoder only checks the FFmpeg build. Encoding a frame checks the driver/device.
      await ff(
        [
          "-f",
          "lavfi",
          "-i",
          "color=size=128x128:rate=1",
          "-frames:v",
          "1",
          "-pix_fmt",
          "yuv420p",
          "-c:v",
          encoder,
          "-f",
          "null",
          "-",
        ],
        cwd,
      );
      usable.push(encoder);
    } catch (error) {
      localSignal()?.throwIfAborted();
      encoderFallback = encoder + ": " + encoderFailure(error);
    }
  }
  return usable;
}

export async function exists(path: string) {
  return stat(path).then(
    () => true,
    (error: NodeJS.ErrnoException) => {
      if (error.code === "ENOENT") return false;
      throw error;
    },
  );
}
