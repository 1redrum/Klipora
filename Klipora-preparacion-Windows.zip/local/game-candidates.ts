import type { MomentKind, SignalKind } from "../src/lib/analysis/content.ts";
import type { MomentCandidate } from "../src/lib/analysis/selection.ts";
import type { Observation } from "./game-signals.ts";

const eventKind: Partial<Record<SignalKind, MomentKind>> = {
  "kill-feed": "kill",
  multikill: "multikill",
  "victory-screen": "victoria",
  "defeat-screen": "derrota",
  death: "fail",
  objective: "competitivo",
  "round-change": "giro-partida",
};

export function evidenceLabel(o: Observation) {
  const source =
    o.origin === "vision" ? "Video" : o.origin === "audio" ? "Audio" : "OCR";
  return `${source} (${o.t.toFixed(1)} s): «${o.text}»`;
}

export function observedGames(
  observations: Observation[],
  from: number,
  to: number,
) {
  const candidates: (MomentCandidate & { evidence: Observation[] })[] = [];
  for (const event of observations) {
    const kind = eventKind[event.kind];
    if (!kind || event.origin !== "ocr" || event.t < from || event.t >= to)
      continue;
    // OCR names the event. An independent frame or audio change must corroborate the timing.
    const vision = observations
      .filter(
        (o) =>
          o.origin === "vision" &&
          o.kind !== "facecam-reaction" &&
          Math.abs(o.t - event.t) <= 3,
      )
      .sort((a, b) => b.strength - a.strength)[0];
    const audio = observations
      .filter((o) => o.origin === "audio" && Math.abs(o.t - event.t) <= 3)
      .sort((a, b) => b.strength - a.strength)[0];
    if (!vision && !audio) continue;
    const evidence = [event, ...[vision, audio].filter((o) => o !== undefined)];
    const supporting = vision?.strength ?? 0;
    const intensity = audio?.strength ?? supporting * 0.65;
    const cohesion = vision && audio ? 10 : 0;
    const category = event.kind === "objective" ? 0 : 5;
    candidates.push({
      id: `hud-${event.t.toFixed(3)}-${event.kind}`,
      start: event.t,
      end: event.t + 0.375,
      peak: event.t + 0.125,
      kind,
      evidence,
      reason: evidenceLabel(event),
      signals: evidence,
      // Explicit editorial rubric from measured data, not a probability or user-engagement metric.
      breakdown: {
        interest: Math.round(59 + category + cohesion + supporting * 12),
        emotion: Math.round(37 + intensity * 43),
        entertainment: Math.round(52 + cohesion + supporting * 16),
        context: 67 + cohesion,
        impact: Math.round(60 + category + supporting * 15),
        hook: Math.round(57 + cohesion + intensity * 16),
      },
    });
  }
  return candidates;
}
