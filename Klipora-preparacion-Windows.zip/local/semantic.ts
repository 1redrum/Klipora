import { createHash } from "node:crypto";
import { mkdir, readFile } from "node:fs/promises";
import { join } from "node:path";
import { z } from "zod";
import {
  classifyContent,
  type ContentClassification,
} from "../src/lib/analysis/classifier.ts";
import {
  MOMENT_KIND_LABEL,
  GAME_KEYS,
  type GameKey,
  type ContentMode,
  type MomentKind,
  type MomentSignal,
  type SignalKind,
} from "../src/lib/analysis/content.ts";
import {
  buildMomentPrompt,
  MOMENT_RESPONSE_SCHEMA,
} from "../src/lib/analysis/prompts.ts";
import {
  jaccard,
  overlapRatio,
  scoreMoment,
  selectMoments,
  sentenceBoundaries,
  tokens,
  type SelectedMoment,
  type MomentCandidate,
} from "../src/lib/analysis/selection.ts";
import type { SourcePlatform, Word } from "../src/lib/types.ts";
import { gameObservations, type Observation } from "./game-signals.ts";
import { saveJson, transcriptWindow, type TimedWord } from "./media.ts";

import { localSignal, reportDevice } from "./processes.ts";

const core = 90;
const context = 25;
import { visualObservations } from "./vision.ts";
import { evidenceLabel, observedGames } from "./game-candidates.ts";
import {
  chooseBounds,
  trimLeadingFragment,
  trimTrailingFragment,
} from "./editorial.ts";

const stepVersion = 4;
const editorialVersion = 4;
const visualKinds: Partial<Record<MomentKind, SignalKind[]>> = {
  kill: ["kill-feed", "multikill"],
  multikill: ["multikill"],
  victoria: ["victory-screen", "round-change"],
  derrota: ["defeat-screen", "round-change"],
};
const semanticKinds: Partial<Record<MomentKind, SignalKind>> = {
  frase: "quotable",
  "cambio-tema": "topic-shift",
  gracioso: "punchline",
  "respuesta-inesperada": "unexpected-answer",
  reaccion: "unexpected-answer",
  debate: "disagreement",
  historia: "story-arc",
  ensenanza: "explanation",
  opinion: "opinion",
  "reaccion-streamer": "unexpected-answer",
  celebracion: "quotable",
  fail: "unexpected-answer",
  inesperado: "unexpected-answer",
  jugada: "quotable",
  competitivo: "quotable",
  "giro-partida": "unexpected-answer",
};

async function checkpoint<T>(
  path: string,
  create: () => Promise<T>,
): Promise<T> {
  try {
    return JSON.parse(await readFile(path, "utf8")) as T;
  } catch (error) {
    if (
      (error as NodeJS.ErrnoException).code !== "ENOENT" &&
      !(error instanceof SyntaxError)
    )
      throw error;
    const result = await create();
    await saveJson(path, result);
    return result;
  }
}

async function readWords(
  cwd: string,
  start: number,
  end: number,
  audio: boolean,
) {
  if (!audio) return [];
  const words: Word[] = [];
  for (
    let base = Math.floor(start / transcriptWindow) * transcriptWindow;
    base < end;
    base += transcriptWindow
  ) {
    const chunk = JSON.parse(
      await readFile(join(cwd, "transcript", base + ".json"), "utf8"),
    ) as TimedWord[];
    for (const [a, b, text] of chunk)
      if ((a + b) / 2 >= start && (a + b) / 2 < end) {
        words.push({ start: a, end: b, text });
      }
  }
  return words;
}

function transcriptLines(words: Word[]) {
  const { ends } = sentenceBoundaries(words);
  const lines: { start: number; end: number; text: string }[] = [];
  let offset = 0;
  for (const [i, word] of words.entries()) {
    if (!ends.has(i) && word.end - words[offset].start < 12) continue;
    const text = words
      .slice(offset, i + 1)
      .map((entry) => entry.text)
      .join("")
      .trim();
    if (text) lines.push({ start: words[offset].start, end: word.end, text });
    offset = i + 1;
  }
  return lines;
}

async function infer(
  classification: ContentClassification,
  window: Parameters<typeof buildMomentPrompt>[1],
  ids: string[],
) {
  const base = new URL(process.env.KLIPORA_LLM_URL || "http://127.0.0.1:8080");
  if (
    base.protocol !== "http:" ||
    base.hostname !== "127.0.0.1" ||
    base.username ||
    base.password
  ) {
    throw new Error(
      "KLIPORA_LLM_URL debe ser una dirección HTTP en 127.0.0.1.",
    );
  }
  const model = process.env.KLIPORA_LLM_MODEL || "klipora";
  const location = z.enum(ids);
  const entry =
    MOMENT_RESPONSE_SCHEMA[classification.engine].shape.moments.element;
  const contract = z.object({
    moments: z.array(
      entry.omit({ start: true, end: true, peak: true }).extend({
        startId: location,
        focusId: location.optional(),
        endId: location,
        evidenceIds: z.array(location).min(1),
      }),
    ),
  });
  const schema = z.toJSONSchema(contract);
  const { system, user } = buildMomentPrompt(classification, window);
  const signal = localSignal();
  reportDevice(
    "llm",
    "Servidor local · " +
      model +
      " (dispositivo gestionado por el servidor de inferencia)",
  );
  const response = await fetch(new URL("/v1/chat/completions", base), {
    signal,
    method: "POST",
    redirect: "error",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      temperature: 0.15,
      frequency_penalty: 0.15,
      stream: true,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      response_format: {
        type: "json_schema",
        json_schema: { name: "moments", strict: true, schema },
      },
    }),
  }).catch((error: unknown) => {
    signal?.throwIfAborted();
    throw new Error(
      "No se pudo conectar con el modelo local. Inicia llama-server u Ollama y usa Reintentar.",
      { cause: error },
    );
  });
  if (!response.ok)
    throw new Error(
      `El modelo local devolvió HTTP ${response.status}. ${(await response.text()).slice(0, 500)}`,
    );
  const reader = response.body?.getReader();
  if (!reader) throw new Error("El modelo local no devolvió una respuesta.");
  const decoder = new TextDecoder();
  let buffer = "";
  let result = "";
  let finish: string | undefined;
  try {
    while (finish === undefined) {
      const chunk = await reader.read();
      if (chunk.done) break;
      buffer += decoder.decode(chunk.value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:") || line.slice(5).trim() === "[DONE]")
          continue;
        const event = JSON.parse(line.slice(5)) as {
          choices?: {
            finish_reason?: string | null;
            delta?: { content?: string };
          }[];
          error?: { message?: string };
        };
        if (event.error)
          throw new Error(event.error.message || "Falló la inferencia local.");
        const choice = event.choices?.[0];
        result += choice?.delta?.content ?? "";
        finish = choice?.finish_reason ?? finish;
      }
    }
  } finally {
    await reader.cancel();
  }
  if (finish === "length")
    throw new Error(
      "El modelo agotó el contexto. Aumenta el contexto del servidor local y reintenta.",
    );
  let raw: unknown;
  try {
    raw = JSON.parse(result);
  } catch {
    throw new Error(
      "El modelo entregó una respuesta incompleta o inválida. Reintenta o selecciona otro modelo local.",
    );
  }
  const parsed = contract.safeParse(raw);
  if (!parsed.success)
    throw new Error(
      "El modelo no entregó un análisis con el formato esperado. Reintenta o selecciona otro modelo local.",
    );
  return parsed.data.moments;
}

type Ranked = SelectedMoment & { window: number; fingerprint: string[] };
interface SemanticOptions {
  cwd: string;
  source: string;
  duration: number;
  audio: boolean;
  title: string;
  platform: SourcePlatform;
  mode: ContentMode;
  target: number;
  prepared: (classification: ContentClassification) => Promise<void>;
  progress: (percent: number) => Promise<void>;
}

export async function semanticMoments(options: SemanticOptions) {
  const { cwd, source, audio, duration, title, platform, mode, target } =
    options;
  const root = join(cwd, "semantic");
  await mkdir(root, { recursive: true });
  const classification = await checkpoint(
    join(root, "classification.json"),
    async () => {
      const snippets = await Promise.all(
        Array.from({ length: 5 }, (_, i) => {
          const start = (duration * i) / 5;
          return readWords(cwd, start, Math.min(duration, start + 30), audio);
        }),
      );
      return classifyContent(
        {
          platform,
          title,
          transcriptSample: snippets
            .flat()
            .map((word) => word.text)
            .join(""),
        },
        mode,
      );
    },
  );
  await options.prepared(classification);
  const key = createHash("sha256")
    .update(
      JSON.stringify([
        stepVersion,
        process.env.KLIPORA_LLM_URL,
        process.env.KLIPORA_LLM_MODEL,
        process.env.KLIPORA_OCR_LANG,
        target,
        classification,
      ]),
    )
    .digest("hex")
    .slice(0, 20);
  const found: Ranked[] = [];
  let evaluated = 0;
  for (let base = 0; base < duration; base += core) {
    const start = Math.max(0, base - context);
    const end = Math.min(duration, base + core + context);
    const result = await checkpoint(
      join(root, `${key}-edit${editorialVersion}-${base}.json`),
      async () => {
        const words = await readWords(cwd, start, end, audio);
        const lines = transcriptLines(words);
        const visuals = await visualObservations(
          cwd,
          source,
          start,
          end,
          duration,
        );
        const category = classification.category as GameKey;
        const game = GAME_KEYS.includes(category) ? category : undefined;
        const gameEvidence: Observation[] =
          classification.engine === "gaming"
            ? await checkpoint(
                join(root, `media-v4-${game ?? "generic"}-${base}.json`),
                () => gameObservations(cwd, source, start, end, audio, game),
              )
            : [];
        const observations = [...gameEvidence, ...visuals].sort(
          (a, b) => a.t - b.t,
        );
        const seeded =
          classification.engine === "gaming"
            ? observedGames(observations, base, Math.min(duration, base + core))
            : [];
        if (!lines.length && !seeded.length)
          return { evaluations: [], selected: [] };
        const text = lines
          .map(
            (line, index) =>
              `T${index} [${line.start.toFixed(2)}–${line.end.toFixed(2)} s] ${line.text}`,
          )
          .join("\n");
        const observed = observations
          .map(
            (entry, index) =>
              `M${index} [${entry.t.toFixed(2)} s] ${entry.kind}: ${entry.text}`,
          )
          .join("\n");
        const spans = new Map<string, { start: number; end: number }>();
        lines.forEach((line, index) => spans.set(`T${index}`, line));
        observations.forEach((event, index) =>
          spans.set(`M${index}`, {
            start: event.t,
            end: Math.min(end, event.t + 1),
          }),
        );
        const judgments = lines.length
          ? await checkpoint(join(root, `${key}-judgments-${base}.json`), () =>
              infer(
                classification,
                {
                  start,
                  end,
                  transcript: text,
                  signals: observations,
                  targetLengthSec: target,
                  observations: `El evento principal debe caer entre ${base.toFixed(2)} y ${Math.min(duration, base + core).toFixed(2)} s. Usa las partes anteriores y posteriores para el contexto.\n${observed}`,
                },
                [...spans.keys()],
              ),
            )
          : [];
        const moments = judgments.map((moment) => {
          const first = spans.get(moment.startId)!;
          const last = spans.get(moment.endId)!;
          const starts = Math.max(start, first.start);
          const finishes = Math.min(end, last.end);
          const references = [...new Set(moment.evidenceIds)]
            .map((id) => spans.get(id)!)
            .filter(
              (entry) =>
                entry.start >= starts - 0.2 && entry.end <= finishes + 0.2,
            );
          const anchored = references.length > 0;
          const gapBefore = anchored
            ? Math.min(...references.map((entry) => entry.start)) - starts
            : 0;
          const gapAfter = anchored
            ? finishes - Math.max(...references.map((entry) => entry.end))
            : 0;
          // Remove unsupported excess around short claims while preserving the requested setup.
          const timeStart =
            gapBefore > target * 0.45
              ? starts + gapBefore - Math.min(6, target * 0.3)
              : starts;
          const timeEnd =
            gapAfter > target * 0.4
              ? finishes - gapAfter + Math.min(3, target * 0.17)
              : finishes;
          const proposed = { start: timeStart, end: timeEnd };
          const focusId = moment.focusId ?? moment.evidenceIds[0];
          const focus = spans.get(focusId)!;
          const canTighten =
            classification.engine === "general" &&
            focusId.startsWith("T") &&
            ["frase", "opinion", "reaccion", "cambio-tema"].includes(
              moment.kind,
            ) &&
            timeEnd - timeStart > target * 1.35 &&
            !moment.needsPriorContext;
          const narrowed = canTighten
            ? chooseBounds(words, proposed, focus, target)
            : proposed;
          const completed =
            classification.engine === "general" && !moment.needsPriorContext
              ? trimTrailingFragment(
                  words,
                  trimLeadingFragment(words, narrowed),
                )
              : narrowed;
          const chosen = completed ?? {
            start: narrowed.start,
            end: narrowed.start,
          };
          const keyReference = [focus, ...references].find(
            (entry) => entry.start >= chosen.start && entry.end <= chosen.end,
          );
          const peak = keyReference
            ? (keyReference.start + keyReference.end) / 2
            : (chosen.start + chosen.end) / 2;
          const comicCue =
            /\[(?:risas|laughter|laughs)\]|\b(?:era(?: una)? broma|es(?: una)? broma|just kidding|tells? a joke|ha ha)\b/iu;
          const humorObserved = moment.evidenceIds.some(
            (id) =>
              id.startsWith("T") &&
              comicCue.test(lines[Number(id.slice(1))]?.text ?? ""),
          );
          const unconfirmedHumor =
            classification.engine === "general" &&
            moment.kind === "gracioso" &&
            !humorObserved;
          const kind: MomentKind = unconfirmedHumor ? "frase" : moment.kind;
          const breakdown = unconfirmedHumor
            ? {
                ...moment.breakdown,
                entertainment: Math.max(1, moment.breakdown.entertainment - 10),
              }
            : moment.breakdown;
          return { ...moment, kind, breakdown, ...chosen, peak };
        });

        const bounds = new Map<
          string,
          {
            start: number;
            end: number;
            label: string;
            kind: "speech" | "ocr" | "vision" | "audio";
          }[]
        >();
        const candidates: MomentCandidate[] = moments.flatMap(
          (moment, index) => {
            const id = `semantic-${key}-e${editorialVersion}-${base}-${index}`;
            const peak = moment.peak;
            if (
              moment.start < start - 0.1 ||
              moment.end > end + 0.1 ||
              moment.end <= moment.start ||
              peak < moment.start ||
              peak > moment.end
            )
              return [];
            const signals: MomentSignal[] = [];
            const evidence: NonNullable<ReturnType<typeof bounds.get>> = [];
            const cited = new Set(moment.evidenceIds ?? []);
            const relevantVisual = visualKinds[moment.kind];
            const supportsVisual = (entry: Observation) => {
              if (!relevantVisual?.includes(entry.kind)) return false;
              if (entry.kind !== "round-change") return true;
              return moment.kind === "victoria"
                ? /won|ganada/i.test(entry.text)
                : /lost|perdida/i.test(entry.text);
            };
            const material = observations.filter(
              (entry) =>
                entry.t >= moment.start - 0.5 && entry.t <= moment.end + 0.5,
            );
            if (relevantVisual && !material.some(supportsVisual)) return [];
            for (const evidenceId of cited) {
              if (!/^[TM]\d+$/.test(evidenceId)) continue;
              const i = Number(evidenceId.slice(1));
              if (evidenceId.startsWith("T")) {
                const line = lines[i];
                if (!line || line.start > moment.end || line.end < moment.start)
                  continue;
                evidence.push({
                  start: line.start,
                  end: line.end,
                  kind: "speech",
                  label: `Transcripción (${line.start.toFixed(1)} s): «${line.text}»`,
                });
                const kind = semanticKinds[moment.kind];
                if (kind) signals.push({ kind, t: line.start, strength: 0.65 });
              } else {
                const entry = observations[i];
                if (
                  !entry ||
                  !material.includes(entry) ||
                  entry.kind === "audio-peak"
                )
                  continue;
                evidence.push({
                  start: entry.t,
                  end: entry.t,
                  kind: entry.origin ?? "ocr",
                  label: evidenceLabel(entry),
                });
                signals.push(entry);
              }
            }
            if (!evidence.length) return [];
            if (
              classification.engine === "general" &&
              !evidence.some((entry) => entry.kind === "speech")
            )
              return [];
            if (
              relevantVisual &&
              !material.some(
                (entry) =>
                  entry.origin !== "ocr" &&
                  (entry.origin === "vision" || entry.kind === "audio-peak"),
              )
            )
              return [];
            for (const entry of material) {
              if (supportsVisual(entry) && !signals.includes(entry)) {
                evidence.push({
                  start: entry.t,
                  end: entry.t,
                  kind: entry.origin ?? "ocr",
                  label: evidenceLabel(entry),
                });
                signals.push(entry);
              }
            }
            const peakAudio = material
              .filter((entry) => entry.kind === "audio-peak")
              .sort((a, b) => b.strength - a.strength)[0];
            if (peakAudio) {
              signals.push(peakAudio);
              evidence.push({
                start: peakAudio.t,
                end: peakAudio.t,
                kind: "audio",
                label: evidenceLabel(peakAudio),
              });
            }
            bounds.set(id, evidence);
            const visual = material.find((o) => o.origin === "vision");
            if (visual && !signals.includes(visual)) {
              evidence.push({
                start: visual.t,
                end: visual.t,
                kind: "vision",
                label: evidenceLabel(visual),
              });
            }
            const ratio = (moment.end - moment.start) / target;
            const penalty = Math.min(21, Math.max(0, (ratio - 1.25) * 8));
            const breakdown = {
              ...moment.breakdown,
              context: Math.max(
                1,
                Math.round(moment.breakdown.context - penalty),
              ),
              hook: Math.max(1, Math.round(moment.breakdown.hook - penalty)),
            };
            return [{ ...moment, breakdown, id, peak, signals }];
          },
        );
        for (const event of seeded) {
          const id = `semantic-${key}-e${editorialVersion}-${base}-${event.id}`;
          candidates.push({ ...event, id });
          bounds.set(
            id,
            event.evidence.map((o) => ({
              start: o.t,
              end: o.t,
              kind: o.origin ?? "ocr",
              label: evidenceLabel(o),
            })),
          );
        }
        const selection = selectMoments(
          candidates,
          words,
          classification.engine,
          {
            targetLengthSec: target,
            minLengthSec: 0,
            deduplicate: false,
            roundTimes: false,
          },
        );
        const selected = selection.selected.flatMap((moment): Ranked[] => {
          const candidate = candidates.find(
            (entry) => entry.id === moment.candidateId,
          )!;
          const keepStart = Math.max(start, moment.start);
          const keepEnd = Math.min(end, moment.end);
          if (
            keepEnd <= keepStart ||
            (candidate.peak !== undefined &&
              (candidate.peak < keepStart - 0.05 ||
                candidate.peak > keepEnd + 0.05))
          )
            return [];
          const captured = bounds
            .get(moment.candidateId)!
            .filter(
              (entry) =>
                entry.start >= keepStart - 0.1 && entry.end <= keepEnd + 0.1,
            );
          const anchor = captured.find(
            (entry) => entry.kind === "ocr" || entry.kind === "speech",
          );
          if (!anchor) return [];
          if (
            candidate.id.includes("-hud-") &&
            !captured.some(({ kind }) => kind === "vision" || kind === "audio")
          )
            return [];
          return [
            {
              ...moment,
              reason: anchor.label,
              start: keepStart,
              end: keepEnd,
              window: base,
              evidence: [...new Set(captured.map((entry) => entry.label))],
              fingerprint: [...tokens(words, keepStart, keepEnd)],
            },
          ];
        });
        const evaluations = moments.map((moment, i) => {
          const candidate = candidates.find(
            (entry) =>
              entry.id === `semantic-${key}-e${editorialVersion}-${base}-${i}`,
          );
          return {
            ...moment,
            score: candidate
              ? scoreMoment(candidate, classification.engine)
              : scoreMoment(
                  { ...moment, id: "", signals: [] },
                  classification.engine,
                ),
            validated: Boolean(candidate),
          };
        });
        return {
          evaluations: [
            ...evaluations,
            ...seeded.map((event) => ({
              ...event,
              score: scoreMoment(event, "gaming"),
              validated: true,
            })),
          ],
          selected,
        };
      },
    );
    evaluated += result.evaluations.length;
    found.push(...result.selected);
    await options.progress(Math.min(100, ((base + core) * 100) / duration));
  }

  const kept: (Ranked & { tokenSet: Set<string> })[] = [];
  found.sort((a, b) => b.score - a.score || a.start - b.start);
  for (const moment of found) {
    const tokenSet = new Set(moment.fingerprint);
    if (
      kept.some(
        (entry) =>
          overlapRatio(entry, moment) > 0.35 ||
          jaccard(entry.tokenSet, tokenSet) > 0.55,
      )
    )
      continue;
    kept.push({ ...moment, tokenSet });
  }
  return { evaluated, selected: kept };
}

export async function semanticCut(
  cwd: string,
  moment: SelectedMoment,
  audio: boolean,
) {
  const words = await readWords(cwd, moment.start, moment.end, audio);
  return {
    start: moment.start,
    end: moment.end,
    title: MOMENT_KIND_LABEL[moment.kind],
    words: words.map(({ start, end, text }): TimedWord => [
      Math.max(start, moment.start),
      Math.min(end, moment.end),
      text,
    ]),
  };
}
