"""Transcribe bounded windows, reusing a local model for the job."""
import json
import os
import sys

import ctranslate2
from faster_whisper import WhisperModel

model_name = os.environ.get("KLIPORA_MODEL", "small")
model = None
device = "cpu"
requested = os.environ.get("KLIPORA_DEVICE", "auto")
notice = ""
if requested != "cpu":
    try:
        if ctranslate2.get_cuda_device_count() > 0:
            model = WhisperModel(model_name, device="cuda", compute_type="float16")
            device = "cuda"
        else:
            notice = "CUDA no disponible"
    except (RuntimeError, ValueError, OSError) as error:
        notice = f"CUDA no disponible: {error}"

def cpu_model():
    return WhisperModel(model_name, device="cpu", compute_type="int8")

def transcribe(engine, path, language):
    segments, _ = engine.transcribe(path, language=None if language == "auto" else language,
                                    word_timestamps=True, vad_filter=True)
    return [[word.start, word.end, word.word] for segment in segments for word in (segment.words or [])]

for line in sys.stdin:
    try:
        path, language = json.loads(line)
        if model is None:
            model = cpu_model()
        try:
            words = transcribe(model, path, language)
        except (RuntimeError, ValueError, OSError) as error:
            if device != "cuda":
                raise
            notice = f"CUDA falló: {error}"
            model, device = cpu_model(), "cpu"
            words = transcribe(model, path, language)
        label = "CUDA · float16" if device == "cuda" else "CPU · int8"
        if notice:
            label += " (" + notice[:180] + ")"
        print(json.dumps({"words": words, "device": label}), flush=True)
    except Exception as error:
        print(json.dumps({"error": str(error)}), flush=True)
