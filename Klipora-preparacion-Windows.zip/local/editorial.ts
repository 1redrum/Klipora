import { sentenceBoundaries } from "../src/lib/analysis/selection.ts";
import type { Word } from "../src/lib/types.ts";

type Span = { start: number; end: number };
const continuation = /^(?:and|or|but|because|so|y|o|pero|porque|entonces)\b/iu;

export function chooseBounds(
  words: Word[],
  proposed: Span,
  focus: Span,
  target: number,
) {
  if (!words.length || focus.start < proposed.start || focus.end > proposed.end)
    return proposed;
  const { starts, ends } = sentenceBoundaries(words);
  let best = proposed;
  let cost =
    Math.abs(Math.log((proposed.end - proposed.start) / target)) + 0.12;
  for (const a of starts) {
    const first = words[a];
    if (first.start < proposed.start - 0.05 || first.start > focus.start)
      continue;
    for (const b of ends) {
      const last = words[b];
      if (b < a || last.end < focus.end || last.end > proposed.end + 0.05)
        continue;
      const length = last.end - first.start;
      if (length <= 0) continue;
      const contextLoss =
        (first.start - proposed.start + proposed.end - last.end) /
        Math.max(target, length);
      const incomplete = continuation.test(first.text.trim()) ? 0.4 : 0;
      const ending = /[.!?…]["»”)]*$/u.test(last.text.trim()) ? 0 : 0.25;
      const nextCost =
        Math.abs(Math.log(length / target)) +
        Math.max(0, contextLoss) * 0.22 +
        incomplete +
        ending;
      if (nextCost < cost) {
        best = { start: first.start, end: last.end };
        cost = nextCost;
      }
    }
  }
  return best;
}

const leadingFragment =
  /^(?:and|or|but|because|so|in|of|from|to|with|by|at|y|o|pero|porque|en|de|del|para|con|por)\b/u;

export function trimLeadingFragment(words: Word[], proposed: Span) {
  const { starts } = sentenceBoundaries(words);
  const within = [...starts]
    .map((index) => words[index])
    .filter(
      (word) =>
        word.start >= proposed.start - 0.05 && word.start < proposed.end,
    );
  if (!within.length || !leadingFragment.test(within[0].text.trim()))
    return proposed;
  const next = within.find((word) => !leadingFragment.test(word.text.trim()));
  if (!next || next.start - proposed.start > 8 || proposed.end - next.start < 2)
    return proposed;
  return { start: next.start, end: proposed.end };
}

export function trimTrailingFragment(words: Word[], proposed: Span) {
  const inClip = words.filter(
    (word) =>
      word.start >= proposed.start - 0.05 && word.end <= proposed.end + 0.05,
  );
  const last = inClip.at(-1);
  if (!last || !/[,;:]$/u.test(last.text.trim())) return proposed;
  const complete = inClip
    .reverse()
    .find((word) => /[.!?…]["»”)]*$/u.test(word.text.trim()));
  return complete && complete.end > proposed.start
    ? { start: proposed.start, end: complete.end }
    : null;
}
