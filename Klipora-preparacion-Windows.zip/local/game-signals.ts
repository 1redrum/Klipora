import { mkdtemp, readdir, rm } from "node:fs/promises";
import { join } from "node:path";
import type {
  GameKey,
  MomentSignal,
  SignalKind,
} from "../src/lib/analysis/content.ts";

import { execLocal as exec, reportDevice } from "./processes.ts";
export type Observation = MomentSignal & {
  text: string;
  origin?: "vision" | "ocr" | "audio";
};
const hud: [SignalKind, RegExp][] = [
  [
    "victory-screen",
    /\bvictory royale\b|\b(?:flawless )?victory\b|\bganaste\b|\bvictoria\b|\bwin(?:ner)? winner chicken dinner\b/i,
  ],
  ["defeat-screen", /\bdefeat\b|\bderrota\b|\byou lost\b|\bmission failed\b/i],
  [
    "multikill",
    /\b(?:double|triple|quadra|penta|multi|doble)\s*(?:kill|baja)\b/i,
  ],
  [
    "death",
    /\byou (?:died|were eliminated)\b|\bhas muerto\b|\bte han eliminado\b/i,
  ],
  [
    "kill-feed",
    /\byou eliminated\b|\beliminaste a\b|\benemy killed\b|\b(?:confirmed kill|kill confirmed|enemy eliminated)\b/i,
  ],
  [
    "objective",
    /\b(?:spike|bomb) (?:planted|defused)\b|\b(?:objective|point) (?:captured|secured)\b|\bmission completed\b/i,
  ],
  ["round-change", /\bround (?:won|lost|over)\b|\bronda (?:ganada|perdida)\b/i],
];

const profiles: Partial<Record<GameKey, [SignalKind, RegExp][]>> = {
  fortnite: [
    ["victory-screen", /victory royale|victoria magistral/i],
    ["kill-feed", /(?:you eliminated|eliminaste a)\s+\S+/i],
  ],
  minecraft: [
    ["death", /you died|has muerto/i],
    ["objective", /advancement made|goal reached|desafío completado/i],
  ],
  "gta-v": [
    ["death", /\bwasted\b|\bfulminado\b/i],
    ["objective", /mission passed|misión superada/i],
  ],
  valorant: [
    ["multikill", /\bteam ace\b/i],
    ["objective", /spike (?:planted|defused)/i],
    ["round-change", /round (?:won|lost)/i],
  ],
  cs2: [
    ["round-change", /(?:counter-terrorists|terrorists) win/i],
    ["objective", /bomb has been (?:planted|defused)/i],
  ],
  cod: [
    ["multikill", /double kill|triple kill|quad feed/i],
    ["kill-feed", /elimination confirmed|enemy eliminated/i],
    ["objective", /hardpoint (?:secured|locked down)/i],
  ],
};

export function readHud(
  text: string,
  t: number,
  game?: GameKey,
): Observation[] {
  const clean = text.replace(/\s+/g, " ").trim();
  const found = new Map<SignalKind, Observation>();
  for (const [kind, pattern] of [
    ...(game ? (profiles[game] ?? []) : []),
    ...hud,
  ]) {
    const match = clean.match(pattern);
    if (match && !found.has(kind))
      found.set(kind, {
        kind,
        t,
        strength: 0.75,
        text: match[0],
        origin: "ocr",
      });
  }
  return [...found.values()];
}

export async function gameObservations(
  cwd: string,
  source: string,
  start: number,
  end: number,
  audio: boolean,
  game?: GameKey,
  stride = 3,
) {
  const frames = await mkdtemp(join(cwd, "ocr-"));
  const input = [
    "-nostdin",
    "-hide_banner",
    "-loglevel",
    "error",
    "-ss",
    String(start),
    "-i",
    source,
    "-t",
    String(end - start),
  ];
  const observations: Observation[] = [];
  try {
    await exec(
      "ffmpeg",
      [
        ...input,
        "-an",
        "-filter_threads",
        "1",
        "-vf",
        `fps=1/${stride}:start_time=0,scale=960:-2`,
        "-threads",
        "1",
        join(frames, "%05d.png"),
      ],
      { cwd },
    );
    reportDevice("ocr", "CPU · Tesseract");
    const files = (await readdir(frames)).sort();
    const last = new Map<string, number>();
    for (const [index, file] of files.entries()) {
      let stdout: string;
      try {
        ({ stdout } = await exec(
          process.env.KLIPORA_TESSERACT || "tesseract",
          [
            join(frames, file),
            "stdout",
            "-l",
            process.env.KLIPORA_OCR_LANG || "eng",
            "--psm",
            "11",
          ],
          { env: { ...process.env, OMP_THREAD_LIMIT: "1" } },
        ));
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") {
          throw new Error(
            "Instala Tesseract OCR o configura KLIPORA_TESSERACT para analizar el HUD.",
            { cause: error },
          );
        }
        throw error;
      }
      for (const observation of readHud(
        stdout,
        Math.min(end, start + index * stride),
        game,
      )) {
        const identity =
          observation.kind + ":" + observation.text.toLowerCase();
        const previous = last.get(identity) ?? -Infinity;
        last.set(identity, observation.t);
        const debounce =
          observation.kind === "objective" ? stride * 4 : stride * 2;
        if (observation.t - previous > debounce) observations.push(observation);
      }
    }
  } finally {
    await rm(frames, { recursive: true, force: true });
  }
  if (!audio) return observations;

  reportDevice("audio", "CPU · FFmpeg RMS");
  const { stdout } = await exec(
    "ffmpeg",
    [
      ...input,
      "-vn",
      "-ac",
      "1",
      "-ar",
      "16000",
      "-af",
      "aresample=16000,asetnsamples=n=16000:p=0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
      "-f",
      "null",
      "-",
    ],
    { cwd },
  );
  const levels = [
    ...stdout.matchAll(/pts_time:([\d.]+)[^\n]*\n[^\n]*RMS_level=([^\n]+)/g),
  ]
    .map((match) => ({ t: start + Number(match[1]), db: Number(match[2]) }))
    .filter(({ db }) => Number.isFinite(db));
  const sorted = levels.map(({ db }) => db).sort((a, b) => a - b);
  const baseline = Math.max(-55, sorted[Math.floor(sorted.length / 2)] ?? -55);
  for (const { t, db } of levels) {
    const increase = db - baseline;
    if (db > -35 && increase >= 9)
      observations.push({
        kind: "audio-peak",
        origin: "audio",
        t,
        strength: Math.min(1, increase / 24),
        text: `+${Math.round(increase)} dB RMS frente a la mediana local`,
      });
  }
  return observations;
}
